<script setup lang="ts" generic="T extends string | number | null | undefined = string">
import type { HTMLAttributes } from 'vue'
import { getCurrentInstance, nextTick, onMounted, onUpdated, ref } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{
  class?: HTMLAttributes['class']
  size?: 'default' | 'sm'
  modelValue?: T
  defaultValue?: T
  /** Return false to reject a choice synchronously. Async validation belongs to the product. */
  acceptValue?: (value: T) => boolean
}>(), { class: undefined, size: 'default' })
const emit = defineEmits<{ 'update:modelValue': [value: T] }>()
const instance = getCurrentInstance()!
const select = ref<HTMLSelectElement>()
const local = ref<T | undefined>(props.defaultValue)
const controlled = () => ['modelValue', 'model-value'].some(key => Object.prototype.hasOwnProperty.call(instance.vnode.props ?? {}, key))
const optionValue = (option: HTMLOptionElement): T => ('_value' in option ? (option as HTMLOptionElement & { _value: T })._value : option.value as T)
function syncSelection() {
  if (!select.value) return
  const value = controlled() ? props.modelValue : local.value
  select.value.selectedIndex = Array.from(select.value.options).findIndex(option => Object.is(optionValue(option), value))
}
async function change(event: Event) {
  const element = event.target as HTMLSelectElement
  const option = element.options[element.selectedIndex]
  if (!option) return
  const value = optionValue(option)
  if (!element.disabled && (!props.acceptValue || props.acceptValue(value))) {
    if (!controlled()) local.value = value
    emit('update:modelValue', value)
  }
  await nextTick()
  syncSelection()
}
onMounted(syncSelection)
onUpdated(syncSelection)
</script>

<template>
  <select ref="select" data-slot="native-select" :class="cn('ui-native-select flex h-10 w-full min-w-0 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50', props.size === 'sm' && 'h-9 py-1.5', props.class)" @change="change">
    <slot />
  </select>
</template>
