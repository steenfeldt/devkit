<script setup lang="ts">
import type { Component } from 'vue'
import { CardHeader, CardTitle } from '../components/ui/card'

defineProps<{ id: string; title: string; icon?: Component }>()
</script>

<template>
  <CardHeader class="pb-3">
    <CardTitle :id="id" as="h2" class="flex items-center gap-1.5 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
      <component :is="icon" v-if="icon" class="h-3.5 w-3.5" :stroke-width="1.75" aria-hidden="true" />
      {{ title }}
    </CardTitle>
  </CardHeader>
</template>
