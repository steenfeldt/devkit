/** Shared layout classes. `sd-shell-container` is a stable hook (SwiftDeploy's shell container). */
export const shellContainerClass = 'sd-shell-container mx-auto w-full max-w-[105rem] px-4 sm:px-6 lg:px-8'

export type CollapseBreakpoint = 'md' | 'lg' | 'xl'

/** Static class strings per breakpoint, so Tailwind's content scanning finds them. */
export const collapseClasses: Record<CollapseBreakpoint, { desktop: string; mobile: string }> = {
  md: { desktop: 'hidden md:flex', mobile: 'md:hidden' },
  lg: { desktop: 'hidden lg:flex', mobile: 'lg:hidden' },
  xl: { desktop: 'hidden xl:flex', mobile: 'xl:hidden' },
}
