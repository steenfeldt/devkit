<script setup lang="ts">
import type { DialogCloseProps } from 'reka-ui'
import { DialogClose } from 'reka-ui'

const props = defineProps<DialogCloseProps>()
</script>

<template>
  <!-- With as-child the child keeps its own data-slot (for example "button"). -->
  <DialogClose v-bind="props.asChild ? props : { ...props, 'data-slot': 'sheet-close' }">
    <slot />
  </DialogClose>
</template>
