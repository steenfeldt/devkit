<script setup lang="ts">
import type { ProgressRootProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import {
  ProgressIndicator,
  ProgressRoot,
} from "reka-ui"

const props = withDefaults(
  defineProps<ProgressRootProps & { class?: HTMLAttributes["class"]; color?: "primary" | "neutral" | "info" | "success" | "warning" | "destructive" }>(),
  {
    modelValue: 0,
    color: "primary",
  },
)

const delegatedProps = reactiveOmit(props, "class", "color")
const tones = {
  neutral: ["bg-muted", "bg-muted-foreground"],
  primary: ["bg-primary/20", "bg-primary"],
  info: ["bg-info/20", "bg-info"],
  success: ["bg-success/20", "bg-success"],
  warning: ["bg-warning/20", "bg-warning"],
  destructive: ["bg-destructive/20", "bg-destructive"],
}
</script>

<template>
  <ProgressRoot
    data-slot="progress"
    v-bind="delegatedProps"
    :class="
      cn(
        tones[color][0], 'relative h-2 w-full overflow-hidden rounded-full',
        props.class,
      )
    "
  >
    <ProgressIndicator
      data-slot="progress-indicator"
      :class="[tones[color][1], 'h-full w-full flex-1 transition-all']"
      :style="`transform: translateX(-${100 - (props.modelValue ?? 0)}%);`"
    />
  </ProgressRoot>
</template>
