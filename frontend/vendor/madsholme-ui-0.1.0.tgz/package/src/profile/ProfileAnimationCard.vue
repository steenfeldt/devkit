<script setup lang="ts">
import { useId } from 'vue'
import { Card, CardContent } from '../components/ui/card'
import { Switch } from '../components/ui/switch'
import ProfileCardTitle from './ProfileCardTitle.vue'

withDefaults(defineProps<{
  enabled?: boolean
  saving?: boolean
  error?: string
}>(), { enabled: true, saving: false, error: '' })
const emit = defineEmits<{ 'update:enabled': [enabled: boolean] }>()
const id = `profile-animations-${useId()}`
</script>

<template>
  <Card data-slot="profile-animation-card" :aria-labelledby="`${id}-title`">
    <ProfileCardTitle :id="`${id}-title`" title="Motion Settings" />
    <CardContent>
      <div class="flex items-start justify-between gap-4">
        <div class="min-w-0">
          <label :for="id" class="text-sm font-medium">Animations</label>
          <p :id="`${id}-description`" class="m-0 mt-1 text-xs text-muted-foreground">
            Animate menus, dialogs and interface effects. Your device’s reduced-motion setting still applies. Loading indicators stay active.
          </p>
        </div>
        <Switch :id="id" :model-value="enabled" :aria-describedby="`${id}-description`" @update:model-value="emit('update:enabled', Boolean($event))" />
      </div>
      <p v-if="saving" role="status" class="mb-0 mt-3 text-xs text-muted-foreground">Saving…</p>
      <p v-if="error" role="alert" class="mb-0 mt-3 text-sm font-medium text-destructive">{{ error }}</p>
    </CardContent>
  </Card>
</template>
