<script setup lang="ts">
import { useId, type Component } from 'vue'
import { Badge } from '../components/ui/badge'
import { Card, CardContent } from '../components/ui/card'
import ProfileCardTitle from './ProfileCardTitle.vue'
import type { ProfileDetailRow } from './types'

withDefaults(defineProps<{
  title: string
  icon?: Component
  rows: readonly ProfileDetailRow[]
  /** Shown instead of the rows when there are none. */
  emptyTitle?: string
  emptyDescription?: string
  footnote?: string
}>(), { icon: undefined, emptyTitle: '', emptyDescription: '', footnote: '' })

const titleId = `profile-card-${useId()}`
</script>

<template>
  <Card data-slot="profile-details-card" :aria-labelledby="titleId">
    <ProfileCardTitle :id="titleId" :title="title" :icon="icon" />
    <CardContent v-if="rows.length">
      <dl data-slot="profile-details" class="profile-details m-0">
        <div v-for="row in rows" :key="row.key" data-slot="profile-detail" class="profile-details__row">
          <dt class="shrink-0 text-sm text-muted-foreground">{{ row.label }}</dt>
          <dd class="m-0 min-w-0 text-right">
            <slot :name="`row-${row.key}`" :row="row">
              <Badge v-if="row.badge" :variant="row.badge.variant ?? 'outline'">{{ row.badge.label }}</Badge>
              <div v-else-if="row.groups" class="space-y-2">
                <div v-for="group in row.groups" :key="group.id">
                  <p class="m-0 text-sm font-medium">
                    {{ group.name }}
                    <Badge v-if="group.isPrimary" variant="outline" class="ml-1 text-[10px]">Primary</Badge>
                  </p>
                  <p v-if="group.externalId" class="m-0 break-all font-mono text-xs text-muted-foreground">{{ group.externalId }}</p>
                </div>
                <p v-if="!row.groups.length" class="m-0 text-sm text-muted-foreground">{{ row.emptyText ?? '—' }}</p>
              </div>
              <template v-else>
                <p v-if="row.value" class="m-0 break-all text-sm" :class="row.mono ? 'font-mono' : 'font-medium'">{{ row.value }}</p>
                <p v-else class="m-0 text-sm text-muted-foreground">{{ row.emptyText ?? '—' }}</p>
                <p v-if="row.detail" class="m-0 break-all font-mono text-xs text-muted-foreground">{{ row.detail }}</p>
              </template>
            </slot>
          </dd>
        </div>
      </dl>
      <p v-if="footnote" class="mb-0 mt-4 text-xs text-muted-foreground">{{ footnote }}</p>
      <slot name="footer" />
    </CardContent>
    <CardContent v-else>
      <p class="m-0 text-sm font-medium">{{ emptyTitle }}</p>
      <p v-if="emptyDescription" class="mb-0 mt-1 text-xs text-muted-foreground">{{ emptyDescription }}</p>
    </CardContent>
  </Card>
</template>

<style scoped>
/* SwiftDeploy's label/value rows with separators, as a definition list (SwiftPatch); stacked on narrow screens. */
.profile-details__row { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; padding-block: .75rem; border-top: 1px solid var(--border); }
.profile-details__row:first-child { border-top: 0; padding-top: 0; }
.profile-details__row:last-child { padding-bottom: 0; }
@media (max-width: 479px) {
  .profile-details__row { flex-direction: column; gap: .25rem; }
  .profile-details__row dd { text-align: left; }
}
</style>
