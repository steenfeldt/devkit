import type { Component } from 'vue'
import { Info, OctagonAlert, TriangleAlert } from 'lucide-vue-next'
import type { GlobalNotice } from '../types'

const priority: Record<GlobalNotice['category'], number> = { alert: 0, warning: 1, information: 2 }

/** Alerts first, then warnings, then information; stable within a category. */
export function sortGlobalNotices<T extends GlobalNotice>(notices: readonly T[]): T[] {
  return notices.map((notice, index) => ({ notice, index }))
    .sort((a, b) => priority[a.notice.category] - priority[b.notice.category] || a.index - b.index)
    .map(({ notice }) => notice)
}

export const noticeIcons: Record<GlobalNotice['category'], Component> = {
  information: Info,
  warning: TriangleAlert,
  alert: OctagonAlert,
}
