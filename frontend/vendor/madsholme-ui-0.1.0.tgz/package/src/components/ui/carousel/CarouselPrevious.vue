<script setup lang="ts">
import type { WithClassAsProps } from "./interface"
import type { ButtonVariants } from "../button"
import { ArrowLeft } from "lucide-vue-next"
import { cn } from "../../../lib/utils"
import { Button } from "../button"
import { useCarousel } from "./useCarousel"

const props = withDefaults(defineProps<{
  variant?: ButtonVariants["variant"]
  size?: ButtonVariants["size"]
}
& WithClassAsProps>(), {
  variant: "outline",
  size: "icon",
})

const { orientation, canScrollPrev, scrollPrev } = useCarousel()
</script>

<template>
  <Button
    data-slot="carousel-previous"
    :disabled="!canScrollPrev"
    :class="cn(
      'absolute size-8 rounded-full',
      orientation === 'horizontal'
        ? 'top-1/2 -left-12 -translate-y-1/2 active:-translate-y-1/2'
        : '-top-12 left-1/2 -translate-x-1/2 rotate-90 active:translate-y-0',
      props.class,
    )"
    :variant="variant"
    :size="size"
    @click="scrollPrev"
  >
    <slot>
      <ArrowLeft />
      <span class="sr-only">Previous Slide</span>
    </slot>
  </Button>
</template>
