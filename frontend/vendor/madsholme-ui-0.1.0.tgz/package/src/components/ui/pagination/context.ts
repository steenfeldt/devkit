import type { ComputedRef, InjectionKey } from 'vue'
import { computed, inject } from 'vue'
export interface PaginationLabels {
  navigation?: string
  first?: string
  previous?: string
  next?: string
  last?: string
  page?: (page: number) => string
  summary?: (page: number, pages: number) => string
}
export const defaultPaginationLabels = {
  navigation: 'Pagination', first: 'First', previous: 'Previous', next: 'Next', last: 'Last',
  page: (page: number) => `Page ${page}`,
  summary: (page: number, pages: number) => `Page ${page} of ${pages}`,
}
export const paginationOptionsKey: InjectionKey<ComputedRef<{ labels: typeof defaultPaginationLabels; selectedAttribute: boolean }>> = Symbol('SwiftPaginationOptions')
export function usePaginationOptions() {
  return inject(paginationOptionsKey, computed(() => ({ labels: defaultPaginationLabels, selectedAttribute: true })))
}
