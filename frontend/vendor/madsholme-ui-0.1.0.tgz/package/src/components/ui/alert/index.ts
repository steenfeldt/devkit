import type { VariantProps } from 'class-variance-authority'
import { cva } from 'class-variance-authority'

export { default as Alert } from './Alert.vue'
export { default as AlertDescription } from './AlertDescription.vue'
export { default as AlertTitle } from './AlertTitle.vue'

export const alertVariants = cva(
  'relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground',
  {
    variants: {
      variant: {
        default: 'bg-background text-foreground',
        info: 'border-info bg-[var(--sd-info-background)] text-[var(--sd-info-foreground)] [&>svg]:text-[var(--sd-info-foreground)]',
        success: 'border-success bg-[var(--sd-success-background)] text-[var(--sd-success-foreground)] [&>svg]:text-[var(--sd-success-foreground)]',
        warning: 'border-warning bg-[var(--sd-warning-background)] text-[var(--sd-warning-foreground)] [&>svg]:text-[var(--sd-warning-foreground)]',
        destructive:
          'border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive [&_[data-slot=alert-description]]:text-foreground',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
)

export type AlertVariants = VariantProps<typeof alertVariants>
