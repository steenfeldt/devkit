import type { InjectionKey, ComputedRef } from 'vue'
export const tabsVariantKey: InjectionKey<ComputedRef<'default' | 'underline'>> = Symbol('SwiftTabsVariant')
