export { default as Toaster } from './Toaster.vue'
// Re-export the same store so existing vue-sonner callers and shared consumers interoperate.
export { toast } from 'vue-sonner'
export type { ExternalToast, ToasterProps } from 'vue-sonner'
