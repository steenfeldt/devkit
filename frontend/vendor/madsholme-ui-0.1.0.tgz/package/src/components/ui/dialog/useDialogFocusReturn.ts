import { onBeforeUnmount } from 'vue'

/** Reka restores focus synchronously; AppShell clears mirrored inert in a mutation observer.
 * Retry on the next task only when normal restoration could not focus the trigger.
 * Explicit consumer close-auto-focus handlers retain full control via preventDefault(). */
export function useDialogFocusReturn() {
  let target: HTMLElement | null = null
  let unmounting = false
  let retry: ReturnType<typeof setTimeout> | undefined
  onBeforeUnmount(() => {
    unmounting = true
    clearTimeout(retry)
  })
  function rememberFocus() {
    target = document.activeElement instanceof HTMLElement ? document.activeElement : null
  }
  function restoreFocus(event: Event) {
    const previous = target
    target = null
    if (event.defaultPrevented || !previous) return
    // Parent removal must never leave a delayed focus return behind. Reka releases
    // the scope and hidden siblings during teardown; finish our return in that teardown.
    if (unmounting) {
      if (previous.isConnected) previous.focus()
      return
    }
    clearTimeout(retry)
    retry = setTimeout(() => {
      if (previous.isConnected && document.activeElement === document.body) previous.focus()
    })
  }
  return { rememberFocus, restoreFocus }
}
