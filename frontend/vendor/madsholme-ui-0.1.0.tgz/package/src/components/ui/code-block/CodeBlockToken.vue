<script setup lang="ts">
import type { HighlightedToken } from "./highlighter"

defineProps<{
  token: HighlightedToken
}>()
</script>

<template>
  <span :style="token.htmlStyle">{{ token.content }}</span>
</template>
