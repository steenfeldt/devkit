<script setup lang="ts">
import { inject } from "vue"
import { comboboxOptionsKey } from "./context"
import type { ComboboxItemEmits, ComboboxItemProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { ComboboxItem, useForwardProps, injectComboboxRootContext } from "reka-ui"

const props = defineProps<ComboboxItemProps & { class?: HTMLAttributes["class"] }>()
const emits = defineEmits<ComboboxItemEmits>()

const delegatedProps = reactiveOmit(props, "class")

const forwarded = useForwardProps(delegatedProps)
const options = inject(comboboxOptionsKey, undefined)
const root = injectComboboxRootContext()
function select(event: ComboboxItemEmits['select'][0]) {
  emits('select', event)
  if (event.defaultPrevented || !options?.clearOnReselect.value || root.multiple.value || root.disabled.value || props.disabled) return
  // Reka has already compared values (including object `by` comparisons) for aria-selected.
  if (event.target instanceof HTMLElement && event.target.getAttribute('aria-selected') === 'true') {
    event.preventDefault()
    root.modelValue.value = null
    root.onOpenChange(false)
  }
}
</script>

<template>
  <ComboboxItem
    data-slot="combobox-item"
    v-bind="forwarded"
    @select="select"
    :class="cn(`data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground [&_svg:not([class*='text-'])]:text-muted-foreground relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4`, props.class)"
  >
    <slot />
  </ComboboxItem>
</template>
