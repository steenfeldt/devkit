<script setup lang="ts">
import { computed, provide } from "vue"
import type { PaginationLabels } from "./context"
import { defaultPaginationLabels, paginationOptionsKey } from "./context"
import PaginationPrevious from "./PaginationPrevious.vue"
import PaginationNext from "./PaginationNext.vue"
import type { PaginationRootEmits, PaginationRootProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { PaginationRoot, useForwardPropsEmits } from "reka-ui"

const props = defineProps<PaginationRootProps & {
  class?: HTMLAttributes["class"]
  compact?: boolean
  labels?: PaginationLabels
  selectedAttribute?: boolean
}>()
const options = computed(() => ({ labels: { ...defaultPaginationLabels, ...props.labels }, selectedAttribute: props.selectedAttribute !== false }))
provide(paginationOptionsKey, options)
const emits = defineEmits<PaginationRootEmits>()

const delegatedProps = reactiveOmit(props, "class", "compact", "labels", "selectedAttribute")
const forwarded = useForwardPropsEmits(delegatedProps, emits)
</script>

<template>
  <PaginationRoot
    v-slot="slotProps"
    data-slot="pagination"
    :aria-label="options.labels.navigation"
    v-bind="forwarded"
    :class="cn('mx-auto flex w-full justify-center', compact && 'items-center gap-2', props.class)"
  >
    <slot v-bind="slotProps">
      <template v-if="compact">
        <PaginationPrevious />
        <span data-slot="pagination-summary" class="text-sm text-muted-foreground" aria-live="polite">{{ options.labels.summary(slotProps.page, slotProps.pageCount) }}</span>
        <PaginationNext />
      </template>
    </slot>
  </PaginationRoot>
</template>
