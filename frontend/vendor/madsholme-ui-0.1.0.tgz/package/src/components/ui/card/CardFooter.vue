<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{ class?: HTMLAttributes['class'] }>(), { class: undefined })
</script>

<template>
  <div
    data-slot="card-footer"
    :class="cn('ui-card-footer flex items-center p-6 pt-0', props.class)"
  >
    <slot />
  </div>
</template>
