<script setup lang="ts">
import type { DialogTriggerProps } from 'reka-ui'
import { DialogTrigger } from 'reka-ui'

const props = defineProps<DialogTriggerProps>()
</script>

<template>
  <!-- With as-child the child keeps its own data-slot (for example "button"). -->
  <DialogTrigger v-bind="props.asChild ? props : { ...props, 'data-slot': 'sheet-trigger' }">
    <slot />
  </DialogTrigger>
</template>
