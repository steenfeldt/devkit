import type { Component } from 'vue'

export interface ProfileBadge {
  readonly key: string
  readonly label: string
  readonly variant?: 'default' | 'secondary' | 'outline' | 'destructive'
  readonly icon?: Component
}

export interface ProfileGroup {
  readonly id: string | number
  readonly name: string
  /** External identifier shown in monospace (ServiceNow sys_id, external_id). */
  readonly externalId?: string | null
  readonly isPrimary?: boolean
}

export interface ProfileDetailRow {
  readonly key: string
  readonly label: string
  readonly value?: string | null
  /** A second, monospace line under the value (an ID). */
  readonly detail?: string | null
  /** Show the value in monospace. */
  readonly mono?: boolean
  /** Groups listed under each other (name, ID, "Primary"). */
  readonly groups?: readonly ProfileGroup[]
  /** Shown when there is no value or no groups. */
  readonly emptyText?: string
  /** A status shown as a badge (text, so it never relies on colour alone). */
  readonly badge?: ProfileBadge
}

export interface ApiTokenSummary {
  readonly id: string | number
  readonly name: string
  readonly prefix: string
  readonly createdAt: string
  readonly expiresAt: string
  readonly lastUsedAt: string | null
  readonly access?: 'read' | 'write' | null
}

export interface GeneratedApiToken extends ApiTokenSummary {
  /** The one-time secret. */
  readonly secret: string
}

export interface ApiTokenAccessOption {
  readonly value: 'read' | 'write'
  readonly label: string
  readonly description?: string
}

export interface TokenDateOptions {
  readonly locale?: string
  readonly timeZone?: string
}

export interface AuthorizationIdentity {
  readonly providerName: string
  readonly providerKey?: string | null
  /** Shown as a badge with text, e.g. "Synced", "Linked". */
  readonly status: string
  readonly statusTone?: 'positive' | 'neutral'
  readonly matchMethod?: string | null
  readonly externalUsername?: string | null
  readonly externalId?: string | null
  readonly email?: string | null
  readonly message?: string | null
}
/** An MCP token's access in one area. */
export type McpGrantLevel = 'none' | 'read' | 'read_write'

/** One area an MCP token can be granted, e.g. normal user or application admin. */
export interface McpGrantArea {
  /** The product's grant field, e.g. `user_access`. */
  readonly key: string
  readonly label: string
  /** Used in token badges, e.g. "App admin: Read/write". */
  readonly shortLabel: string
  readonly description?: string
}

/** Grant level per area key. */
export type McpGrants = Readonly<Record<string, McpGrantLevel>>

/** Token lifetimes in seconds. Any read/write grant uses `write`. */
export interface McpTokenLifetimes {
  readonly readOnly: number
  readonly write: number
}

export interface McpTokenSummary {
  readonly id: string | number
  readonly name: string
  readonly prefix: string
  readonly createdAt: string
  readonly expiresAt: string
  readonly lastUsedAt: string | null
  readonly grants: McpGrants
}

export interface McpClientSnippet {
  readonly title: string
  /** One paragraph, or several. */
  readonly description?: string | readonly string[]
  /** Placeholders and environment variable names only, never a secret. */
  readonly code: string
}

export interface McpClientExample {
  readonly id: string
  readonly label: string
  /** Manual bearer-token configuration; always available. */
  readonly snippets: readonly McpClientSnippet[]
  /** Browser OAuth setup; rendered only when the product explicitly enables OAuth. */
  readonly oauthSnippets?: readonly McpClientSnippet[]
}

/** Product-owned browser connection instructions; plain text, not HTML or secrets. */
export interface McpClientGuidance {
  readonly id: string
  readonly label: string
  readonly description: string | readonly string[]
}

/** Only explicit enablement advertises browser sign-in. Products own discovery and auth. */
export type McpBrowserOAuth = {
  readonly enabled: true
  readonly loginProviderLabel: string
  readonly clientGuidance?: readonly McpClientGuidance[]
} | {
  readonly enabled: false | null
}
