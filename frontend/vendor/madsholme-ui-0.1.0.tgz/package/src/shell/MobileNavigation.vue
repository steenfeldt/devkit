<script setup lang="ts">
import { Menu } from 'lucide-vue-next'
import { RouterLink } from 'vue-router'
import { Button } from '../components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu'
import type { NavGroup } from '../types'

defineProps<{ navigation: readonly NavGroup[]; currentId: string | null }>()
const open = defineModel<boolean>('open', { default: false })
</script>

<template>
  <DropdownMenu v-model:open="open" :modal="false">
    <DropdownMenuTrigger as-child>
      <Button
        data-site-header-interactive
        data-slot="mobile-navigation-trigger"
        variant="ghost"
        size="icon"
        aria-label="Open navigation"
      >
        <Menu class="size-5" aria-hidden="true" />
      </Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent data-testid="mobile-navigation" align="start" class="w-60">
      <template v-for="(group, index) in navigation" :key="group.id">
        <DropdownMenuSeparator v-if="index > 0" />
        <DropdownMenuItem v-if="!group.items?.length && group.to" as-child>
          <RouterLink :to="group.to" :aria-current="currentId === group.id ? 'page' : undefined" class="flex items-center gap-2">
            <component :is="group.icon" v-if="group.icon" class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
            {{ group.label }}
          </RouterLink>
        </DropdownMenuItem>
        <template v-else>
          <DropdownMenuLabel>{{ group.label }}</DropdownMenuLabel>
          <DropdownMenuItem v-for="item in group.items" :key="item.id" as-child>
            <RouterLink :to="item.to" class="flex items-center gap-2">
              <component :is="item.icon" v-if="item.icon" class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
              {{ item.label }}
            </RouterLink>
          </DropdownMenuItem>
        </template>
      </template>
    </DropdownMenuContent>
  </DropdownMenu>
</template>
