<script setup lang="ts">
import type { ThemePreference } from '@madsholme/themes'
import { ChevronDown, LogOut, ShieldCheck, User, UserCheck, UserCircle } from 'lucide-vue-next'
import { nextTick, ref } from 'vue'
import { RouterLink, type RouteLocationRaw } from 'vue-router'
import { Button } from '../components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../components/ui/dropdown-menu'
import type { ThemeChoice } from '../theme/icons'
import type { ShellUser } from '../types'
import ThemeQuickPicker from './ThemeQuickPicker.vue'

const props = withDefaults(defineProps<{
  user: ShellUser
  profileTo?: RouteLocationRaw
  themeChoices: readonly ThemeChoice[]
  themePreference: ThemePreference
  themeError?: string
  /** Show "Work as admin / user". */
  canToggleAdminMode?: boolean
  adminModeActive?: boolean
  adminModePending?: boolean
  /** Show "Impersonate user". */
  canImpersonate?: boolean
  logoutPending?: boolean
}>(), {
  profileTo: '/profile',
  themeError: '',
  canToggleAdminMode: false,
  adminModeActive: false,
  adminModePending: false,
  canImpersonate: false,
  logoutPending: false,
})

const emit = defineEmits<{
  'select-theme': [preference: ThemePreference]
  'toggle-admin-mode': []
  impersonate: []
  logout: []
}>()

const open = defineModel<boolean>('open', { default: false })
const trigger = ref<{ $el: HTMLButtonElement } | null>(null)
const impersonationItem = ref<HTMLButtonElement | null>(null)

// Opening the impersonation sheet while the menu's dismissable layer is still mounted can leave
// `body { pointer-events: none }` behind (SwiftDeploy). Wait for the menu's close-auto-focus.
let impersonateAfterClose = false

function requestImpersonation(): void {
  impersonateAfterClose = true
}

function onCloseAutoFocus(event: Event): void {
  if (!impersonateAfterClose) return
  impersonateAfterClose = false
  event.preventDefault()
  void nextTick(() => emit('impersonate'))
}

defineExpose({
  /** The profile trigger, for focus restoration. */
  triggerElement: () => trigger.value?.$el ?? null,
  impersonationElement: () => impersonationItem.value,
})
void props
</script>

<template>
  <!-- Non-modal: a menu needs no page-wide aria-hidden; Escape, Tab and outside clicks still close it. -->
  <DropdownMenu v-model:open="open" :modal="false">
    <DropdownMenuTrigger as-child>
      <Button
        ref="trigger"
        data-site-header-interactive
        data-slot="profile-menu-trigger"
        variant="ghost"
        size="sm"
        class="gap-1.5 text-sm font-normal"
      >
        <!-- The accessible name comes from the content, so it always contains the visible text (WCAG 2.5.3).
             Spaces sit inside spans: Vue drops whitespace-only nodes between elements. -->
        <User class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
        <span class="sr-only">User menu: </span>
        <span data-slot="profile-menu-name" class="sr-only sm:not-sr-only sm:max-w-[180px] sm:truncate">{{ user.name }}</span>
        <template v-if="adminModeActive">
          <span class="sr-only">, </span>
          <!-- Inherits the trigger's text colour, so it stays readable on the hover/open accent. -->
          <span
            data-slot="admin-mode-badge"
            class="rounded bg-warning/15 px-1.5 py-0.5 text-xs font-medium"
          >Admin mode</span>
        </template>
        <ChevronDown class="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
      </Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent
      id="profile-menu"
      data-testid="profile-menu"
      align="end"
      class="w-60"
      @close-auto-focus="onCloseAutoFocus"
    >
      <DropdownMenuLabel class="font-normal">
        <div data-slot="profile-menu-identity" class="flex flex-col gap-0.5">
          <span class="text-sm font-medium">{{ user.name }}</span>
          <span v-if="user.subtitle" class="text-xs text-muted-foreground">{{ user.subtitle }}</span>
        </div>
      </DropdownMenuLabel>
      <DropdownMenuSeparator />
      <ThemeQuickPicker
        :choices="themeChoices"
        :preference="themePreference"
        :error="themeError"
        @select="emit('select-theme', $event)"
      />
      <DropdownMenuSeparator />
      <template v-if="canToggleAdminMode">
        <DropdownMenuItem as-child :disabled="adminModePending" @select="emit('toggle-admin-mode')">
          <button type="button" data-test="toggle-admin-mode" class="flex w-full cursor-pointer items-center gap-2" :disabled="adminModePending">
            <ShieldCheck class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
            {{ adminModeActive ? 'Work as user' : 'Work as admin' }}
          </button>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
      </template>
      <DropdownMenuItem as-child>
        <RouterLink :to="profileTo" class="flex cursor-pointer items-center gap-2">
          <UserCircle class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
          My Profile
        </RouterLink>
      </DropdownMenuItem>
      <DropdownMenuItem v-if="canImpersonate" as-child @select="requestImpersonation">
        <button
          ref="impersonationItem"
          type="button"
          data-test="begin-impersonation"
          class="flex w-full cursor-pointer items-center gap-2"
          aria-haspopup="dialog"
          aria-controls="impersonation-dialog"
        >
          <UserCheck class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
          Impersonate user
        </button>
      </DropdownMenuItem>
      <slot name="items" />
      <DropdownMenuSeparator />
      <DropdownMenuItem as-child :disabled="logoutPending" @select="emit('logout')">
        <button type="button" data-test="logout" class="flex w-full cursor-pointer items-center gap-2" :disabled="logoutPending">
          <LogOut class="h-4 w-4" :stroke-width="1.75" aria-hidden="true" />
          {{ logoutPending ? 'Logging out…' : 'Log out' }}
        </button>
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
</template>
