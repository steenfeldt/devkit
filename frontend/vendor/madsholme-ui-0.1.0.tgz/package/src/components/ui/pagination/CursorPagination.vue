<script setup lang="ts">
import { computed } from 'vue'
import type { HTMLAttributes } from 'vue'
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-vue-next'
import { Button } from '../button'
import { cn } from '../../../lib/utils'
import { defaultPaginationLabels } from './context'
import type { PaginationLabels } from './context'

const props = defineProps<{
  hasPrevious: boolean
  hasNext: boolean
  summary?: string
  labels?: Pick<PaginationLabels, 'previous' | 'next' | 'navigation'>
  disabled?: boolean
  busy?: boolean
  previousAttrs?: HTMLAttributes & Record<string, unknown>
  nextAttrs?: HTMLAttributes & Record<string, unknown>
  class?: HTMLAttributes['class']
}>()
const emit = defineEmits<{ previous: []; next: [] }>()
const labels = computed(() => ({ ...defaultPaginationLabels, ...props.labels }))
function navigate(direction: 'previous' | 'next') {
  if (props.disabled || props.busy || !(direction === 'previous' ? props.hasPrevious : props.hasNext)) return
  if (direction === 'previous') emit('previous')
  else emit('next')
}
</script>

<template>
  <nav data-slot="cursor-pagination" :aria-label="labels.navigation" :aria-busy="busy || undefined"
    :class="cn('mx-auto flex w-full items-center justify-center gap-2', props.class)">
    <Button v-bind="previousAttrs" data-slot="cursor-pagination-previous" type="button" variant="ghost"
      class="gap-1 px-2.5" :aria-label="labels.previous" :disabled="disabled || busy || !hasPrevious" @click="navigate('previous')">
      <ChevronLeftIcon aria-hidden="true" /><span class="hidden sm:block">{{ labels.previous }}</span>
    </Button>
    <span v-if="summary" data-slot="cursor-pagination-summary" class="text-sm text-muted-foreground" aria-live="polite">{{ summary }}</span>
    <Button v-bind="nextAttrs" data-slot="cursor-pagination-next" type="button" variant="ghost"
      class="gap-1 px-2.5" :aria-label="labels.next" :disabled="disabled || busy || !hasNext" @click="navigate('next')">
      <span class="hidden sm:block">{{ labels.next }}</span><ChevronRightIcon aria-hidden="true" />
    </Button>
  </nav>
</template>
