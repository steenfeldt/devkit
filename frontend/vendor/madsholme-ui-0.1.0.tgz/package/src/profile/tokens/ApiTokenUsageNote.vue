<template>
  <p data-slot="api-token-usage-note" class="m-0 text-sm text-muted-foreground">
    Send your token in the <code class="text-xs">Authorization: Bearer &lt;token&gt;</code> header. Keep it private.
    Revoking a token stops future API requests using it.
  </p>
</template>
