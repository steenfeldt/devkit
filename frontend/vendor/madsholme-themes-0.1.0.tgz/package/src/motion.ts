/** Named, opt-in animation presets shipped by the themes CSS. */
export const motionPresets = [
  { name: 'fade-in', label: 'Fade in', category: 'enter', className: 'sd-animate-fade-in' },
  { name: 'fade-out', label: 'Fade out', category: 'exit', className: 'sd-animate-fade-out' },
  { name: 'slide-up', label: 'Slide up', category: 'enter', className: 'sd-animate-slide-up' },
  { name: 'slide-down', label: 'Slide down', category: 'enter', className: 'sd-animate-slide-down' },
  { name: 'slide-left', label: 'Slide left', category: 'enter', className: 'sd-animate-slide-left' },
  { name: 'slide-right', label: 'Slide right', category: 'enter', className: 'sd-animate-slide-right' },
  { name: 'exit-up', label: 'Exit up', category: 'exit', className: 'sd-animate-exit-up' },
  { name: 'exit-down', label: 'Exit down', category: 'exit', className: 'sd-animate-exit-down' },
  { name: 'exit-left', label: 'Exit left', category: 'exit', className: 'sd-animate-exit-left' },
  { name: 'exit-right', label: 'Exit right', category: 'exit', className: 'sd-animate-exit-right' },
  { name: 'scale-in', label: 'Scale in', category: 'enter', className: 'sd-animate-scale-in' },
  { name: 'scale-out', label: 'Scale out', category: 'exit', className: 'sd-animate-scale-out' },
  { name: 'blur-in', label: 'Blur in', category: 'enter', className: 'sd-animate-blur-in' },
  { name: 'blur-out', label: 'Blur out', category: 'exit', className: 'sd-animate-blur-out' },
  { name: 'reveal', label: 'Reveal', category: 'enter', className: 'sd-animate-reveal' },
  { name: 'conceal', label: 'Conceal', category: 'exit', className: 'sd-animate-conceal' },
  { name: 'shake', label: 'Shake', category: 'attention', className: 'sd-animate-shake' },
  { name: 'nod', label: 'Nod', category: 'attention', className: 'sd-animate-nod' },
  { name: 'bounce', label: 'Bounce', category: 'attention', className: 'sd-animate-bounce' },
  { name: 'pop', label: 'Pop', category: 'attention', className: 'sd-animate-pop' },
  { name: 'wiggle', label: 'Wiggle', category: 'attention', className: 'sd-animate-wiggle' },
  { name: 'ping', label: 'Ping', category: 'attention', className: 'sd-animate-ping' },
  { name: 'spin', label: 'Spin', category: 'loading', className: 'sd-animate-spin' },
  { name: 'pulse', label: 'Pulse', category: 'loading', className: 'sd-animate-pulse' },
] as const
export type MotionPreset = typeof motionPresets[number]
export type MotionPresetName = MotionPreset['name']
