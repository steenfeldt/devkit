<script setup lang="ts">
import { computed } from 'vue'
import type { GlobalNotice } from '../types'
import { shellContainerClass } from './classes'
import { noticeIcons, sortGlobalNotices } from './notifications'

const props = defineProps<{ notifications: readonly GlobalNotice[] }>()
const sorted = computed(() => sortGlobalNotices(props.notifications))
</script>

<template>
  <section v-if="sorted.length" data-slot="global-notification-banner" class="global-notification-banner" aria-label="Global notifications">
    <div
      v-for="notice in sorted"
      :key="notice.id"
      data-slot="global-notification"
      class="global-notification-banner__item"
      :class="`global-notification-banner__item--${notice.category}`"
    >
      <div :class="shellContainerClass">
        <div
          data-slot="global-notification-content"
          :role="notice.category === 'alert' ? 'alert' : 'status'"
          :aria-live="notice.category === 'alert' ? 'assertive' : 'polite'"
          class="global-notification-banner__content"
        >
          <span
            data-slot="global-notification-icon"
            class="global-notification-banner__icon"
            :class="[`global-notification-banner__icon--${notice.category}`, notice.category === 'information' ? 'dark:[color:oklch(0.7681_0.1246_231.73)]' : '']"
            aria-hidden="true"
          >
            <component :is="noticeIcons[notice.category]" class="h-4 w-4" :stroke-width="1.9" />
          </span>
          <p class="m-0 whitespace-pre-line text-sm font-medium leading-6">{{ notice.message }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
/* From SwiftDeploy b49e160 GlobalNotificationBanner.vue; the dark-theme colour moved to a Tailwind
 * `dark:` class, which covers every dark theme from the theme files (`tailwind-theme.css`). */
.global-notification-banner { border-bottom: 1px solid var(--border); }
.global-notification-banner__item { border-top: 1px solid transparent; border-bottom: 1px solid transparent; }
.global-notification-banner__content { display: flex; min-height: 2.75rem; align-items: flex-start; gap: 0.75rem; padding-top: 0.625rem; padding-bottom: 0.625rem; }
.global-notification-banner__icon { display: inline-flex; height: 1.75rem; width: 1.75rem; flex: 0 0 auto; align-items: center; justify-content: center; border-radius: calc(var(--radius) - 2px); }
.global-notification-banner__item--information { border-color: oklch(0.6777 0.1482 238.12 / 0.34); background: oklch(0.6777 0.1482 238.12 / 0.1); color: var(--foreground); }
.global-notification-banner__icon--information { border: 1px solid oklch(0.6777 0.1482 238.12 / 0.4); background: oklch(0.6777 0.1482 238.12 / 0.14); color: oklch(0.5271 0.1132 237.44); }
.global-notification-banner__item--warning { border-color: color-mix(in srgb, var(--warning) 40%, transparent); background: color-mix(in srgb, var(--warning) 13%, transparent); color: var(--foreground); }
.global-notification-banner__icon--warning { border: 1px solid color-mix(in srgb, var(--warning) 45%, transparent); background: color-mix(in srgb, var(--warning) 16%, transparent); color: var(--warning-foreground); }
.global-notification-banner__item--alert { border-color: color-mix(in srgb, var(--destructive) 42%, transparent); background: color-mix(in srgb, var(--destructive) 10%, transparent); color: var(--foreground); }
.global-notification-banner__icon--alert { border: 1px solid color-mix(in srgb, var(--destructive) 45%, transparent); background: color-mix(in srgb, var(--destructive) 14%, transparent); color: var(--destructive); }
</style>
