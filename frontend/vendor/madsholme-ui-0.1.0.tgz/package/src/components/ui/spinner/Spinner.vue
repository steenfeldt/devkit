<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { LoaderCircle } from 'lucide-vue-next'
import { cn } from '../../../lib/utils'

const props = defineProps<{
  class?: HTMLAttributes['class']
  decorative?: boolean
  label?: string
}>()
</script>

<template>
  <LoaderCircle
    data-slot="spinner"
    :role="decorative ? undefined : 'status'"
    :aria-label="decorative ? undefined : (label ?? 'Loading')"
    :aria-hidden="decorative ? true : undefined"
    :class="cn('size-4 animate-spin', props.class)"
  />
</template>
