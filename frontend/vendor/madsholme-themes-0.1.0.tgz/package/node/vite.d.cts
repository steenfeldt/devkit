export { themeBoot, type ThemeBootOptions } from '../src/vite'
