<script setup lang="ts">
import type { DialogContentEmits, DialogContentProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { useId } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import { X } from 'lucide-vue-next'
import {
  DialogClose,
  Primitive,
  injectDialogRootContext,
  DialogContent,
  DialogOverlay,
  DialogPortal,
  useForwardPropsEmits,
} from 'reka-ui'
import { cn } from '../../../lib/utils'
import { useDialogFocusReturn } from '../dialog/useDialogFocusReturn'
import { dialogContentClass, dialogOverlayClass } from './styles'

defineOptions({
  inheritAttrs: false,
})

const props = withDefaults(defineProps<DialogContentProps & {
  class?: HTMLAttributes['class']
  inline?: boolean
  showClose?: boolean
  closeLabel?: string
}>(), { showClose: true, closeLabel: 'Close' })
const emits = defineEmits<DialogContentEmits>()

const delegatedProps = reactiveOmit(props, 'class', 'showClose', 'closeLabel', 'inline')
const forwarded = useForwardPropsEmits(delegatedProps, emits)
const { rememberFocus, restoreFocus } = useDialogFocusReturn()
const context = injectDialogRootContext()
context.titleId ||= useId()
context.descriptionId ||= useId()
</script>

<template>
  <Primitive
    v-if="inline && (context.open.value || forceMount)"
    :as="as ?? 'section'"
    :as-child="asChild"
    :id="context.contentId"
    role="region"
    :aria-labelledby="context.titleId"
    :aria-describedby="context.descriptionId"
    :data-state="context.open.value ? 'open' : 'closed'"
    :hidden="!context.open.value"
    data-slot="dialog-content"
    :class="cn('[&_[data-slot=dialog-description]]:text-foreground relative grid w-full gap-4 rounded-2xl border border-border bg-background p-6 text-foreground', props.class)"
    v-bind="$attrs"
  >
    <slot />
    <DialogClose v-if="showClose" data-slot="dialog-close" class="absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100 focus-visible:outline-ring focus-visible:ring-2 focus-visible:ring-ring">
      <X class="h-4 w-4 text-muted-foreground" aria-hidden="true" />
      <span class="sr-only">{{ closeLabel }}</span>
    </DialogClose>
  </Primitive>
  <DialogPortal v-else-if="!inline">
    <DialogOverlay
      data-slot="dialog-overlay"
      :class="dialogOverlayClass"
    />
    <DialogContent
      data-slot="dialog-content"
      v-bind="{ ...forwarded, ...$attrs }"
      @open-auto-focus="rememberFocus"
      @close-auto-focus="restoreFocus"
      :class="cn(dialogContentClass, props.class)"
    >
      <slot />
      <DialogClose
        v-if="showClose"
        data-slot="dialog-close"
        class="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-hidden focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none"
      >
        <X class="h-4 w-4 text-muted-foreground" aria-hidden="true" />
        <span class="sr-only">{{ closeLabel }}</span>
      </DialogClose>
    </DialogContent>
  </DialogPortal>
</template>
