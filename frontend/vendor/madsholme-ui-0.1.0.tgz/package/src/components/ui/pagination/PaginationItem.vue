<script setup lang="ts">
import { usePaginationOptions } from "./context"
import { computed } from "vue"
import type { PaginationListItemProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import type { ButtonVariants } from "../button"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { PaginationListItem, injectPaginationRootContext } from "reka-ui"
import { buttonVariants } from "../button"

const props = withDefaults(defineProps<PaginationListItemProps & {
  size?: ButtonVariants["size"]
  class?: HTMLAttributes["class"]
  isActive?: boolean
}>(), {
  size: "icon",
})

const options = usePaginationOptions()
const context = injectPaginationRootContext()
const selected = computed(() => context.page.value === props.value)
const delegatedProps = reactiveOmit(props, "class", "size", "isActive")
</script>

<template>
  <PaginationListItem
    data-slot="pagination-item"
    v-bind="delegatedProps"
    :aria-label="options.labels.page(value)"
    :data-selected="options.selectedAttribute && selected ? 'true' : undefined"
    :class="cn(
      buttonVariants({
        variant: isActive ? 'outline' : 'ghost',
        size,
      }),
      props.class)"
  >
    <slot />
  </PaginationListItem>
</template>
