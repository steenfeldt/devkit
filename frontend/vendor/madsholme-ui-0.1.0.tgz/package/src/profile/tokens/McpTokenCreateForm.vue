<script setup lang="ts">
import { Bot, Loader2 } from 'lucide-vue-next'
import { computed, reactive, ref, useId, watch } from 'vue'
import { Badge } from '../../components/ui/badge'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { NativeSelect } from '../../components/ui/native-select'
import { formatTokenLifetime } from '../format'
import { mcpGrantLevelLabels } from '../mcp'
import type { McpGrantArea, McpGrantLevel, McpGrants, McpTokenLifetimes } from '../types'

const props = withDefaults(defineProps<{
  /** Only the areas this account may grant, in display order. */
  areas: readonly McpGrantArea[]
  lifetimes: McpTokenLifetimes
  /** Starting level per area key. Areas without one start with no access. */
  defaultGrants?: McpGrants
  pending?: boolean
  error?: string
  title?: string
  namePlaceholder?: string
  locale?: string
}>(), {
  defaultGrants: () => ({}),
  pending: false,
  error: '',
  title: 'Generate an MCP token',
  namePlaceholder: 'e.g. Codex on my laptop',
  locale: 'en-GB',
})

const emit = defineEmits<{ submit: [value: { name: string; grants: Record<string, McpGrantLevel> }] }>()
const id = useId()
const name = ref('')
const grants = reactive<Record<string, McpGrantLevel>>({})
// Areas usually arrive with the product's data; new areas get their default, existing choices stay.
watch(() => props.areas, (areas) => {
  for (const area of areas) grants[area.key] ??= props.defaultGrants[area.key] ?? 'none'
}, { immediate: true })

const selected = computed(() => Object.fromEntries(props.areas.map((area) => [area.key, grants[area.key] ?? 'none'])) as Record<string, McpGrantLevel>)
const hasWrite = computed(() => Object.values(selected.value).includes('read_write'))
const hasGrant = computed(() => Object.values(selected.value).some((level) => level !== 'none'))
const lifetime = computed(() => formatTokenLifetime(hasWrite.value ? props.lifetimes.write : props.lifetimes.readOnly, props.locale))
const canSubmit = computed(() => !props.pending && hasGrant.value && Boolean(name.value.trim()))

function submit(): void {
  if (!canSubmit.value) return
  emit('submit', { name: name.value.trim(), grants: { ...selected.value } })
}

defineExpose({
  reset: () => {
    name.value = ''
    for (const area of props.areas) grants[area.key] = props.defaultGrants[area.key] ?? 'none'
  },
})
</script>

<template>
  <Card class="[--muted-foreground:var(--sd-muted-card-foreground)]" data-slot="mcp-token-create-form">
    <CardHeader>
      <CardTitle as="h2" class="flex items-center gap-2"><Bot class="h-5 w-5" aria-hidden="true" /> {{ title }}</CardTitle>
      <CardDescription>
        <slot name="description">
          Read-only tokens expire {{ formatTokenLifetime(lifetimes.readOnly, locale) }} after creation. Any read/write grant shortens this to
          {{ formatTokenLifetime(lifetimes.write, locale) }}. Grants cannot be changed later.
        </slot>
      </CardDescription>
    </CardHeader>
    <CardContent>
      <form class="flex flex-col gap-5" @submit.prevent.stop="submit">
        <div class="flex flex-col gap-2">
          <label :for="`mcp-token-name-${id}`" class="text-sm font-medium">Token name</label>
          <Input :id="`mcp-token-name-${id}`" v-model="name" maxlength="100" required autocomplete="off" :placeholder="namePlaceholder" :disabled="pending" :aria-invalid="Boolean(error)" />
        </div>
        <fieldset class="m-0 flex min-w-0 flex-col gap-2 border-0 p-0">
          <legend class="mb-2 p-0 text-sm font-medium">Access</legend>
          <div class="divide-y divide-border rounded-lg border border-border">
            <div v-for="area in areas" :key="area.key" class="flex flex-col gap-3 p-3 sm:flex-row sm:items-center sm:justify-between">
              <div class="min-w-0">
                <label :for="`mcp-grant-${area.key}-${id}`" class="text-sm font-medium">{{ area.label }}</label>
                <p v-if="area.description" :id="`mcp-grant-${area.key}-help-${id}`" class="m-0 text-xs text-muted-foreground">{{ area.description }}</p>
              </div>
              <NativeSelect
                :id="`mcp-grant-${area.key}-${id}`"
                v-model="grants[area.key]"
                class="sm:w-44"
                :disabled="pending"
                :aria-describedby="area.description ? `mcp-grant-${area.key}-help-${id}` : undefined"
              >
                <option v-for="(label, value) in mcpGrantLevelLabels" :key="value" :value="value">{{ label }}</option>
              </NativeSelect>
            </div>
          </div>
        </fieldset>
        <p role="status" class="m-0 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
          <Badge :variant="hasWrite ? 'default' : 'secondary'">{{ hasWrite ? 'Write lifetime' : 'Read-only lifetime' }}</Badge>
          This token will expire after {{ lifetime }}.
        </p>
        <p v-if="error" role="alert" class="m-0 text-sm text-destructive">{{ error }}</p>
        <Button type="submit" class="self-start" :disabled="!canSubmit">
          <Loader2 v-if="pending" class="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
          {{ pending ? 'Generating…' : 'Generate MCP token' }}
        </Button>
      </form>
    </CardContent>
  </Card>
</template>
