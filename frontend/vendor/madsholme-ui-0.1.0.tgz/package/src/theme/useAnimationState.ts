import type { AnimationController } from '@madsholme/themes'
import { computed, getCurrentScope, onScopeDispose, readonly, shallowRef } from 'vue'

/** Reactive view of the product-owned animation controller. */
export function useAnimationState(controller: AnimationController) {
  const state = shallowRef(controller.getState())
  const stop = controller.subscribe((next) => { state.value = next })
  if (getCurrentScope()) onScopeDispose(stop)
  return {
    state: readonly(state),
    enabled: computed(() => state.value.enabled),
    saving: computed(() => state.value.saving),
    saveError: computed(() => state.value.saveError),
    select: controller.select,
  }
}
