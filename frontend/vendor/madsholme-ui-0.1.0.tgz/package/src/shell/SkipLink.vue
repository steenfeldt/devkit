<script setup lang="ts">
withDefaults(defineProps<{ target?: string; label?: string }>(), { target: '#main-content', label: 'Skip to main content' })
</script>

<template>
  <a
    data-slot="skip-link"
    :href="target"
    class="sd-skip-link fixed left-2 top-2 z-[100] -translate-y-[200%] rounded-lg border-2 border-ring bg-popover px-4 py-3 text-sm font-medium text-popover-foreground focus:translate-y-0"
  >{{ label }}</a>
</template>
