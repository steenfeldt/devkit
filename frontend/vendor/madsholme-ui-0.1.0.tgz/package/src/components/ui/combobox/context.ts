import type { ComputedRef, InjectionKey } from 'vue'
export const comboboxOptionsKey: InjectionKey<{
  clearOnReselect: ComputedRef<boolean>
  loop: ComputedRef<boolean>
  maxResults: ComputedRef<number | undefined>
}> = Symbol('combobox-options')
