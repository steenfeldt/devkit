<script setup lang="ts">
import { shellContainerClass } from '../shell/classes'

withDefaults(defineProps<{ eyebrow?: string; title?: string; description?: string; contained?: boolean }>(), {
  contained: true,
  eyebrow: 'Account',
  title: 'My Profile',
  description: 'Your account details and preferences.',
})
</script>

<template>
  <div data-slot="profile-page" :class="contained ? [shellContainerClass, 'py-6'] : undefined">
    <div data-slot="profile-page-heading" class="mb-8">
      <p class="mb-1 mt-0 text-xs font-semibold uppercase tracking-widest text-primary">{{ eyebrow }}</p>
      <h1 class="sd-page-title m-0 text-[1.875rem] leading-tight">{{ title }}</h1>
      <p class="mb-0 mt-1 text-sm text-muted-foreground">{{ description }}</p>
    </div>
    <slot name="status" />
    <div data-slot="profile-page-columns" class="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <div data-slot="profile-page-main" class="space-y-6 lg:col-span-3"><slot name="main" /></div>
      <div data-slot="profile-page-aside" class="space-y-6 lg:col-span-2"><slot name="aside" /></div>
    </div>
  </div>
</template>
