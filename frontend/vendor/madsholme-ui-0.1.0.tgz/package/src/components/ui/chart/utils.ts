import type { Component } from 'vue'
import type { ChartConfig } from '.'
import { h, render } from 'vue'

/** Adapt a Vue tooltip to Unovis' HTML callback, disposing each temporary render.
 * Read config on every call so live themes/data do not leave stale cached tooltips. */
export function componentToString(config: ChartConfig, component: Component, props: Record<string, unknown> = {}) {
  return (input: unknown, x: number | Date) => {
    if (typeof document === 'undefined') return ''
    const record = input && typeof input === 'object' ? input as Record<string, unknown> : {}
    const payload = record.data && typeof record.data === 'object' ? record.data : record
    const div = document.createElement('div')
    render(h(component, { ...props, payload, config, x }), div)
    const html = div.innerHTML
    render(null, div)
    return html
  }
}
