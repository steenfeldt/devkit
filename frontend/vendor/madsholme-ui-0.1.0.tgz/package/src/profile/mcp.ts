import type { McpClientExample, McpGrantArea, McpGrantLevel, McpGrants } from './types'

export const mcpGrantLevelLabels: Readonly<Record<McpGrantLevel, string>> = {
  none: 'No access',
  read: 'Read only',
  read_write: 'Read/write',
}

export interface McpGrantBadge {
  readonly key: string
  readonly label: string
  /** A read/write grant; shown emphasised. */
  readonly write: boolean
}

/** One badge per granted area, in area order. Areas without access are left out. */
export function mcpGrantBadges(areas: readonly McpGrantArea[], grants: McpGrants): McpGrantBadge[] {
  return areas.flatMap((area) => {
    const level = grants[area.key] ?? 'none'
    return level === 'none' ? [] : [{ key: area.key, label: `${area.shortLabel}: ${mcpGrantLevelLabels[level]}`, write: level === 'read_write' }]
  })
}

export interface McpClientExampleOptions {
  readonly endpoint: string
  /** The MCP server key in client configuration, e.g. `swiftconfig`. */
  readonly serverName: string
  /** The environment variable that holds the token, e.g. `SWIFTCONFIG_MCP_TOKEN`. */
  readonly envVar: string
}

/** Codex, Claude Code and OpenAI configuration. The examples never contain a token. */
export function buildMcpClientExamples({ endpoint, serverName, envVar }: McpClientExampleOptions): [McpClientExample, McpClientExample, McpClientExample] {
  const url = JSON.stringify(endpoint)
  const shellName = /^[a-zA-Z0-9_-]+$/.test(serverName) ? serverName : "'" + serverName.replace(/'/g, "'\\''") + "'"
  return [
    {
      id: 'codex',
      label: 'Codex',
      oauthSnippets: [
        {
          title: 'config.toml — browser OAuth',
          description: 'Add this server to config.toml, then run the login command below. When switching from a manual token, replace that server entry and remove bearer_token_env_var and Authorization headers.',
          code: `[mcp_servers.${serverName}]\nurl = ${url}`,
        },
        {
          title: 'Terminal — sign in with Codex',
          description: 'Complete product sign-in and approve MCP access in the browser. Codex manages the issued product MCP token. Sign in again when it expires.',
          code: `codex mcp login ${shellName}`,
        },
      ],
      snippets: [
        {
          title: 'config.toml — token from an environment variable',
          description: `Set ${envVar} in Codex’s environment before starting it, then add this to config.toml.`,
          code: `[mcp_servers.${serverName}]\nurl = ${url}\nbearer_token_env_var = "${envVar}"`,
        },
        {
          title: 'config.toml — token stored in the file',
          description: [
            'Replace YOUR_MCP_TOKEN with your token. Use either this or bearer_token_env_var, not both; bearer_token_env_var expects an environment variable name, not the token itself.',
            'Keep this file private. Restart Codex after changing it, and replace the token when it expires.',
          ],
          code: `[mcp_servers.${serverName}]\nurl = ${url}\nhttp_headers = { Authorization = "Bearer YOUR_MCP_TOKEN" }`,
        },
      ],
    },
    {
      id: 'claude',
      label: 'Claude Code',
      oauthSnippets: [{
        title: '.mcp.json — browser OAuth',
        description: [
          'Merge this server entry into .mcp.json. When switching from a manual token, replace that entry and remove its Authorization header.',
          'Open Claude Code, run /mcp, select this server and authenticate. Complete product sign-in and approve MCP access in the browser. Claude Code manages the issued product MCP token; authenticate again when it expires.',
        ],
        code: JSON.stringify({ mcpServers: { [serverName]: { type: 'http', url: endpoint } } }, null, 2),
      }],
      snippets: [{
        title: '.mcp.json',
        description: `Set ${envVar} in the environment and merge this into .mcp.json.`,
        code: JSON.stringify({ mcpServers: { [serverName]: { type: 'http', url: endpoint, headers: { Authorization: `Bearer \${${envVar}}` } } } }, null, 2),
      }],
    },
    {
      id: 'openai',
      label: 'OpenAI',
      snippets: [{
        title: 'Responses API tool',
        description: 'Supply the token from secure storage on each request. The endpoint must be reachable by OpenAI.',
        code: JSON.stringify({ type: 'mcp', server_label: serverName, server_url: endpoint, authorization: '<your MCP token>', require_approval: 'always' }, null, 2),
      }],
    },
  ]
}
