<script setup lang="ts">
import { computed, ref, useId, watch } from 'vue'
import { parseDate, parseDateTime, type DateValue } from '@internationalized/date'
import { CalendarDays } from 'lucide-vue-next'
import { Button } from '../button'
import { Calendar } from '../calendar'
import { Input } from '../input'
import { Popover, PopoverContent, PopoverTrigger } from '../popover'
import { instantToLocal, localToInstant, validateLocalDateTime } from './date-time'

export interface DateTimePickerLabels {
  placeholder?: string
  time?: string
  clear?: string
  done?: string
  previousMonth?: string
  nextMonth?: string
  invalid?: string
  bounds?: string
}
const props = withDefaults(defineProps<{
  modelValue?: string | null
  label: string
  /** IANA timezone, e.g. Europe/Copenhagen or UTC. Values are ISO instants with offsets. */
  timeZone?: string
  valueMode?: 'instant' | 'local'
  hideLabel?: boolean
  showTimeZone?: boolean
  locale: string
  name?: string
  disabled?: boolean
  min?: string
  max?: string
  labels?: DateTimePickerLabels
}>(), { modelValue: null, valueMode: 'instant', showTimeZone: true, labels: () => ({}) })
const emit = defineEmits<{ 'update:modelValue': [value: string | null]; invalid: [reason: string] }>()
const configurationValid = computed(() => {
  try {
    if (props.valueMode === 'instant' && !props.timeZone) return false
    new Intl.DateTimeFormat(props.locale, { timeZone: props.valueMode === 'local' ? 'UTC' : props.timeZone }); return true
  }
  catch { return false }
})
const id = useId()
const open = ref(false)
const draft = ref('')
const error = ref('')
const words = computed(() => ({
  placeholder: 'Pick date and time', time: 'Time', clear: 'Clear', done: 'Done',
  previousMonth: 'Previous month', nextMonth: 'Next month',
  invalid: props.valueMode === 'local' ? 'Choose a valid local date and time.' : 'Choose a valid date and time. This local time may not exist or may occur twice in the selected timezone.',
  bounds: 'Choose a date and time within the allowed range.', ...props.labels,
}))
const zoneVisible = computed(() => props.showTimeZone && props.valueMode === 'instant')
watch(() => [props.modelValue, props.timeZone, props.valueMode], () => {
  const value = props.modelValue ? (props.valueMode === 'local' ? (validateLocalDateTime(props.modelValue).error ? null : props.modelValue) : instantToLocal(props.modelValue, props.timeZone ?? '')) : ''
  draft.value = value ?? ''
  error.value = value === null ? words.value.invalid : ''
}, { immediate: true })
watch(() => props.disabled, disabled => { if (disabled) open.value = false })
const date = computed<DateValue | undefined>(() => {
  try { return draft.value ? parseDate(draft.value.slice(0, 10)) : undefined } catch { return undefined }
})
const time = computed(() => draft.value.slice(11, 16) || '00:00')
const display = computed(() => {
  if (!props.modelValue) return words.value.placeholder
  try {
    const local = props.valueMode === 'local'
    const value = local ? parseDateTime(props.modelValue).toDate('UTC') : new Date(props.modelValue)
    return new Intl.DateTimeFormat(props.locale, { dateStyle: 'medium', timeStyle: 'short', timeZone: local ? 'UTC' : props.timeZone }).format(value)
  } catch { return props.modelValue }
})
function commit(value: string) {
  if (props.disabled) return
  draft.value = value
  const result = props.valueMode === 'local' ? validateLocalDateTime(value, props.min, props.max) : localToInstant(value, props.timeZone ?? '', props.min, props.max)
  error.value = result.error ? (result.error === 'bounds' ? words.value.bounds : words.value.invalid) : ''
  if (result.error) emit('invalid', result.error)
  else emit('update:modelValue', result.value!)
}
function setDate(value: DateValue | undefined) {
  if (value) commit(`${value.toString().slice(0, 10)}T${time.value}`)
}
function clear() {
  if (props.disabled) return
  draft.value = ''; error.value = ''; open.value = false
  emit('update:modelValue', null)
}
</script>

<template>
  <div data-slot="date-time-picker" class="ui-date-time-picker grid min-w-0 gap-2">
    <label :for="`${id}-trigger`" class="text-sm font-medium" :class="hideLabel && 'sr-only'">{{ label }}</label>
    <input v-if="name" type="hidden" :name="name" :value="modelValue ?? ''" :disabled="disabled">
    <Popover v-model:open="open">
      <PopoverTrigger as-child>
        <Button :id="`${id}-trigger`" type="button" variant="outline" :disabled="disabled || !configurationValid" class="h-auto min-h-10 w-full justify-start whitespace-normal text-left font-normal" :aria-invalid="Boolean(error)" :aria-describedby="[zoneVisible && `${id}-zone`, error && `${id}-error`].filter(Boolean).join(' ') || undefined">
          <CalendarDays class="size-4 shrink-0" aria-hidden="true" /><span>{{ display }}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent :label="label" align="start" class="w-auto p-0">
        <Calendar :model-value="date" :locale="configurationValid ? locale : 'en-GB'" :prev-label="words.previousMonth" :next-label="words.nextMonth" :disabled="disabled" @update:model-value="setDate" />
        <div class="grid gap-2 border-t p-3">
          <label :for="`${id}-time`" class="text-sm font-medium">{{ words.time }}<template v-if="zoneVisible"> · {{ timeZone }}</template></label>
          <Input :id="`${id}-time`" type="time" :model-value="time" :disabled="disabled || !date" :aria-invalid="Boolean(error)" @update:model-value="commit(`${draft.slice(0, 10)}T${$event}`)" />
          <p v-if="error" role="alert" class="text-sm text-foreground">{{ error }}</p>
          <div class="flex justify-between gap-2">
            <Button type="button" variant="ghost" size="sm" :disabled="disabled" @click="clear">{{ words.clear }}</Button>
            <Button type="button" size="sm" @click="open = false">{{ words.done }}</Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
    <p v-if="!configurationValid" role="alert" class="text-sm text-foreground">{{ words.invalid }}</p>
    <p v-if="zoneVisible" :id="`${id}-zone`" class="text-xs text-muted-foreground">{{ timeZone }}</p>
    <p v-if="error" :id="`${id}-error`" role="alert" class="text-sm text-foreground">{{ error }}</p>
  </div>
</template>
