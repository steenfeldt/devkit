<script setup lang="ts">
import { ShieldAlert } from 'lucide-vue-next'
import { ref } from 'vue'
import { Button } from '../components/ui/button'
import { shellContainerClass } from '../shell/classes'
import type { ImpersonationParty } from '../types'

const props = withDefaults(defineProps<{
  /** The user whose access is in use. */
  effective: ImpersonationParty
  /** The user who started impersonating. */
  actor: ImpersonationParty
  pending?: boolean
  error?: string
}>(), { pending: false, error: '' })

defineEmits<{ stop: [] }>()

const stopButton = ref<{ $el: HTMLButtonElement } | null>(null)

/** Moves focus to the stop action (after an actor change without a page reload). */
function focusStopAction(): boolean {
  const button = stopButton.value?.$el
  if (!button || button.disabled) return false
  button.focus()
  return document.activeElement === button
}

defineExpose({ focusStopAction })
void props
</script>

<template>
  <section
    data-slot="impersonation-banner"
    class="impersonation-banner dark:[background:linear-gradient(90deg_in_srgb,color-mix(in_srgb,var(--warning)_18%,transparent),color-mix(in_srgb,var(--primary)_12%,transparent)),color-mix(in_srgb,var(--background)_92%,transparent)]"
    aria-label="Impersonation active"
  >
    <div :class="[shellContainerClass, 'flex flex-col gap-3 py-2.5 text-sm sm:flex-row sm:items-center sm:justify-between']">
      <div data-slot="impersonation-banner-status" role="status" class="flex min-w-0 flex-1 flex-wrap items-center gap-x-2 gap-y-1.5">
        <span class="impersonation-banner__icon" aria-hidden="true">
          <ShieldAlert class="h-4 w-4" :stroke-width="1.8" />
        </span>
        <!-- Spaces live inside the spans: Vue drops whitespace-only nodes between elements, which would run
             the words together for screen readers ("Acting asalice"). -->
        <span class="font-medium">Acting as </span>
        <span class="impersonation-banner__user impersonation-banner__user--target"><span class="truncate">{{ effective.name }}</span></span>
        <span class="impersonation-banner__role"> (Started by </span>
        <span class="impersonation-banner__user impersonation-banner__user--real"><span class="truncate">{{ actor.name }}</span></span><span class="impersonation-banner__role -ml-2">)</span>
      </div>
      <Button
        ref="stopButton"
        size="sm"
        variant="outline"
        class="impersonation-banner__button w-full shrink-0 sm:w-auto"
        data-testid="stop-impersonation"
        :aria-label="`End impersonation of ${effective.name}`"
        :disabled="pending"
        @click="$emit('stop')"
      >
        {{ pending ? 'Ending…' : 'End impersonation' }}
      </Button>
    </div>
    <p v-if="error" data-slot="impersonation-banner-error" role="alert" :class="[shellContainerClass, 'm-0 pb-2.5 text-sm font-medium text-destructive']">
      {{ error }}
    </p>
  </section>
</template>

<style scoped>
/* From SwiftDeploy b49e160 ImpersonationBanner.vue; the dark-theme background moved to a Tailwind `dark:`
 * class, which covers every dark theme from the theme files (`tailwind-theme.css`). */
.impersonation-banner {
  border-bottom: 1px solid color-mix(in srgb, var(--warning) 42%, transparent);
  background: linear-gradient(90deg in srgb, color-mix(in srgb, var(--warning) 16%, transparent), color-mix(in srgb, var(--primary) 9%, transparent)), color-mix(in srgb, var(--background) 96%, transparent);
  color: var(--foreground);
  box-shadow: inset 0 1px 0 color-mix(in srgb, var(--background) 58%, transparent);
}
.impersonation-banner__icon {
  display: inline-flex; height: 1.75rem; width: 1.75rem; flex: 0 0 auto; align-items: center; justify-content: center;
  border: 1px solid color-mix(in srgb, var(--warning) 38%, transparent); border-radius: calc(var(--radius) - 2px);
  background: color-mix(in srgb, var(--warning) 16%, transparent); color: var(--foreground);
}
.impersonation-banner__role { color: var(--muted-foreground); }
.impersonation-banner__user {
  display: inline-flex; min-width: 0; max-width: min(18rem, 100%); align-items: center;
  border-radius: calc(var(--radius) - 2px); border: 1px solid color-mix(in srgb, var(--border) 78%, transparent);
  padding: 0.125rem 0.5rem; font-weight: 650; line-height: 1.35;
}
.impersonation-banner__user--target { border-color: color-mix(in srgb, var(--warning) 45%, transparent); background: color-mix(in srgb, var(--warning) 14%, transparent); }
.impersonation-banner__user--real { border-color: color-mix(in srgb, var(--primary) 34%, transparent); background: color-mix(in srgb, var(--primary) 10%, transparent); }
.impersonation-banner__button { border-color: color-mix(in srgb, var(--warning) 48%, transparent) !important; background: color-mix(in srgb, var(--background) 72%, transparent) !important; color: var(--foreground) !important; }
.impersonation-banner__button:hover { background: color-mix(in srgb, var(--warning) 16%, transparent) !important; }
</style>
