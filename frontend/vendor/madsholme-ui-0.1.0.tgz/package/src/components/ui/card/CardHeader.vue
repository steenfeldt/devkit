<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{ class?: HTMLAttributes['class'] }>(), { class: undefined })
</script>

<template>
  <div
    data-slot="card-header"
    :class="cn('ui-card-header flex flex-col gap-y-1.5 p-6', props.class)"
  >
    <slot />
  </div>
</template>
