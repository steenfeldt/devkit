<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{ as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'; class?: HTMLAttributes['class'] }>(), { as: 'h3', class: undefined })
</script>

<template>
  <component
    :is="props.as"
    data-slot="card-title"
    :class="cn('ui-card-title m-0 text-2xl font-semibold leading-none tracking-tight', props.class)"
  >
    <slot />
  </component>
</template>
