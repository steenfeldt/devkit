<script setup lang="ts">
import { Check, Copy, KeyRound } from 'lucide-vue-next'
import { ref } from 'vue'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { formatTokenDate } from '../format'
import type { GeneratedApiToken } from '../types'

const props = withDefaults(defineProps<{
  token: GeneratedApiToken
  dismissLabel?: string
  /** The secret input's accessible name. */
  secretLabel?: string
  locale?: string
  timeZone?: string
}>(), { dismissLabel: 'I’ve saved my token', secretLabel: 'Generated API token', locale: 'en-GB', timeZone: 'Europe/Copenhagen' })

const emit = defineEmits<{ dismiss: []; copied: []; 'copy-failed': [] }>()
const copied = ref(false)
const status = ref('')

async function copyToken(): Promise<void> {
  try {
    await navigator.clipboard.writeText(props.token.secret)
    copied.value = true
    status.value = 'Token copied to the clipboard.'
    emit('copied')
  } catch {
    status.value = 'Could not copy. Select the token and copy it manually.'
    emit('copy-failed')
  }
}
</script>

<template>
  <Card data-slot="generated-token" class="border-primary/40">
    <CardHeader>
      <CardTitle as="h2" class="flex items-center gap-2"><KeyRound class="h-5 w-5" aria-hidden="true" /> Copy your token</CardTitle>
      <CardDescription>Save it somewhere secure now. You cannot view it again after leaving or dismissing this page.</CardDescription>
    </CardHeader>
    <CardContent class="flex flex-col gap-4">
      <div class="flex flex-col gap-2 sm:flex-row">
        <Input
          :model-value="token.secret"
          readonly
          data-testid="created-api-token"
          :aria-label="secretLabel"
          autocomplete="off"
          spellcheck="false"
          class="min-w-0 flex-1 font-mono"
        />
        <Button type="button" variant="outline" @click="copyToken">
          <component :is="copied ? Check : Copy" class="mr-2 h-4 w-4" aria-hidden="true" />{{ copied ? 'Copied' : 'Copy token' }}
        </Button>
      </div>
      <p role="status" aria-live="polite" class="m-0 min-h-0 text-sm" :class="status ? 'text-muted-foreground' : 'sr-only'">{{ status }}</p>
      <p class="m-0 text-sm text-muted-foreground">{{ token.name }} · Expires {{ formatTokenDate(token.expiresAt, { locale, timeZone }) }} (Copenhagen)</p>
      <Button type="button" variant="secondary" class="self-start" @click="$emit('dismiss')">{{ dismissLabel }}</Button>
    </CardContent>
  </Card>
</template>
