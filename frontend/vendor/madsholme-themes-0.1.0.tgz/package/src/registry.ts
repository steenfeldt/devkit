/**
 * The theme registry: the single definition of every supported theme.
 *
 * `scheme` drives `darkThemeKeys`, the Tailwind `dark:` selector and the dark selector lists in
 * the polish layer (see scripts/sync-dark-selectors.ts). `surface` describes the page and header
 * surfaces so brand marks can pick a legible variant.
 */

export type ThemeScheme = 'light' | 'dark'
/** `neutral`: a coloured header that needs the brand mark on a neutral chip. */
export type HeaderTone = 'light' | 'dark' | 'neutral'

export interface ThemeSurface {
  readonly page: ThemeScheme
  readonly header: HeaderTone
}

export interface ThemeDefinition {
  readonly key: string
  readonly label: string
  readonly scheme: ThemeScheme
  readonly surface: ThemeSurface
}

/** All themes, in profile-picker order. */
export const themes = [
  { key: 'light', label: 'Light', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'dark', label: 'Dark', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'dim', label: 'Dim', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'magic-mike', label: 'Magic Mike', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'rn', label: 'RN', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'rn-light', label: 'RN Light', scheme: 'light', surface: { page: 'light', header: 'dark' } },
  { key: 'sw-light', label: 'SW Light', scheme: 'light', surface: { page: 'light', header: 'neutral' } },
  { key: 'alex', label: 'Alex', scheme: 'light', surface: { page: 'light', header: 'neutral' } },
  { key: 'midnight-mirage', label: 'Midnight', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'solar-bloom', label: 'Solar', scheme: 'light', surface: { page: 'light', header: 'neutral' } },
  { key: 'cyberpunk', label: 'Cyberpunk', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'matrix', label: 'Matrix', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'orbital-light', label: 'Orbital', scheme: 'light', surface: { page: 'light', header: 'dark' } },
  { key: 'tron-light', label: 'Tron Light', scheme: 'light', surface: { page: 'light', header: 'dark' } },
  { key: 'nova-drift', label: 'Nova Drift', scheme: 'light', surface: { page: 'light', header: 'dark' } },
  { key: 'rose-pine', label: 'Rose Pine', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'rose-pine-dawn', label: 'Rose Pine Dawn', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'cosmic-light', label: 'Cosmic Light', scheme: 'light', surface: { page: 'light', header: 'dark' } },
  { key: 'ember', label: 'Ember', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'night-shift', label: 'Night Shift', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'catppuccin', label: 'Catppuccin Mocha', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'catppuccin-latte', label: 'Catppuccin Latte', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'gruvbox-material-dark', label: 'Gruvbox Material Dark', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'gruvbox-material-light', label: 'Gruvbox Material Light', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'graphite', label: 'Graphite', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'sage', label: 'Sage', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'pink', label: 'Hot Pink', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'soft-pink', label: 'Soft Pink', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'aurora', label: 'Aurora', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'high-contrast', label: 'High Contrast', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'signal', label: 'High Contrast Dark', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'colorblind', label: 'Colour-blind Safe Light', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'colorblind-dark', label: 'Colour-blind Safe Dark', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'nord', label: 'Nord', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'solarized-light', label: 'Solarized Light', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'solarized-dark', label: 'Solarized Dark', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'ink', label: 'Ink', scheme: 'light', surface: { page: 'light', header: 'light' } },
  { key: 'tokyo-night', label: 'Tokyo Night', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
  { key: 'dracula', label: 'Dracula', scheme: 'dark', surface: { page: 'dark', header: 'dark' } },
] as const satisfies readonly ThemeDefinition[]

export type ThemeKey = (typeof themes)[number]['key']

export const themeKeys: readonly ThemeKey[] = themes.map((theme) => theme.key)

const themeByKey = new Map<ThemeKey, ThemeDefinition>(themes.map((theme) => [theme.key, theme]))

/** Looks up a theme definition. */
export function getTheme(key: ThemeKey): ThemeDefinition {
  const theme = themeByKey.get(key)
  if (!theme) throw new RangeError(`Unknown theme: ${String(key)}`)
  return theme
}

/**
 * Themes with dark page surfaces that are selected with `data-theme`. `dark` itself is not
 * listed: it uses the `.dark` class. The order follows the registry and is not part of the API.
 */
export const darkThemeKeys: readonly ThemeKey[] = themes
  .filter((theme) => theme.scheme === 'dark' && theme.key !== 'dark')
  .map((theme) => theme.key)

/** True for every theme with dark page surfaces, including `dark`. */
export function isDarkTheme(key: ThemeKey): boolean {
  return getTheme(key).scheme === 'dark'
}

export const themeSurfaces: Readonly<Record<ThemeKey, ThemeSurface>> = Object.fromEntries(
  themes.map((theme) => [theme.key, theme.surface]),
) as Record<ThemeKey, ThemeSurface>

/** "Match system": a preference that resolves to a light or dark theme from the OS setting. */
export const systemPreference = 'system'
export type SystemPreference = typeof systemPreference
export type ThemePreference = ThemeKey | SystemPreference

export interface SystemThemes {
  readonly light: ThemeKey
  readonly dark: ThemeKey
}

/** The RN pair: RN Light for a light OS setting, RN for a dark one. */
export const defaultSystemThemes: SystemThemes = { light: 'rn-light', dark: 'rn' }

/** Used when nothing has been chosen: no cached value and no theme in the profile. */
export const defaultPreference: ThemePreference = systemPreference
