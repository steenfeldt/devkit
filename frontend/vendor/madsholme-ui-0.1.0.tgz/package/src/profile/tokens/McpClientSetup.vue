<script setup lang="ts">
import { Check, Copy } from 'lucide-vue-next'
import { computed, onUnmounted, ref } from 'vue'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import McpClientExampleTabs from './McpClientExampleTabs.vue'
import type { McpBrowserOAuth, McpClientExample } from '../types'

const props = withDefaults(defineProps<{
  endpoint: string
  examples: readonly McpClientExample[]
  title?: string
  oauth?: McpBrowserOAuth | null
}>(), { title: 'Connect your MCP client' })

const emit = defineEmits<{ copied: []; 'copy-failed': [] }>()
const oauthExamples = computed(() => props.examples.flatMap(example => example.oauthSnippets?.length
  ? [{ ...example, snippets: example.oauthSnippets }]
  : []))
const copied = ref('')
const status = ref('')
let clearCopied: ReturnType<typeof setTimeout> | undefined
onUnmounted(() => clearTimeout(clearCopied))
const paragraphs = (description?: string | readonly string[]) => description === undefined ? [] : typeof description === 'string' ? [description] : description

async function copy(code: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(code)
    copied.value = code
    status.value = 'Copied to the clipboard.'
    clearTimeout(clearCopied)
    clearCopied = setTimeout(() => { copied.value = '' }, 2000)
    emit('copied')
  } catch {
    copied.value = ''
    status.value = 'Could not copy. Select the endpoint or example and copy it manually.'
    emit('copy-failed')
  }
}
</script>

<template>
  <Card class="[--muted-foreground:var(--sd-muted-card-foreground)]" data-slot="mcp-client-setup">
    <CardHeader>
      <CardTitle as="h2">{{ title }}</CardTitle>
      <CardDescription>
        <slot name="description">
          Use the MCP endpoint below to connect your client.
        </slot>
      </CardDescription>
    </CardHeader>
    <CardContent class="flex min-w-0 flex-col gap-4">
      <div class="flex min-w-0 items-center gap-3 rounded-lg border border-input p-3">
        <div class="min-w-0 flex-1">
          <p class="m-0 text-sm font-medium">MCP endpoint</p>
          <code class="break-all text-xs">{{ endpoint }}</code>
        </div>
        <Button type="button" size="icon-sm" variant="ghost" class="shrink-0" aria-label="Copy MCP endpoint" @click="copy(endpoint)">
          <component :is="copied === endpoint ? Check : Copy" aria-hidden="true" />
        </Button>
      </div>
      <section v-if="oauth?.enabled === true" class="flex min-w-0 flex-col gap-3" aria-label="Browser sign-in">
        <h3 class="m-0 text-base font-semibold">Browser sign-in</h3>
        <ol class="m-0 list-decimal space-y-1 pl-5 text-sm">
          <li>Connect from your MCP client using the endpoint above.</li>
          <li>Sign in to the product with {{ oauth.loginProviderLabel }}.</li>
          <li>Review the requested MCP access and approve it.</li>
          <li>Your client receives a product MCP token.</li>
        </ol>
        <p class="m-0 text-sm text-muted-foreground">No manual token generation is needed for browser OAuth. You can revoke issued tokens from your profile.</p>
        <p v-if="oauthExamples.length" class="m-0 text-sm text-muted-foreground">Choose the browser OAuth or manual token configuration for a server, not both. The client obtains a token through sign-in; leaving a token out of this configuration does not make the connection anonymous.</p>
        <McpClientExampleTabs :examples="oauthExamples" :copied="copied" label="Browser sign-in MCP client" @copy="copy" />
        <div v-for="guidance in oauth.clientGuidance" :key="guidance.id" class="flex min-w-0 flex-col gap-1.5">
          <h4 class="m-0 text-sm font-medium">{{ guidance.label }}</h4>
          <p v-for="paragraph in paragraphs(guidance.description)" :key="paragraph" class="m-0 break-words text-sm text-muted-foreground">{{ paragraph }}</p>
        </div>
      </section>
      <section class="flex min-w-0 flex-col gap-3" aria-label="Manual token">
        <h3 class="m-0 text-base font-semibold">Manual token</h3>
        <p class="m-0 text-sm text-muted-foreground">Generate an MCP token in your profile and configure your client using an example below. Keep tokens out of prompts and committed files, and generate a new one when it expires. You can revoke tokens from your profile.</p>
        <McpClientExampleTabs :examples="examples" :copied="copied" label="MCP client" @copy="copy" />
      </section>
      <p aria-live="polite" class="m-0 text-sm" :class="status ? 'text-muted-foreground' : 'sr-only'">{{ status }}</p>
      <slot />
    </CardContent>
  </Card>
</template>
