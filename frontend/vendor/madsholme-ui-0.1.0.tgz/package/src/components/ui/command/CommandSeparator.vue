<script setup lang="ts">
import type { SeparatorProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import { Separator } from 'reka-ui'
import { cn } from '../../../lib/utils'

const props = defineProps<SeparatorProps & { class?: HTMLAttributes['class'] }>()
const delegatedProps = reactiveOmit(props, 'class')
</script>

<template>
  <Separator v-bind="delegatedProps" data-slot="command-separator" :class="cn('-mx-1 h-px bg-border', props.class)">
    <slot />
  </Separator>
</template>
