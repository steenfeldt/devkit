<script setup lang="ts">
import { computed, useId } from 'vue'
import { CalendarDays } from 'lucide-vue-next'
import { parseDate, type DateValue } from '@internationalized/date'
import { Button } from '../button'
import { Calendar } from '../calendar'
import { Popover, PopoverContent, PopoverTrigger } from '../popover'
const props = withDefaults(defineProps<{
  modelValue?: string | null
  label: string
  locale: string
  disabled?: boolean
  placeholder?: string
  clearLabel?: string
}>(), { modelValue: null, placeholder: 'Pick a date', clearLabel: 'Clear' })
const emit = defineEmits<{ 'update:modelValue': [value: string | null] }>()
const id = useId()
const validLocale = computed(() => { try { new Intl.DateTimeFormat(props.locale); return true } catch { return false } })
const value = computed(() => { try { return props.modelValue ? parseDate(props.modelValue) : undefined } catch { return undefined } })
const display = computed(() => {
  try { return value.value ? new Intl.DateTimeFormat(props.locale, { dateStyle: 'medium', timeZone: 'UTC' }).format(value.value.toDate('UTC')) : props.placeholder }
  catch { return props.modelValue || props.placeholder }
})
function select(date: DateValue | undefined) { if (!props.disabled) emit('update:modelValue', date?.toString() ?? null) }
</script>
<template>
  <div data-slot="date-picker" class="grid gap-2">
    <label :for="id" class="text-sm font-medium">{{ label }}</label>
    <Popover>
      <PopoverTrigger as-child><Button :id="id" type="button" variant="outline" :disabled="disabled || !validLocale" class="justify-start"><CalendarDays class="size-4" aria-hidden="true" />{{ display }}</Button></PopoverTrigger>
      <PopoverContent :label="label" class="w-auto p-0" align="start">
        <Calendar :model-value="value" :locale="validLocale ? locale : 'en'" :disabled="disabled || !validLocale" @update:model-value="select" />
        <div class="border-t p-2"><Button type="button" size="sm" variant="ghost" :disabled="disabled || !validLocale" @click="select(undefined)">{{ clearLabel }}</Button></div>
      </PopoverContent>
    </Popover>
  </div>
</template>
