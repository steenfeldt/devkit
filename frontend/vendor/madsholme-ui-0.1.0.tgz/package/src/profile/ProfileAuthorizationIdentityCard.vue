<script setup lang="ts">
import { Link2 } from 'lucide-vue-next'
import { computed } from 'vue'
import ProfileDetailsCard from './ProfileDetailsCard.vue'
import type { AuthorizationIdentity, ProfileDetailRow, ProfileGroup } from './types'

const props = withDefaults(defineProps<{
  title?: string
  identity: AuthorizationIdentity | null
  ownerGroup?: ProfileGroup | null
  memberships?: readonly ProfileGroup[]
  emptyTitle?: string
  emptyDescription?: string
}>(), {
  title: 'Authorization Identity',
  ownerGroup: null,
  memberships: () => [],
  emptyTitle: 'No active authorization identity',
  emptyDescription: 'This account is not linked to an external identity.',
})

const rows = computed<ProfileDetailRow[]>(() => {
  const identity = props.identity
  if (!identity) return []
  return [
    { key: 'provider', label: 'Provider', value: identity.providerName, detail: identity.providerKey },
    { key: 'status', label: 'Status', badge: { key: 'status', label: identity.status, variant: identity.statusTone === 'positive' ? 'default' : 'outline' } },
    ...(identity.matchMethod ? [{ key: 'match', label: 'Match method', value: identity.matchMethod }] : []),
    { key: 'external-username', label: 'External Username', value: identity.externalUsername, mono: true },
    { key: 'external-id', label: 'External User ID', value: identity.externalId, mono: true },
    { key: 'email', label: 'External Email', value: identity.email },
    { key: 'owner-group', label: 'Owner Group', groups: props.ownerGroup ? [props.ownerGroup] : [], emptyText: 'No owner group' },
    { key: 'memberships', label: 'Memberships', groups: props.memberships, emptyText: 'No group memberships' },
  ]
})
</script>

<template>
  <ProfileDetailsCard
    :title="title"
    :icon="Link2"
    :rows="rows"
    :empty-title="emptyTitle"
    :empty-description="emptyDescription"
    :footnote="identity?.message ?? ''"
  />
</template>
