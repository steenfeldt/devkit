<script setup lang="ts" generic="T extends { value: AcceptableValue; label: string; disabled?: boolean }">
import type { AcceptableValue } from 'reka-ui'
import { injectComboboxRootContext, useFilter } from 'reka-ui'
import { computed, inject } from 'vue'
import ComboboxItem from './ComboboxItem.vue'
import { comboboxOptionsKey } from './context'

const props = defineProps<{
  options: T[]
  maxResults?: number
}>()
const root = injectComboboxRootContext()
const settings = inject(comboboxOptionsKey, undefined)
const { contains } = useFilter({ sensitivity: 'base' })
const objectKeys = new WeakMap<object, number>()
let nextKey = 0
function optionKey(option: T) {
  const value = option.value
  if (value !== null && typeof value === 'object') {
    if (!objectKeys.has(value)) objectKeys.set(value, ++nextKey)
    return `object:${objectKeys.get(value)}:${option.label}`
  }
  return `${typeof value}:${String(value)}:${option.label}`
}
const visible = computed(() => {
  const search = root.filterSearch.value
  const matches = !search || root.ignoreFilter.value ? props.options
    : props.options.filter(option => contains(option.label, search))
  const limit = props.maxResults ?? settings?.maxResults.value
  return limit !== undefined && Number.isFinite(limit) && limit >= 0 ? matches.slice(0, Math.floor(limit)) : matches
})
</script>

<template>
  <ComboboxItem v-for="option in visible" :key="optionKey(option)" :value="option.value" :disabled="option.disabled" :text-value="option.label">
    <slot :option="option">{{ option.label }}</slot>
  </ComboboxItem>
</template>
