import { parseAbsolute, parseDateTime, toCalendarDateTime, toZoned } from '@internationalized/date'

export function instantToLocal(value: string, timeZone: string): string | null {
  try { return toCalendarDateTime(parseAbsolute(value, timeZone)).toString().slice(0, 16) }
  catch { return null }
}

export function localToInstant(local: string, timeZone: string, min?: string, max?: string): { value: string; error?: never } | { error: string; value?: never } {
  try {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(local)) return { error: 'invalid' }
    const instant = toZoned(parseDateTime(local), timeZone, 'reject').toDate()
    const minTime = min ? parseAbsolute(min, timeZone).toDate().getTime() : -Infinity
    const maxTime = max ? parseAbsolute(max, timeZone).toDate().getTime() : Infinity
    if (minTime > maxTime || instant.getTime() < minTime || instant.getTime() > maxTime) return { error: 'bounds' }
    return { value: instant.toISOString() }
  }
  catch { return { error: 'invalid' } }
}

/** Validate timezone-free minute-precision wall times without DST/UTC conversion. */
export function validateLocalDateTime(value: string, min?: string, max?: string): { value: string; error?: never } | { error: string; value?: never } {
  try {
    const parse = (input: string) => {
      if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(input)) throw new Error('invalid')
      return parseDateTime(input)
    }
    const date = parse(value)
    const lower = min ? parse(min) : undefined
    const upper = max ? parse(max) : undefined
    if ((lower && upper && lower.compare(upper) > 0) || (lower && date.compare(lower) < 0) || (upper && date.compare(upper) > 0)) return { error: 'bounds' }
    return { value }
  } catch { return { error: 'invalid' } }
}
