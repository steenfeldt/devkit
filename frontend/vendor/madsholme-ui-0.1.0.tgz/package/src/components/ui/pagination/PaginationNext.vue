<script setup lang="ts">
import { usePaginationOptions } from "./context"
const options = usePaginationOptions()
import type { PaginationNextProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import type { ButtonVariants } from "../button"
import { ChevronRightIcon } from "lucide-vue-next"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { PaginationNext, useForwardProps } from "reka-ui"
import { buttonVariants } from "../button"

const props = withDefaults(defineProps<PaginationNextProps & {
  size?: ButtonVariants["size"]
  class?: HTMLAttributes["class"]
}>(), {
  size: "default",
})

const delegatedProps = reactiveOmit(props, "class", "size")
const forwarded = useForwardProps(delegatedProps)
</script>

<template>
  <PaginationNext
    data-slot="pagination-next"
    :class="cn(buttonVariants({ variant: 'ghost', size }), 'gap-1 px-2.5 sm:pr-2.5', props.class)"
    v-bind="forwarded"
    :aria-label="options.labels.next"
  >
    <slot>
      <span class="hidden sm:block">{{ options.labels.next }}</span>
      <ChevronRightIcon />
    </slot>
  </PaginationNext>
</template>
