<script setup lang="ts">
import type { PopoverTriggerProps } from 'reka-ui'
import { PopoverTrigger } from 'reka-ui'

const props = defineProps<PopoverTriggerProps>()
</script>

<template>
  <!-- With as-child the child keeps its own data-slot (for example "button"). -->
  <PopoverTrigger v-bind="props.asChild ? props : { ...props, 'data-slot': 'popover-trigger' }">
    <slot />
  </PopoverTrigger>
</template>
