import type { ThemeKey, ThemeOption, ThemePreference } from '@madsholme/themes'
import type { Component } from 'vue'
import {
  BedDouble, BookOpen, Building2, Cat, CloudMoon, CloudSun, Coffee, Contrast, Cpu, Eye, Flame, Flower, Flower2,
  Ghost, Heart, Leaf, Monitor, Moon, MoonStar, Orbit, Palette, Pencil, PenTool, Snowflake, Sparkles, Star, Sun,
  Sunrise, Sunset, Terminal, TreeDeciduous, TreePine, Zap,
} from 'lucide-vue-next'

/** One icon per theme, as the products' profile theme cards use them, plus `system`. */
export const themeIcons: Readonly<Record<ThemePreference, Component>> = {
  system: Monitor,
  light: Sun,
  dark: Moon,
  dim: Sunset,
  'magic-mike': Sparkles,
  rn: Building2,
  'rn-light': Building2,
  'sw-light': CloudSun,
  alex: Heart,
  'midnight-mirage': MoonStar,
  'solar-bloom': Sunrise,
  cyberpunk: Zap,
  matrix: Terminal,
  'orbital-light': Sparkles,
  'tron-light': Cpu,
  'nova-drift': Orbit,
  'rose-pine': Flower2,
  'rose-pine-dawn': Flower,
  'cosmic-light': Star,
  ember: Flame,
  'night-shift': BedDouble,
  catppuccin: Cat,
  'catppuccin-latte': Coffee,
  'gruvbox-material-dark': TreePine,
  'gruvbox-material-light': TreeDeciduous,
  graphite: Pencil,
  sage: Leaf,
  pink: Zap,
  'soft-pink': Flower2,
  aurora: Sparkles,
  'high-contrast': Eye,
  signal: Contrast,
  colorblind: Palette,
  'colorblind-dark': Palette,
  nord: Snowflake,
  'solarized-light': BookOpen,
  'solarized-dark': BookOpen,
  ink: PenTool,
  'tokyo-night': CloudMoon,
  dracula: Ghost,
}

export interface ThemeChoice {
  readonly value: ThemePreference
  readonly label: string
  readonly icon: Component
}

/** Adds icons to theme options from @madsholme/themes. */
export function withThemeIcons(options: readonly ThemeOption[]): ThemeChoice[] {
  return options.map((option) => ({ ...option, icon: themeIcons[option.value as ThemeKey] }))
}
