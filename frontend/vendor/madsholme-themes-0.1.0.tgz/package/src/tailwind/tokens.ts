import { darkThemeKeys } from '../registry'

/** Every root that should activate Tailwind's `dark:` variant: `.dark` plus each dark data-theme. */
export const darkRoots: readonly string[] = ['.dark', ...darkThemeKeys.map((key) => `[data-theme="${key}"]`)]

/** Selector for the generated `@custom-variant dark` in `css/tailwind-theme.css`; exported from the package root. */
export const darkModeSelector = `&:where(${darkRoots.flatMap((root) => [root, `${root} *`]).join(', ')})`

/** Colours, radii, fonts and text sizes that feed the generated `css/tailwind-theme.css`; exported from the package root. Values are API. */
export const tailwindTokens = {
  colors: {
    border: 'var(--border)',
    input: 'var(--input)',
    ring: 'var(--ring)',
    background: 'var(--background)',
    foreground: 'var(--foreground)',
    primary: {
      DEFAULT: 'var(--primary)',
      foreground: 'var(--primary-foreground)',
    },
    secondary: {
      DEFAULT: 'var(--secondary)',
      foreground: 'var(--secondary-foreground)',
    },
    destructive: {
      DEFAULT: 'var(--destructive)',
      foreground: 'var(--destructive-foreground)',
    },
    muted: {
      DEFAULT: 'var(--muted)',
      foreground: 'var(--muted-foreground)',
    },
    accent: {
      DEFAULT: 'var(--accent)',
      foreground: 'var(--accent-foreground)',
    },
    popover: {
      DEFAULT: 'var(--popover)',
      foreground: 'var(--popover-foreground)',
    },
    card: {
      DEFAULT: 'var(--card)',
      foreground: 'var(--card-foreground)',
    },
    warning: {
      DEFAULT: 'var(--warning)',
      foreground: 'var(--warning-foreground)',
    },
    success: {
      DEFAULT: 'var(--success)',
      foreground: 'var(--success-foreground)',
    },
    highlight: {
      DEFAULT: 'var(--highlight)',
      foreground: 'var(--highlight-foreground)',
    },
    info: {
      DEFAULT: 'var(--info)',
      foreground: 'var(--info-foreground)',
    },
  },
  borderRadius: {
    xl: 'calc(var(--radius) + 4px)',
    lg: 'var(--radius)',
    md: 'calc(var(--radius) - 2px)',
    sm: 'calc(var(--radius) - 4px)',
  },
} as const

/**
 * Tailwind 3.4 defaults that Tailwind 4 changed, kept so v4 renders as v3 did. Emitted into
 * css/tailwind-theme.css; not exported from the package root.
 * - `fontFamily`: v4.3's default sans stack starts with -apple-system/Segoe UI/Roboto; v3's
 *   started with ui-sans-serif/system-ui. Mono is unchanged and pinned with it.
 * - `lineHeight`: v3's `text-*` line heights were rem lengths, which children inherit as lengths;
 *   v4's are unitless ratios, which children re-apply to their own font size.
 */
export const tailwind3Defaults = {
  fontFamily: {
    sans: 'ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
    mono: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
  },
  lineHeight: {
    xs: '1rem',
    sm: '1.25rem',
    base: '1.5rem',
    lg: '1.75rem',
    xl: '1.75rem',
    '2xl': '2rem',
    '3xl': '2.25rem',
    '4xl': '2.5rem',
  },
} as const
