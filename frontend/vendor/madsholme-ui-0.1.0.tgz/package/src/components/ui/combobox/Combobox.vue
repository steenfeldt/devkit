<script setup lang="ts">
import { computed, provide } from "vue"
import { reactiveOmit } from "@vueuse/core"
import { comboboxOptionsKey } from "./context"
import type { ComboboxRootEmits, ComboboxRootProps } from "reka-ui"
import { ComboboxRoot, useForwardPropsEmits } from "reka-ui"

const props = defineProps<ComboboxRootProps & { clearOnReselect?: boolean; loop?: boolean; maxResults?: number }>()
const emits = defineEmits<ComboboxRootEmits>()

provide(comboboxOptionsKey, {
  clearOnReselect: computed(() => props.clearOnReselect),
  loop: computed(() => props.loop),
  maxResults: computed(() => props.maxResults),
})
const forwarded = useForwardPropsEmits(reactiveOmit(props, 'clearOnReselect', 'loop', 'maxResults'), emits)
</script>

<template>
  <ComboboxRoot
    v-slot="slotProps"
    data-slot="combobox"
    v-bind="forwarded"
  >
    <slot v-bind="slotProps" />
  </ComboboxRoot>
</template>
