<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { useModel } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{
  defaultValue?: string | number
  modelValue?: string | number
  size?: 'default' | 'sm'
  class?: HTMLAttributes['class']
}>(), {
  defaultValue: undefined,
  modelValue: undefined,
  size: 'default',
  class: undefined,
})

defineEmits<{
  (e: 'update:modelValue', payload: string | number): void
}>()

const modelValue = useModel(props, 'modelValue', {
  get: value => value ?? props.defaultValue ?? '',
})
</script>

<template>
  <input
    v-model="modelValue"
    data-slot="input"
    :class="cn('ui-input flex h-10 w-full min-w-0 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-foreground file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50', props.size === 'sm' && 'h-9 py-1.5', props.class)"
  >
</template>
