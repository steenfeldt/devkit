<script setup lang="ts">
import type { PrimitiveProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { Primitive } from 'reka-ui'
import { cn } from '../../../lib/utils'

// `sd-card` carries the themes polish-layer elevation; `ui-card` is the stable hook.
const props = withDefaults(defineProps<PrimitiveProps & { class?: HTMLAttributes['class'] }>(), {
  as: 'div',
  class: undefined,
})
</script>

<template>
  <Primitive
    data-slot="card"
    :as="as"
    :as-child="asChild"
    :class="cn('ui-card sd-card min-w-0 rounded-xl border bg-card text-card-foreground', props.class)"
  >
    <slot />
  </Primitive>
</template>
