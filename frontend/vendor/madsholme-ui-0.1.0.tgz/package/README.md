# @madsholme/ui

Vue 3 components for the Swift product family. The package contains:

- the shadcn-vue components (Reka UI 2);
- the application shell: header, top and mobile navigation, profile dropdown, admin-mode
  banner, impersonation banner and dialog, global notifications, skip link;
- the profile-page building blocks: identity, details, capabilities, API access, theme, work
  default, and the API token list, create form, generated token and revoke dialog.

Components receive data and emit actions. They never import a product's store, API client,
generated types or routes, and `test/shell.test.ts` enforces that. Themes come from
`@madsholme/themes`; the brand mark comes from `@madsholme/branding` through the shell's
`brand` slot.

The reconciliation of the three products' copies is in
[`docs/ui-reconciliation.md`](../../docs/ui-reconciliation.md), and the plan in
[`docs/plans/ui-package.md`](../../docs/plans/ui-package.md).

## Scoped imports

Use scoped entries to avoid evaluating unrelated components in tests and native ESM:

```ts
import { cn } from '@madsholme/ui/utils'
import { ImpersonationBanner, ImpersonationDialog } from '@madsholme/ui/impersonation'
import { AppShell, type NavGroup, type ImpersonationTarget } from '@madsholme/ui/shell'
```

`cn` uses the shared clsx and tailwind-merge rules. `/shell` exports all shell contract types;
`/impersonation` also exports `ImpersonationParty` and `ImpersonationTarget` types. Existing root
imports remain supported. See [consumer patterns](../../docs/consumer-patterns.md#component-imports-and-bundle-boundaries)
for component, profile and theme entries and bundle checks.

## Install

```sh
pnpm add @madsholme/ui @madsholme/themes vue-sonner@^1.3.2 @unovis/vue@^1.6.7 @unovis/ts@^1.6.7 vee-validate@^4.15.1 @tanstack/vue-table@^8.21.0
```

`.npmrc` needs the `@madsholme` registry and a `read:packages` token, as for themes.

- **Peer dependencies:** `vue ^3.5`, `vue-router ^4`, `reka-ui ^2.9`, `tailwindcss ^4.3`,
  `tw-animate-css ^1.4.0`, `lucide-vue-next >=0.390`, `vue-sonner ^1.3.2`, `@unovis/vue ^1.6.7`, `@unovis/ts ^1.6.7`,
  `vee-validate ^4.15.1`, `@tanstack/vue-table ^8.21.0`.
- **`tw-animate-css`:** import it once in the product's main CSS, after the Tailwind theme import
  (see the [themes README](../themes/README.md#css)); without it the components' open and close
  animations are no-ops.
- **Toasts:** use the shared `Toaster` and `toast` exports below. `vue-sonner` is a peer so
  existing product imports share the same notification store.

## Vite development

Add `uiDependencies()` from `@madsholme/ui/vite` to the consumer's Vite plugins, alongside Vue.
It pre-bundles Unovis's CommonJS-bearing dependency graph, required by root imports and charts in
`vite dev` when consuming the published source package. Scoped imports remain available.
See [consumer patterns](../../docs/consumer-patterns.md#vite-dev-with-the-published-ui-package)
for setup, Table attribute migration, inline dialogs and capped Combobox options.

## Tailwind sources

The package ships `.vue` and `.ts` source, so Tailwind must scan it. Add an `@source` line to
the product's main CSS, after the import sequence from the
[`@madsholme/themes` README](../themes/README.md#css) (Tailwind 4.3, no `tailwind.config`; the
path is relative to the CSS file):

```css
@source '../node_modules/@madsholme/ui/src';
```

## Colours

Components use semantic Tailwind classes (`bg-primary`, `text-muted-foreground`, `bg-warning/15`)
and `var(--token)` in their own CSS. The tokens are full `oklch()` colours, so there are no
`hsl(var(--x))` wrappers; alpha is a slash modifier or `color-mix(in srgb, var(--x) N%, transparent)`.
The format and the migration table for product code are in the
[`@madsholme/themes` README](../themes/README.md#colour-tokens). Browsers: Chrome and Edge 111+,
Safari 16.4+, Firefox 128+ (Tailwind 4's baseline, which also covers `oklch()`, `color-mix()` and
gradient colour interpolation).

Two colour groups beyond the shadcn set, both defined in every theme:

- `bg-highlight` / `text-highlight-foreground`: the theme's second hue, for stat tiles, charts and
  decorative emphasis; it is never the same colour as `bg-primary` outside the single-hue themes.
- `bg-info` / `text-info-foreground`: the fourth status, next to success, warning and destructive;
  for info text on a card use `var(--sd-info-foreground)`, which falls back to card text where the
  info colour is below AA.

The roles of every token are in the
[`@madsholme/themes` README](../themes/README.md#colour-tokens) ("Token roles"). `hover:bg-accent`
and `data-[state=open]:bg-accent/50` on the shell's header items are intentionally overridden to
transparent in the nine flat-header themes (Alex, Solar Bloom, Rosé Pine, Cosmic Light, Nova Drift,
Orbital Light, Tron Light, Cyberpunk, Ember): there the current item shows only its underline and
keyboard focus shows an outline in the item's text colour (`currentColor`).

## The shell

```vue
<AppShell
  home-to="/dashboard"
  home-label="SwiftDeploy home"
  :navigation="navigation"
  :user="{ name: auth.displayName, subtitle: auth.groupName }"
  :theme="{ preference: theme.preference.value, error: theme.saveError.value }"
  :admin-mode="{ active: auth.isAdminMode, canToggle: auth.adminCapable }"
  :impersonation="{ active, actor, effective, canStart, stopPending, targets, searching, startPending, dialogError }"
  :logout="{ pending: logoutPending, error: logoutError }"
  :notifications="notices"
  collapse-below="md"
  @select-theme="theme.select"
  @toggle-admin-mode="switchMode"
  @search-impersonation="search"
  @start-impersonation="start"
  @stop-impersonation="stop"
  @logout="logout"
>
  <template #brand><ProductBrand product="swiftdeploy" surface="header" :theme="theme.theme.value" /></template>
  <RouterView />
</AppShell>
```

- **`navigation`** is `NavGroup[]`: direct links (`to`) or groups (`items`), already filtered
  by the product's permissions. The current group is the longest `match` prefix (by default,
  the paths of the group's links).
- **Slots:** `brand`, `header-actions`, `profile-menu-items`, `alerts` (product alerts under
  the header), `subnav` and the default slot.
- **`restoreFocus()`** moves focus to the impersonation stop action, else the profile
  trigger, else `#main-content`. Products that change actor without a page reload call it
  after the transition.
- **Built in:**
  - a skip link and a focusable `#main-content`;
  - the theme quick picker: "System", RN, RN Light, SW Light as `menuitemradio`, and the
    menu stays open after a choice;
  - impersonation opens only after the menu has closed (avoiding Reka's leftover
    `pointer-events: none`);
  - a debounced type-ahead impersonation search;
  - Escape blocked while a start is pending;
  - focus returns after dialogs;
  - logout retry;
  - while a modal is open, `aria-hidden` on the page is mirrored into `inert`.
- **Motion:** with `tw-animate-css` imported (see Install) the profile menu, dialogs and the
  navigation menu animate open and closed, as do select, popover, tooltip, sheet, dropdown sub
  menus and the accordion (see the ui changeset), and the themes package reveals the admin-mode
  and notification banners on mount and eases header items (`docs/theme-reconciliation.md` §14).
  A closing overlay stays mounted while its exit animation plays (150 to 200 ms), so a test that
  acts right after closing a menu or dialog must wait for it to unmount or be hidden
  (`await expect(locator).toBeHidden()`), as `apps/template/tests/axe.spec.ts` does. Under
  `prefers-reduced-motion: reduce` every `animate-*` utility except the loaders (`animate-spin`,
  `animate-pulse`) collapses to 0.01 ms.

The parts are also exported for products that compose their own shell: `ProfileMenu`,
`TopNavigation`, `MobileNavigation`, `ImpersonationBanner`, `ImpersonationDialog`,
`AdminModeBanner`, `GlobalNotificationBanner`, `SkipLink` and `ThemeQuickPicker`.

## Theme state

`useThemeState(controller)` turns a `@madsholme/themes` controller into refs (`preference`,
`theme`, `followsSystem`, `saving`, `saveError`) and actions (`select`, `setFollowSystem`).
`themeIcons` and `withThemeIcons()` provide the one icon map for all themes.

## Profile page

Assemble the page from `ProfilePageLayout` (`main` and `aside` slots) and these cards:

- `ProfileIdentityHeader`, `ProfileDetailsCard`, `ProfileAuthorizationIdentityCard` and
  `ProfileBadgeCard`;
- `ProfileApiAccessCard`, `ProfileWorkDefaultCard`, `ProfileAnimationCard` and `ProfileThemeCard`, which has the
  "Match system theme" switch;
- `ApiTokenList`, `ApiTokenCreateForm`, `GeneratedTokenDisplay`, `ApiTokenRevokeDialog` and
  `ApiTokenUsageNote`, for the tokens page.
- `McpTokenCreateForm`, `McpTokenList` and `McpClientSetup`, for MCP tokens. The product maps its
  grant fields to `McpGrantArea` / `McpTokenSummary`, passes only the areas the account may grant to
  the form (all areas to the list), and builds snippets with `buildMcpClientExamples({ endpoint,
  serverName, envVar })`. Use `GeneratedTokenDisplay` with `secret-label="Generated MCP token"` for
  the one-time secret, with `class="[--muted-foreground:var(--sd-muted-card-foreground)]"`
  for theme-safe card copy, and `ApiTokenRevokeDialog` to confirm revocation. The components emit events
  only; API calls, eligibility, sign-in notices and toasts stay in the product.

The product keeps its data fetching, one-time-secret handling, capability labels and its own
cards.

## MCP browser sign-in guidance

`McpClientSetup` always renders the product's `endpoint` with a copy action and the
**Manual token** method using the supplied `examples`. Existing `description` and default
slots remain available. Both endpoint and example copies emit `copied` / `copy-failed`
and announce feedback; failed copies leave selectable text available.

Pass `oauth: McpBrowserOAuth` only from product configuration. Browser sign-in is shown
**only for `enabled: true`**. Omitted, `null`, `{ enabled: false }`, and `{ enabled: null }`
(unknown/loading) never advertise OAuth. Unknown is not inferred from an endpoint,
provider label, signed-in session or client examples. Changes are reflected reactively.

```vue
<script setup lang="ts">
import { McpClientSetup, buildMcpClientExamples, type McpBrowserOAuth } from '@madsholme/ui/profile'

// These values illustrate product-supplied configuration, not discovery by SwiftDesign.
const endpoint = 'https://product.example/mcp'
const examples = buildMcpClientExamples({ endpoint, serverName: 'product', envVar: 'PRODUCT_MCP_TOKEN' })
const oauth: McpBrowserOAuth = {
  enabled: true, // Map only an explicit true from the product's configuration.
  loginProviderLabel: 'Company SSO',
  clientGuidance: [{
    id: 'open-webui',
    label: 'Open WebUI',
    description: [
      'Dynamic registration requests refresh-token support; this server accepts authorization-code-only registration.',
      'Static OAuth registration is a proposed workaround awaiting end-to-end verification.',
    ],
  }],
}
</script>

<template>
  <McpClientSetup :endpoint="endpoint" :examples="examples" :oauth="oauth" />
</template>
```

### Examples for both connection methods

Each `McpClientExample` keeps its existing `snippets` for manual-token setup and may
supply `oauthSnippets` with the same `McpClientSnippet` shape. The browser section has
its own client tabs, shown only for entries with nonempty `oauthSnippets` and explicit
product OAuth enablement. Missing OAuth examples never hide manual examples. Product
adapters can supply or filter examples; the shared UI performs no client detection.

`buildMcpClientExamples` includes:

- **Codex browser OAuth:** URL-only `config.toml` and a separate `codex mcp login`
  command. The browser completes the product's configured sign-in and MCP consent.
- **Claude Code browser OAuth:** HTTP `.mcp.json` with the endpoint and no token
  header; open `/mcp` in Claude Code and authenticate that server.
- **Manual token:** the existing Codex environment/file variants, Claude Code bearer
  header, and OpenAI Responses tool with explicit authorization.

Choose one configuration for each server. When switching to OAuth, replace its manual
entry and remove `bearer_token_env_var` / `Authorization` headers so they cannot take
precedence. OAuth still issues a product MCP token; it is not anonymous access and
never uses an ADFS access token as the MCP credential. The client manages that token;
re-authenticate after expiry. No refresh-token support is promised.

Client syntax checked against [Codex MCP documentation](https://developers.openai.com/codex/mcp)
and [Claude Code MCP documentation](https://code.claude.com/docs/en/mcp) on 2026-10-30.
These are setup examples, not end-to-end compatibility certification. OpenAI Responses
retains its manual authorization example; no interactive browser setup is invented for it.
Existing product calls to the helper receive the added examples after package adoption
without changing their API adapter. Rebuild the consuming frontend and deploy the new
`dist` output; a shared-source update does not replace a previously built deployment.

The enabled variant requires `loginProviderLabel`. Optional `clientGuidance` entries
(`McpClientGuidance`) have a unique `id`, a `label`, and a plain-text `description`
(string or paragraph array). Supply only applicable clients and current product guidance;
omit the list when none applies. Text is escaped, never interpreted as HTML.
The shared flow is: connect from the client → product sign-in → explicit MCP approval →
client receives a product MCP token. It explains that manual generation is unnecessary
for this flow and issued tokens can be revoked from the profile. SwiftDesign neither
starts authentication nor fetches configuration or tokens.

**Open WebUI limitation:** source inspection supplied for this change found a dynamic
registration mismatch: Open WebUI requests refresh-token support while Swift MCP accepts
authorization-code-only registration. Static registration is a proposed workaround,
awaiting end-to-end verification. Do not describe automatic registration, refresh tokens
or verified Open WebUI compatibility as available. Include the caveat if showing this
client; the shared component contains no built-in compatibility claim.

**Product adoption is separate work.** SwiftDeploy, SwiftConfig and SwiftPatch must expose
OAuth availability, endpoint and login-provider configuration, pass the applicable guidance
into this component, and adopt the package release (or refresh their supported package
snapshot). Keep their existing token creation/list/revocation wiring and permission rules.
SwiftDeploy must remove “No external web-app OAuth registration is provided”. The inspected
SwiftConfig and SwiftPatch adapters also contain “OAuth browser applications are not enabled”;
replace those unconditional statements with configuration-aware guidance during adoption.
Updating SwiftDesign alone does not enable this UI in running products. Backend auth,
registration, consent, API contracts and product wiring remain outside this package.

## Stable hooks

Products and their tests select on these. Removing or renaming any is a breaking change.

- **`data-slot`:** the documented primitive and composition hooks, listed in the public snapshot.
- **Class hooks:** `ui-button`, `ui-button--{variant}`, `ui-button--{size}`, `ui-badge*`,
  `ui-card*`, `ui-input`, `ui-native-select`, `ui-textarea`, `ui-checkbox`, `ui-switch*`,
  `ui-popover-content`, `ui-dropdown-menu-*`, `ui-tooltip`, `ui-calendar*`, `ui-toaster`, and `sd-card`.
- **Test hooks:** `data-test="begin-impersonation"`, `"toggle-admin-mode"` and `"logout"`;
  `data-testid="stop-impersonation"`, `"retry-logout"`, `"product-name"`,
  `"created-api-token"`, `"profile-menu"`, `"mobile-navigation"`, `"impersonation-dialog"` and
  `"revoke-token-dialog"`.

The full surface (exports, props, events, slots, exposed members, hooks) is snapshotted in
[`test/fixtures/public-surface.json`](test/fixtures/public-surface.json). Run `pnpm surface`
after an API change and review the diff.

## Development

```sh
pnpm --filter @madsholme/ui test        # components, shell, profile, public surface
pnpm --filter @madsholme/ui typecheck
pnpm --filter template test:visual      # screenshots, keyboard and axe checks (apps/template)
```


## Animation profile setting

`ProfileAnimationCard` is a controlled, accessible switch. Its optional `enabled` prop defaults
to `true`; it emits `update:enabled` with a boolean. Pass `saving` and `error` for live save feedback.
It stays interactive during saves. The card does not access storage or APIs.

```vue
<script setup lang="ts">
import { ProfileAnimationCard, useAnimationState } from '@madsholme/ui'
import { animationController } from './preferences' // product-owned, initialized before mount
const animations = useAnimationState(animationController)
</script>

<template>
  <ProfileAnimationCard
    :enabled="animations.enabled.value"
    :saving="animations.saving.value"
    :error="animations.saveError.value"
    @update:enabled="animations.select"
  />
</template>
```

Place the card beside the theme card on the product's profile page. `useAnimationState` subscribes
to a `createAnimationController` from `@madsholme/themes` and unsubscribes when its Vue scope ends.
See the themes README for the profile adapter, boolean backend field, early boot setup, error
rollback and impersonation contract. No additional CSS imports or `@source` entries are needed
beyond the installation sequence above. The stable card hook is `data-slot="profile-animation-card"`.

## Backends without system-theme support

Set `theme.allowSystem: false` on `AppShell` and `:allow-system="false"` on `ProfileThemeCard`.
The shell filters the system entry even from custom choices. Configure the theme controller and
boot plugin with the same `allowSystem: false, fallbackTheme: 'light'` policy. Named theme choices
and existing defaults remain unchanged for other consumers.

## Toast notifications

Mount exactly one `Toaster` in the application's root, beside the router or shell, so it also
covers sign-in and other pages outside the shell. `AppShell` does not mount one automatically.
Replace the product's old Sonner Toaster rather than rendering both.

```vue
<script setup lang="ts">
import { Toaster } from '@madsholme/ui'
</script>

<template>
  <Toaster />
  <RouterView />
</template>
```

```ts
import { toast } from '@madsholme/ui'

toast.success('Changes saved')
toast.error('Could not save changes', { description: 'Check your connection and try again.' })
toast.warning('Session expires soon')
toast.info('Report is ready')
const id = toast.loading('Saving…')
toast.success('Changes saved', { id }) // replace the loading message
toast.dismiss(id)
```

The default is bottom-right, with a close button, four-second lifetime, pause while the page is
hidden, and hover/focus pause. Alt+T focuses the first toast; Tab reaches its controls and Escape
returns to the invoking control. Icons and text accompany
status colors. The popover, border and status tokens follow every SwiftDesign theme immediately;
no separate light/dark theme prop is needed. Motion respects reduced motion and the animation
preference. Styles ship with the Vue component; no extra CSS import is required.

`Toaster` forwards Sonner props such as `position`, `duration`, `visibleToasts`, `hotkey`,
`containerAriaLabel`, `toastOptions`, `icons`, `class` and `style`. `ExternalToast` and `ToasterProps`
are exported for TypeScript consumers. Use `duration: Infinity` for a message that must remain
until dismissed. Sonner's `toast.promise`, action, cancellation and ID-based updates remain
available. Local links should include `vue-sonner` in Vite `resolve.dedupe`, alongside Vue/Reka,
so product imports and the wrapper resolve to the same store.

Use toasts for transient outcomes. Keep field validation, retryable form errors, long-lived
notices and essential recovery instructions in the page or dialog where users can act on them.
The product owns API calls, error mapping and when messages appear; SwiftDesign owns presentation.

## Modal and confirmation dialog standard

Use `Dialog` for focused input and `AlertDialog` for a decision that needs explicit confirmation.
Both share the SwiftDeploy-derived treatment: rounded 16px corners, a theme background and border,
24px padding, a large shadow and a 70% black backdrop. Content defaults to 32rem wide, keeps 16px
viewport gutters, and scrolls within 90dvh. Footers stack with gaps on mobile and align right on
desktop. Override width with `class="max-w-2xl"` when the task needs more space.

```vue
<Dialog v-model:open="editing">
  <DialogTrigger as-child><Button>Edit report</Button></DialogTrigger>
  <DialogContent>
    <DialogHeader class="pr-6">
      <DialogTitle>Edit report</DialogTitle>
      <DialogDescription>Update the report settings.</DialogDescription>
    </DialogHeader>
    <!-- Product-owned, labelled form fields -->
    <DialogFooter>
      <Button variant="outline" @click="editing = false">Cancel</Button>
      <Button :disabled="saving" @click="save">Save changes</Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

Always include a title and description and label form controls. Reka traps focus, handles Escape,
and restores focus to the trigger. `DialogContent` has an accessible close button; confirmation
content instead uses `AlertDialogCancel` and `AlertDialogAction` and ignores backdrop clicks.
For async destructive actions, use a controlled `AlertDialog` and an ordinary `Button` for confirm
so it stays open on failure; block closing while pending and retain an inline error (as
`ApiTokenRevokeDialog` does). A toast is not a modal: it does not take focus or block the page.
See the template's `/feedback` route for working examples of both dialog types and long content.


## Complete shared catalog

The [component catalog](../../docs/component-catalog.md) maps every main shadcn-vue entry to its
shared source and working example, including sidebar, skeleton, messages, charts and forms.
AI Elements are excluded. SwiftDesign owns styling and primitive interactions; products supply
data, routes, permissions and actions. Specialized dependencies are documented in that guide.

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { DateTimePicker } from '@madsholme/ui'
const scheduledAt = ref<string | null>(null)
</script>
<template>
  <DateTimePicker v-model="scheduledAt" label="Scheduled start"
    locale="en-GB" time-zone="Europe/Copenhagen" />
</template>
```

A date/time value is an instant with an offset; date-only values use `DatePicker`. DateTimePicker
rejects ambiguous and missing DST times, supports inclusive min/max bounds and emits minute-precision
UTC instants. Products choose the timezone and locale explicitly. See the catalog for full
composition contracts and failure behavior.


## Status badges

`Badge` supports `default`, `secondary`, `destructive`, `outline`, `warning` and `success`.
Use the status variants for pills and counts instead of copying product-specific colors:

```vue
<Badge variant="warning">3 warnings</Badge>
<Badge variant="success">Passed</Badge>
```

Warning and success use semantic status borders and the themes package's contrast-checked
`--sd-warning-*` / `--sd-success-*` foreground/background pairs. Keep a visible status label
(or an accessible name on the surrounding control); color alone must not identify the status.
Badge remains an inline span. For tab pills, render it inside the tab trigger; the tab owns
selection, keyboard interaction and focus. Stable hooks are `ui-badge--warning` and
`ui-badge--success`. Existing variants are unchanged.


## Consumer integration options

See [consumer patterns](../../docs/consumer-patterns.md) for decorative spinners, animated
collapsibles, status alerts/progress, local date/time filters, required toggles, underline tabs,
compact/localized pagination, typed native selects, parent-owned profile width and scoped imports.

### jsdom chart setup

Tests that import chart exports can call `installJsdomShims()` from `@madsholme/ui/testing` in
setup before importing charts. This idempotent jsdom-only helper supplies missing ResizeObserver
and matchMedia, a zero-sized SVG getBBox fallback, and minimal canvas metrics; it does not emulate layout or rendering. It is never
exported by the root barrel. See [consumer patterns](../../docs/consumer-patterns.md) for lazy
text tooltips, cursor pagination, custom modal controls, semantic empty headings and pasted tags.
