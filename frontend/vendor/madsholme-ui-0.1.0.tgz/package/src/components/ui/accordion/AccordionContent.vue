<script setup lang="ts">
import type { AccordionContentProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import { AccordionContent } from 'reka-ui'
import { cn } from '../../../lib/utils'

const props = defineProps<AccordionContentProps & { class?: HTMLAttributes['class'] }>()

const delegatedProps = reactiveOmit(props, 'class')
</script>

<template>
  <!-- SwiftPatch names the inner (class-carrying) element "accordion-content"; the region wrapper gets its own slot. -->
  <AccordionContent
    v-bind="delegatedProps"
    data-slot="accordion-region"
    class="overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"
  >
    <div
      data-slot="accordion-content"
      :class="cn('pb-4 pt-0', props.class)"
    >
      <slot />
    </div>
  </AccordionContent>
</template>
