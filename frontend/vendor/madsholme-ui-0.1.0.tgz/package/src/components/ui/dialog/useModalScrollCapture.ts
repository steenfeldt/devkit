import { watch, type Ref } from 'vue'

/** Redirect wheel gestures over dialog chrome; Reka continues to own popup scroll locking. */
export function useModalScrollCapture({ open, modalRef, scrollRef }: {
  open: () => boolean
  modalRef: Ref<HTMLElement | null>
  scrollRef: Ref<HTMLElement | null>
}) {
  watch([open, modalRef, scrollRef], ([isOpen, modal, body], _, onCleanup) => {
    if (!isOpen || !modal || !body) return
    function onWheel(event: WheelEvent) {
      if (!body || !modal || event.defaultPrevented || !event.cancelable || event.ctrlKey || event.shiftKey || !event.deltaY || Math.abs(event.deltaX) > Math.abs(event.deltaY)) return
      if (!(event.target instanceof Node) || !modal.contains(event.target) || body.contains(event.target)) return
      const max = Math.max(0, body.scrollHeight - body.clientHeight)
      if (!max) return
      const lineHeight = Number.parseFloat(getComputedStyle(body).lineHeight) || 16
      const unit = event.deltaMode === 1 ? lineHeight : event.deltaMode === 2 ? body.clientHeight : 1
      body.scrollTop = Math.min(max, Math.max(0, body.scrollTop + event.deltaY * unit))
      event.preventDefault()
    }
    modal.addEventListener('wheel', onWheel, { capture: true, passive: false })
    onCleanup(() => modal.removeEventListener('wheel', onWheel, true))
  }, { immediate: true, flush: 'post' })
}
