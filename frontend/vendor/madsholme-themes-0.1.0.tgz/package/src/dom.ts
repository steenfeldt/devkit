import type { ThemeKey } from './registry'

export const prefersDarkQuery = '(prefers-color-scheme: dark)'

export interface ThemeAttributes {
  /** `dark` uses the `.dark` class. */
  readonly darkClass: boolean
  /** Every other theme except `light` uses `data-theme`. */
  readonly dataTheme: string | null
}

export function themeAttributes(theme: ThemeKey): ThemeAttributes {
  if (theme === 'dark') return { darkClass: true, dataTheme: null }
  if (theme === 'light') return { darkClass: false, dataTheme: null }
  return { darkClass: false, dataTheme: theme }
}

/** Sets the theme on `<html>` (or `root`), clearing whatever theme was there. */
export function applyThemeToDocument(theme: ThemeKey, root?: HTMLElement | null): void {
  const element = root ?? (typeof document === 'undefined' ? null : document.documentElement)
  if (!element) return
  const { darkClass, dataTheme } = themeAttributes(theme)
  element.classList.toggle('dark', darkClass)
  if (dataTheme) element.setAttribute('data-theme', dataTheme)
  else element.removeAttribute('data-theme')
}

export type MatchMedia = (query: string) => MediaQueryList

export function defaultMatchMedia(): MatchMedia | undefined {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return undefined
  return window.matchMedia.bind(window)
}

/** Whether the OS asks for a dark appearance. False when it cannot be determined. */
export function prefersDarkScheme(matchMedia: MatchMedia | undefined = defaultMatchMedia()): boolean {
  try {
    return matchMedia?.(prefersDarkQuery).matches === true
  } catch {
    return false
  }
}
