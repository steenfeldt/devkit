<script setup lang="ts">
import { ShieldAlert } from 'lucide-vue-next'
import { shellContainerClass } from './classes'

withDefaults(defineProps<{ label?: string }>(), { label: 'Working as administrator' })
</script>

<template>
  <div
    data-slot="admin-mode-banner"
    class="sd-admin-mode-banner border-b border-warning/40 bg-warning/12 text-foreground"
    role="status"
    aria-live="polite"
  >
    <div data-slot="admin-mode-banner-content" :class="[shellContainerClass, 'flex items-center gap-2 py-2 text-sm font-medium']">
      <ShieldAlert class="h-4 w-4 shrink-0" :stroke-width="1.9" aria-hidden="true" />
      <span>{{ label }}</span>
    </div>
  </div>
</template>
