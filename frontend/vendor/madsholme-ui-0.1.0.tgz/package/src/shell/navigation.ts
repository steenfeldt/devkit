import type { RouteLocationRaw } from 'vue-router'
import type { NavGroup } from '../types'

function pathOf(to: RouteLocationRaw | undefined): string | null {
  if (typeof to === 'string') return to.split(/[?#]/)[0] ?? null
  if (to && typeof to === 'object' && 'path' in to && typeof to.path === 'string') return to.path
  return null
}

/** The prefixes a group owns: its `match` list, else the paths of its own link and its items. */
export function groupPrefixes(group: NavGroup): string[] {
  if (group.match) return [...group.match]
  return [pathOf(group.to), ...(group.items ?? []).map((item) => pathOf(item.to))].filter((path): path is string => Boolean(path))
}

function owns(path: string, prefix: string): boolean {
  if (prefix === '/') return path === '/'
  const trimmed = prefix.replace(/\/$/, '')
  return path === trimmed || path.startsWith(`${trimmed}/`)
}

/**
 * The navigation group that owns a route path: the group with the longest matching prefix, so
 * `/queue/audit` can belong to "Info" while `/queue` belongs to "Jobs".
 */
export function currentNavGroupId(groups: readonly NavGroup[], path: string): string | null {
  let best: { id: string; length: number } | null = null
  for (const group of groups) {
    for (const prefix of groupPrefixes(group)) {
      if (owns(path, prefix) && (!best || prefix.length > best.length)) best = { id: group.id, length: prefix.length }
    }
  }
  return best?.id ?? null
}
