import { themes, type ThemeKey } from './registry'

export type ThemeOption = { readonly value: ThemeKey; readonly label: string }

/** Every theme, in profile-picker order. */
export const themeOptions: readonly ThemeOption[] = themes.map(({ key, label }) => ({ value: key, label }))

/** Alias of `themeOptions` (the products' existing name). */
export const persistedThemeOptions: readonly ThemeOption[] = themeOptions

/** Alias of `themeOptions` (the products' existing name). */
export const profileThemeOptions: readonly ThemeOption[] = themeOptions

/** The curated subset offered by the compact header picker. */
export const appShellThemeOptions: readonly ThemeOption[] = [
  { value: 'rn', label: 'RN' },
  { value: 'rn-light', label: 'RN Light' },
  { value: 'sw-light', label: 'SW Light' },
]

/** Alias of `appShellThemeOptions` (SwiftDeploy's name). */
export const compactThemeOptions: readonly ThemeOption[] = appShellThemeOptions

/** Copy for the "match system" toggle. */
export const systemThemeToggle = {
  label: 'Match system theme',
  description: 'Uses RN Light or RN to follow your device setting.',
} as const
