<script setup lang="ts">
import type { AlertDialogContentEmits, AlertDialogContentProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import {
  AlertDialogContent,
  AlertDialogOverlay,
  AlertDialogPortal,
  useForwardPropsEmits,
} from 'reka-ui'
import { cn } from '../../../lib/utils'
import { useDialogFocusReturn } from '../dialog/useDialogFocusReturn'
import { dialogContentClass, dialogOverlayClass } from '../dialog/styles'

defineOptions({
  inheritAttrs: false,
})

const props = defineProps<AlertDialogContentProps & { class?: HTMLAttributes['class'] }>()
const emits = defineEmits<AlertDialogContentEmits>()

const delegatedProps = reactiveOmit(props, 'class')

const forwarded = useForwardPropsEmits(delegatedProps, emits)
const { rememberFocus, restoreFocus } = useDialogFocusReturn()
</script>

<template>
  <AlertDialogPortal>
    <AlertDialogOverlay
      data-slot="alert-dialog-overlay"
      :class="dialogOverlayClass"
    />
    <AlertDialogContent
      data-slot="alert-dialog-content"
      v-bind="{ ...forwarded, ...$attrs }"
      @open-auto-focus="rememberFocus"
      @close-auto-focus="restoreFocus"
      :class="cn(dialogContentClass, props.class)"
    >
      <slot />
    </AlertDialogContent>
  </AlertDialogPortal>
</template>
