<script setup lang="ts">
import type { DropdownMenuTriggerProps } from 'reka-ui'
import { DropdownMenuTrigger, useForwardProps } from 'reka-ui'

const props = defineProps<DropdownMenuTriggerProps>()

const forwardedProps = useForwardProps(props)
</script>

<template>
  <!-- With as-child the child keeps its own data-slot (for example "button"). -->
  <DropdownMenuTrigger
    class="outline-hidden"
    v-bind="props.asChild ? forwardedProps : { ...forwardedProps, 'data-slot': 'dropdown-menu-trigger' }"
  >
    <slot />
  </DropdownMenuTrigger>
</template>
