import type { ThemePreference } from '@madsholme/themes'
import type { Component } from 'vue'
import type { ThemeChoice } from './theme/icons'
import type { RouteLocationRaw } from 'vue-router'

/** A link inside a navigation group. */
export interface NavLink {
  readonly id: string
  readonly label: string
  readonly to: RouteLocationRaw
  readonly icon?: Component
}

/**
 * A top-level navigation entry: a direct link (`to`) or a group of links (`items`). The product passes
 * them already filtered by its own permission rules.
 */
export interface NavGroup {
  readonly id: string
  readonly label: string
  readonly icon?: Component
  readonly to?: RouteLocationRaw
  readonly items?: readonly NavLink[]
  /** Path prefixes that make this entry current (the underline, `data-nav-current`). */
  readonly match?: readonly string[]
}

/** The signed-in user as the shell shows it. */
export interface ShellUser {
  readonly name: string
  /** Usually the primary group. */
  readonly subtitle?: string | null
}

export interface ImpersonationParty {
  readonly name: string
  readonly username?: string | null
}

export interface ImpersonationTarget {
  readonly id: string | number
  readonly name: string
  readonly username?: string | null
  /** Extra line, e.g. full name and email. */
  readonly detail?: string | null
}

export interface GlobalNotice {
  readonly id: string | number
  readonly message: string
  readonly category: 'information' | 'warning' | 'alert'
}


export interface ShellThemeState {
  /** Hide system when the product backend only accepts named themes. */
  allowSystem?: boolean
  preference: ThemePreference
  /** Quick choices; default "Match system", RN, RN Light, SW Light. */
  choices?: readonly ThemeChoice[]
  error?: string
}

export interface ShellAdminMode {
  active: boolean
  canToggle: boolean
  pending?: boolean
  error?: string
}

export interface ShellImpersonation {
  active: boolean
  actor?: ImpersonationParty | null
  effective?: ImpersonationParty | null
  canStart: boolean
  stopPending?: boolean
  stopError?: string
  targets?: readonly ImpersonationTarget[]
  searching?: boolean
  startPending?: boolean
  dialogError?: string
}
