<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { computed, nextTick, ref, watch } from 'vue'
import { cn } from '../../../lib/utils'
import type { CollapsibleContentProps } from 'reka-ui'
import { Primitive, Presence, injectCollapsibleRootContext, useForwardExpose, useId } from 'reka-ui'

const props = withDefaults(defineProps<CollapsibleContentProps & { class?: HTMLAttributes['class']; animated?: boolean }>(), { animated: true })
const context = injectCollapsibleRootContext()
context.contentId ||= useId(undefined, 'reka-collapsible-content')
const { forwardRef, currentElement } = useForwardExpose()
const transitioned = ref(false)
const height = ref(0)
const width = ref(0)
const state = computed(() => context.open.value ? 'open' : 'closed')
// Measure only real transitions. No mount frame or timer, including retained closed content.
watch(context.open, async () => {
  transitioned.value = true
  if (!props.animated) return
  await nextTick()
  const node = currentElement.value
  if (!node) return
  const { animationName, transitionDuration } = node.style
  node.style.animationName = 'none'
  node.style.transitionDuration = '0s'
  const rect = node.getBoundingClientRect()
  height.value = rect.height
  width.value = rect.width
  node.style.animationName = animationName
  node.style.transitionDuration = transitionDuration
}, { flush: 'pre' })
function reveal() {
  if (!context.open.value) context.onOpenToggle()
}
</script>

<template>
  <Presence v-slot="{ present }" :present="forceMount || context.open.value" force-mount>
    <Primitive :id="context.contentId" :ref="forwardRef" :as="as" :as-child="asChild"
      data-slot="collapsible-content" :data-state="state" :data-disabled="context.disabled?.value ? '' : undefined"
      :hidden="!present ? context.unmountOnHide.value ? '' : 'until-found' : undefined"
      :style="{ animationName: animated && !transitioned ? 'none' : undefined, '--reka-collapsible-content-height': `${height}px`, '--reka-collapsible-content-width': `${width}px` }"
      :class="cn(animated && 'sd-collapsible-content overflow-hidden', props.class)" @beforematch="reveal">
      <slot v-if="context.unmountOnHide.value ? present : true" />
    </Primitive>
  </Presence>
</template>
