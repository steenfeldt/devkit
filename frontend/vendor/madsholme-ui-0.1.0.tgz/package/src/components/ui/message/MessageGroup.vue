<script lang='ts' setup>
import type { PrimitiveProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { cn } from "../../../lib/utils"
import { Primitive } from "reka-ui"

interface Props extends PrimitiveProps {
  class?: HTMLAttributes["class"]
}
const props = withDefaults(defineProps<Props>(), {
  as: "div",
})
</script>

<template>
  <Primitive
    data-slot="message-group"
    :as="as"
    :as-child="asChild"
    :class="cn(
      'gap-2 flex min-w-0 flex-col',
      props.class,
    )"
  >
    <slot />
  </Primitive>
</template>
