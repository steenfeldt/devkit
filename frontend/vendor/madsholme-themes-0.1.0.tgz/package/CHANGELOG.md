# @madsholme/themes

## 0.1.0

### Minor Changes

- 91e0acd: First release: the shared themes extracted from SwiftDeploy b49e160, reconciled with SwiftConfig
  b47bfef and SwiftPatch ba910c8 (see docs/theme-reconciliation.md).

  - All 39 themes. Token values are SwiftDeploy's, verbatim; all three products carry identical
    values.
  - Polish layer, header themes and per-theme effects from SwiftDeploy, on package hooks
    (`.sd-page-title`, `.sd-panel-heading`, `.sd-stat-value`, `.sd-table`). Product-only rules stay
    in the products.
  - WCAG contrast layer from SwiftPatch, renamed from `--swiftpatch-*` to `--sd-*`.
  - **Colour tokens are `oklch()`.** Every colour token is a full `oklch()` colour used as
    `var(--x)`; alpha goes through `color-mix(in srgb, var(--x) N%, transparent)` or Tailwind slash
    utilities, and every gradient states its interpolation space: `in srgb` where its stops were
    legacy colours, `in oklab` where a stop already was a `color-mix()`. The shadow colour is
    `--sd-shadow-color`. Browsers: Chrome and Edge 111+, Safari 16.4+, Firefox 128+ (Tailwind 4's
    baseline; it also covers `oklch()`, `color-mix()` and gradient colour interpolation). The README
    has the migration table and a checklist for product code.
  - **Differences from the products' copies:** HSL triplets (`199 70% 36%`) became `oklch()`
    colours (`hsl(var(--x))` is now `var(--x)`), and `--sd-shadow-rgb` became `--sd-shadow-color`.
    Rendered colours are equal at 8 bits; see docs/theme-reconciliation.md section 12 for the
    residual differences (dithering, glow halos, OKLab transitions).
  - Theme registry, picker options, legacy aliases, `darkThemeKeys` and header/page surface
    metadata (SwiftPatch's corrected table).
  - Tailwind 4.3 theme: `css/tailwind-theme.css` (generated `@theme inline` tokens, the `dark:`
    variant for every dark theme, Tailwind 3.4's font stacks and line heights) and
    `css/tailwind-compat.css` (v3 Preflight behaviour). There is no JS preset and no
    `@madsholme/themes/tailwind` export.
  - Framework-free theme controller with a product-supplied profile adapter.
  - Pre-paint boot script and Vite plugin (`@madsholme/themes/vite`).

  Requires Tailwind 4.3 (`tailwindcss ^4.3.0` peer). Use this import sequence instead of
  `@import 'tailwindcss'` (products without Preflight leave out the Preflight and compat lines;
  the README explains the order):

  ```css
  @layer theme, base, components, utilities;
  @import "tailwindcss/theme.css" layer(theme);
  @import "tailwindcss/preflight.css" layer(base);
  @import "@madsholme/themes/css/tailwind-compat.css" layer(base);
  @import "@madsholme/themes/css/tailwind-theme.css";
  @import "@madsholme/themes/css" layer(utilities);
  @import "@madsholme/themes/css/overrides.css" layer(utilities);
  @import "tailwindcss/utilities.css" layer(utilities);
  ```

  Tailwind 4's OKLCH default palette (for classes such as `bg-teal-800`) is used as is.

  Upgrading classes: if you run `@tailwindcss/upgrade`, do not accept its `rounded*` renames. Keep
  `rounded`, `rounded-sm`, `rounded-md`, `rounded-lg` and `rounded-xl` unchanged, because the theme
  defines those radii and bare `rounded` is still 0.25rem. Its `shadow`, `outline`, `ring` and
  `backdrop-blur` renames are correct.

  Behavior changes for adopters, compared with the products' current copies:

  - **Match system.** A new `system` preference shows RN Light (light OS) or RN (dark OS) and
    follows OS changes live. It is the default when nothing is stored, replacing `light`.
    Products save `system` to the user's profile; their backends must accept it first.
  - **Dim survives a reload.** SwiftDeploy and SwiftConfig resolved a saved `dim` to `light`.
  - **Latest wins.** Every selection applies immediately; at most one save is in flight, and
    only the newest queued selection is sent. Pickers no longer need to disable while saving
    (SwiftPatch disabled them).
  - **No saves before the profile is known or after logout.** This was already SwiftPatch's
    behavior.
  - **Impersonation.** The initiator always keeps their own theme. In
    `keep-initiator-locally` mode the impersonated user's theme is ignored and nothing is saved.
  - **`[data-active="true"]`.** The header active state no longer uses the bare `[data-active]`
    selector, which also matched `data-active="false"`.
  - **Corrected surface metadata.** RN Light and Orbital headers are dark.
  - **Header contrast.** Seven colour pairs in coloured headers now meet WCAG AA (4.5:1). They are
    used by hovered and open header controls, and by Alex's secondary header text. Only
    header-scoped tokens change (values in HSL, as the products write them; the package stores
    them as `oklch()`):
    - Alex: `--accent` 316 62% 56% → 316 62% 40% (hover is now darker than the header);
      `--muted-foreground` 320 60% 93% → 320 60% 98%;
    - SW Light `--accent` 36% → 31%, Cosmic Light 66% → 61%, RN Light 44% → 36% (lightness);
    - Rose Pine header `--primary` 197 49% 38% → 33%. The page-level primary is unchanged;
    - Alex hovered and open header controls: the overlay fix (`hsl(0 0% 100% / 0.18)` →
      `hsl(316 70% 20% / 0.18)`) was superseded before release by the flat top bars; the overlay is
      now transparent and the text sits on the header itself (see the "Second hue, info status, a
      visible accent step and flat top bars" changeset).

  Known, unchanged from SwiftDeploy, planned for 0.2.0 (visible changes):

  - 16 token blocks lack `color-scheme`.
  - Themed menus target the `data-radix-popper-content-wrapper` attribute, which Reka UI 2 no
    longer renders.
  - `dim` has no `--sidebar-*` tokens.
  - Rose Pine's `.bg-primary` effect text is 3.8:1. Its highlighted menu item inherits light text
    onto the light accent.
  - A hovered top-navigation direct link shows no background in SW Light, RN Light and Midnight
    Mirage. `.site-header .bg-background { background-color: transparent }` (0,3,0) beats the
    link's `hover:bg-accent` (0,2,0). Other themes with that rule have a hover override.

- b1cab2f: Add an animation profile preference, enabled by default. Themes exports a framework-free
  animation controller with local cache, optional profile persistence, rollback and identity handling,
  plus an optional animation cache key for pre-paint boot. The explicit off override suppresses CSS
  motion while retaining continuous loading indicators and existing OS reduced-motion protection.
  UI exports ProfileAnimationCard and useAnimationState. Consumers adopting profile persistence
  provide a boolean backend field (default true) and save adapter; existing theme APIs are unchanged.
- 84580ba: Support products whose profile backend only accepts named themes. Add opt-in `allowSystem: false`
  and `fallbackTheme` controller/boot options, hide system selection in the shell and profile card,
  and keep existing system-aware defaults. Minify the generated boot script with the existing
  esbuild toolchain to retain its size budget.

  Make Input and Textarea emit model changes synchronously while retaining uncontrolled defaults, so consumer forms can clear submitted values reliably. Mirror modal aria-hidden on descendants as well as the root, keeping hidden page content inert when a retained live status banner prevents its ancestor from being hidden.

  Allow a named fallback for missing/invalid values while retaining explicit system matching, so existing product defaults survive adoption.

- 3574bbb: Second hue, info status, a visible accent step and flat top bars (docs/theme-reconciliation.md §13).

  - **New tokens in every theme:** `--highlight` / `--highlight-foreground` (the theme's second
    colour, picked from its own palette) and `--info` / `--info-foreground` (the fourth status, blue or
    cyan per theme). Tailwind colour groups `highlight` and `info`: `bg-highlight`, `text-highlight`,
    `border-highlight`, `text-highlight-foreground`, `bg-info`, `text-info`, `border-info`,
    `text-info-foreground` and the other colour utilities.
  - **New contrast pair** `--sd-info-background` / `--sd-info-foreground`, defaulting to the card and
    `--info`, with card text where info on the card is below AA: colorblind, nord, solarized-light,
    gruvbox-material-light, solarized-dark, catppuccin-latte, rose-pine-dawn.
  - **Stat tiles** (`.sd-card.sd-stat`) are tinted with `--highlight` when no `--sd-stat-color` is set
    inline. Ink stays greyscale; High Contrast and Signal stay flat.
  - **`--accent` changed in 21 themes** where it equalled `--secondary` / `--muted` or read as
    off-theme, so hovered, selected and open surfaces are a visible tint (HSL as the products write
    it → the package's `oklch()`; `--accent-foreground` listed only where it changed):

    - light `--accent` `210 40% 96.1%` → `oklch(0.945 0.028 232)`
    - dark `--accent` `217.2 32.6% 17.5%` → `oklch(0.33 0.055 262)`
    - dim `--accent` `220 13% 28%` → `oklch(0.44 0.045 250)`
    - rn `--accent` `207 40% 20%` → `oklch(0.37 0.065 232)`
    - rn-light `--accent` `199 55% 90%` → `oklch(0.9 0.05 227)`
    - pink `--accent` `322.19 60.33% 23.73%` → `oklch(0.41 0.13 340)`
    - soft-pink `--accent` `335.00 75.00% 93.73%` → `oklch(0.91 0.05 345)`
    - aurora `--accent` `164.12 51.52% 12.94%` → `oklch(0.335 0.058 190)`
    - graphite `--accent` `240.0 5.3% 26.1%` → `oklch(0.43 0.025 285)`
    - dracula `--accent` `231.8 13.9% 31.0%` → `oklch(0.44 0.04 280)`
    - nova-drift `--accent` `257 74% 48%` → `oklch(0.4546 0.1 283.91)` (same violet, a tenth of the chroma)
    - rose-pine `--accent` `267 57% 78%` → `oklch(0.3717 0.0358 291.1)` (highlight med `#403d52`);
      `--accent-foreground` `249 22% 12%` → `oklch(0.9088 0.0298 289.97)` (text `#e0def4`)
    - rose-pine-dawn `--accent` `25.0 35.3% 93.3%` → `oklch(0.892 0.0057 31.05)` (highlight med `#dfdad9`)
    - nord `--accent` `220.0 16.8% 31.6%` → `oklch(0.4523 0.0352 264.13)` (nord3 `#4c566a`)
    - tokyo-night `--accent` `226.2 21.7% 23.5%` → `oklch(0.4094 0.0546 274.27)` (terminal_black `#414868`)
    - cyberpunk `--accent` `191 100% 50%` → `oklch(0.36 0.06 244.74)` (the header hover box colour, lifted);
      `--accent-foreground` `255 35% 8%` → `oklch(0.9689 0.0218 219.7)` (= `--foreground`)
    - ember `--accent` `356 56% 50%` → `oklch(0.52 0.09 46.92)` (faded amber on the code-num hue)
    - gruvbox-material-dark `--accent` `166.5 23.2% 58.6%` → `oklch(0.411 0.0115 51.87)` (bg_statusline3 `#504945`);
      `--accent-foreground` `0.0 0.0% 15.7%` → `oklch(0.8108 0.0567 81.23)` (fg0 `#d4be98`)
    - gruvbox-material-light `--accent` `322.2 22.3% 47.5%` → `oklch(0.8507 0.048 83.9)` (bg5 `#ddccab`);
      `--accent-foreground` `0.0 0.0% 100.0%` → `oklch(0.4262 0.0502 51.91)` (fg0 `#654735`)
    - magic-mike `--accent` `42 39% 35%` → `oklch(0.47 0.06 33.3)` (the `--border` hue as a mid brown)
    - orbital-light `--accent` `202 53% 69%` → `oklch(0.87 0.06 333.6)` (sidebar-primary hue, light)

    Signal and Tron Light keep accent = primary. Every `--accent-foreground` is at AA on its new
    surface, so the Orbital Light contrast override (`--sd-active-navigation-foreground` forced to
    black, from SwiftPatch) is dropped.

  - **Flat top bars (visible change).** In Alex, Solar Bloom, Rosé Pine, Cosmic Light, Nova Drift,
    Orbital Light, Tron Light, Cyberpunk and Ember, header items are no longer boxed: the current
    top-nav item shows only its underline (the `[data-active="true"]` selector is removed from the
    hover rule in Rosé Pine, Cosmic Light, Nova Drift, Orbital Light, Tron Light, Cyberpunk and Ember;
    Alex and Solar Bloom were already flat there); hovered, focused and open items paint a transparent
    background (`!important` where SwiftDeploy had it) instead of their tinted box, and Tron Light
    drops its inset ring; keyboard focus shows a 2px `currentColor` outline (the control's text
    colour; measured 4.90 to 18.29:1 on every header stop, the test requires 3:1) with 2px offset.
    Text colours are unchanged. This replaces the Alex hover overlay fix (`hsl(316 70% 20% / 0.18)`)
    listed under "Header contrast" in the first-release changeset; the other header-scoped values
    stand.
  - Details, sources and the guarding tests: docs/theme-reconciliation.md §13.

- f03aea0: Shell motion in the polish layer (docs/theme-reconciliation.md §14). Additive: new rules only, no
  SwiftDeploy rule edited, no selector, hook or token removed.

  - **New token** `--sd-motion: .18s` on `:root`, the shared timing next to the existing `--sd-ease`.
  - **New rules in `css/polish.css`:**
    - `.site-header [data-site-header-interactive]` transitions `background-color`, `color`,
      `border-color`, `box-shadow` and `transform` over `var(--sd-motion)`, so hover, press, focus
      ring and the open state ease on the shared timing (on header controls this replaces the
      Button's `duration-150`).
    - `@keyframes sd-reveal-down` (opacity 0 and `translateY(-.25rem)` to opacity 1), played once on
      mount by `[data-slot="admin-mode-banner"]` and `[data-slot="global-notification-banner"]`
      over `calc(var(--sd-motion) * 1.5)` with `var(--sd-ease)` and `both` fill.
    - `.sd-card.sd-stat` transitions `background`, `transform`, `box-shadow` and `border-color` over
      `var(--sd-motion) var(--sd-ease)`; `.sd-lift` moves its `transition-duration` to
      `var(--sd-motion)`.
  - **Reduced motion.** A second `@media (prefers-reduced-motion: reduce)` block collapses every hook
    above, the ui navigation-menu chevron (`[data-slot="navigation-menu-trigger-icon"]`) and every
    `tw-animate-css` `animate-*` utility to 0.01 ms; the continuous loaders `animate-spin` and
    `animate-pulse` keep running. The selector mechanism is in docs/theme-reconciliation.md §14.
  - **Hooks now targeted by the package CSS** (listed in the public surface):
    `data-slot="admin-mode-banner"`, `data-slot="global-notification-banner"`,
    `data-slot="navigation-menu-trigger-icon"`, `animate-spin`, `animate-pulse`.
  - The package CSS stays framework-free. `tw-animate-css` itself is imported by the consumer, after
    the Tailwind theme import; the themes README shows the line.
