<script setup lang="ts">
import { profileThemeOptions, systemThemeToggle, type ThemeKey, type ThemePreference } from '@madsholme/themes'
import { computed, useId } from 'vue'
import { Card, CardContent } from '../components/ui/card'
import { Switch } from '../components/ui/switch'
import { withThemeIcons, type ThemeChoice } from '../theme/icons'
import ProfileCardTitle from './ProfileCardTitle.vue'

const props = withDefaults(defineProps<{
  /** What the user chose: a theme key or `system`. */
  preference: ThemePreference
  /** What is on screen (the resolved theme while following the system). */
  theme: ThemeKey
  choices?: readonly ThemeChoice[]
  allowSystem?: boolean
  saving?: boolean
  error?: string
  title?: string
  description?: string
}>(), {
  choices: () => withThemeIcons(profileThemeOptions),
  allowSystem: true,
  saving: false,
  error: '',
  title: 'Theme Settings',
  description: 'Choose your preferred interface theme. Changes apply immediately and are saved to your profile.',
})

const emit = defineEmits<{ select: [theme: ThemeKey]; 'follow-system': [on: boolean] }>()
const titleId = `profile-theme-${useId()}`
const switchId = `profile-theme-system-${useId()}`
const followsSystem = computed(() => props.preference === 'system')
</script>

<template>
  <Card data-slot="profile-theme-card" :aria-labelledby="titleId">
    <ProfileCardTitle :id="titleId" :title="title" />
    <CardContent>
      <p class="mb-4 mt-0 text-xs text-muted-foreground">{{ description }}</p>
      <div v-if="allowSystem" data-slot="profile-theme-system" class="mb-4 flex items-start justify-between gap-4 rounded-lg border p-3">
        <div class="min-w-0">
          <label :for="switchId" class="text-sm font-medium">{{ systemThemeToggle.label }}</label>
          <p class="m-0 text-xs text-muted-foreground">{{ systemThemeToggle.description }}</p>
        </div>
        <Switch :id="switchId" :model-value="followsSystem" @update:model-value="emit('follow-system', Boolean($event))" />
      </div>
      <p v-if="error" role="alert" class="mb-3 mt-0 text-sm font-medium text-destructive">{{ error }}</p>
      <p v-if="saving" role="status" class="mb-3 mt-0 text-xs text-muted-foreground">Saving…</p>
      <div role="group" :aria-labelledby="titleId" class="grid grid-cols-3 gap-2">
        <button
          v-for="choice in choices"
          :key="choice.value"
          type="button"
          data-slot="profile-theme-choice"
          :data-theme-choice="choice.value"
          :title="choice.label"
          :aria-pressed="!followsSystem && preference === choice.value"
          :aria-current="followsSystem && theme === choice.value ? 'true' : undefined"
          :class="[
            'flex flex-col items-center justify-center gap-1.5 rounded-lg p-3 text-xs transition-colors',
            !followsSystem && preference === choice.value
              ? 'bg-accent font-semibold text-accent-foreground'
              : followsSystem && theme === choice.value
                ? 'text-foreground ring-1 ring-inset ring-border'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground',
          ]"
          @click="emit('select', choice.value as ThemeKey)"
        >
          <component :is="choice.icon" class="h-4 w-4" aria-hidden="true" />
          {{ choice.label }}
          <span v-if="followsSystem && theme === choice.value" class="text-[10px] text-muted-foreground">(system)</span>
        </button>
      </div>
    </CardContent>
  </Card>
</template>
