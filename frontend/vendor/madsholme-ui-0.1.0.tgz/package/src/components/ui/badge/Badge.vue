<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import type { BadgeVariants } from '.'
import { cn } from '../../../lib/utils'
import { badgeVariants } from '.'

// A span (not a div) so a badge can sit inside inline text.
const props = withDefaults(defineProps<{
  variant?: BadgeVariants['variant']
  class?: HTMLAttributes['class']
}>(), {
  variant: 'default',
  class: undefined,
})
</script>

<template>
  <span
    data-slot="badge"
    :class="cn('ui-badge', `ui-badge--${variant}`, badgeVariants({ variant }), props.class)"
  ><slot /></span>
</template>
