<script setup lang="ts">
import { onBeforeUnmount, ref, shallowRef, watch } from 'vue'
import { Primitive, TooltipProvider, TooltipRoot } from 'reka-ui'
import LazyTextTooltipBridge from './LazyTextTooltipBridge.vue'

defineProps<{ text: string }>()
const trigger = shallowRef<HTMLElement>()
const bridge = shallowRef<InstanceType<typeof LazyTextTooltipBridge>>()
let intent: 'hover' | 'focus' | undefined
const pointerDown = ref(false)
function activate(event: Event, reason: 'hover' | 'focus') {
  if (reason === 'hover' && (event as PointerEvent).pointerType === 'touch') return
  if (reason === 'focus' && pointerDown.value) return
  const changed = intent !== reason
  intent = reason
  trigger.value = event.currentTarget as HTMLElement
  if (changed) runIntent()
}
function runIntent() {
  if (intent === 'focus') bridge.value?.open()
  else if (intent === 'hover') bridge.value?.enter()
}
let activationFrame: number | undefined
watch(bridge, () => {
  // Browser focus can scroll the trigger into view. Open after that scroll event,
  // otherwise Reka's scroll-dismissal immediately closes a freshly mounted tooltip.
  if (intent === 'focus') activationFrame = requestAnimationFrame(runIntent)
  else runIntent()
}, { flush: 'post' })
function releasePointer() { pointerDown.value = false }
function pressPointer() {
  pointerDown.value = true
  close()
  document.addEventListener('pointerup', releasePointer, { once: true })
  document.addEventListener('pointercancel', releasePointer, { once: true })
}
onBeforeUnmount(() => {
  if (activationFrame !== undefined) cancelAnimationFrame(activationFrame)
  document.removeEventListener('pointerup', releasePointer)
  document.removeEventListener('pointercancel', releasePointer)
})
function leave() { intent = undefined; bridge.value?.leave() }
function close() { intent = undefined; bridge.value?.close() }
</script>

<template>
  <Primitive as-child @pointermove="activate($event, 'hover')" @pointerenter="activate($event, 'hover')"
    @focus="activate($event, 'focus')" @pointerleave="leave" @blur="close" @click="close"
    @pointerdown="pressPointer">
    <slot />
  </Primitive>
  <TooltipProvider v-if="trigger" :delay-duration="200">
    <TooltipRoot><LazyTextTooltipBridge ref="bridge" :trigger="trigger" :text="text" /></TooltipRoot>
  </TooltipProvider>
</template>
