<script setup lang="ts">
import { usePaginationOptions } from "./context"
const options = usePaginationOptions()
import type { PaginationPrevProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import type { ButtonVariants } from "../button"
import { ChevronLeftIcon } from "lucide-vue-next"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { PaginationPrev, useForwardProps } from "reka-ui"
import { buttonVariants } from "../button"

const props = withDefaults(defineProps<PaginationPrevProps & {
  size?: ButtonVariants["size"]
  class?: HTMLAttributes["class"]
}>(), {
  size: "default",
})

const delegatedProps = reactiveOmit(props, "class", "size")
const forwarded = useForwardProps(delegatedProps)
</script>

<template>
  <PaginationPrev
    data-slot="pagination-previous"
    :class="cn(buttonVariants({ variant: 'ghost', size }), 'gap-1 px-2.5 sm:pr-2.5', props.class)"
    v-bind="forwarded"
    :aria-label="options.labels.previous"
  >
    <slot>
      <ChevronLeftIcon />
      <span class="hidden sm:block">{{ options.labels.previous }}</span>
    </slot>
  </PaginationPrev>
</template>
