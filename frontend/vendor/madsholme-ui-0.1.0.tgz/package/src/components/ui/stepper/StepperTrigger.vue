<script lang="ts" setup>
import type { StepperTriggerProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { StepperTrigger, useForwardProps, injectStepperRootContext, injectStepperItemContext } from "reka-ui"

const props = defineProps<StepperTriggerProps & { class?: HTMLAttributes["class"] }>()

const root = injectStepperRootContext()
const item = injectStepperItemContext()
let pointerHandled = false
function rememberPointer(event: MouseEvent) {
  pointerHandled = event.button === 0 && !event.ctrlKey && !event.defaultPrevented && !item.disabled.value && item.isFocusable.value
}
function resetPointer() { pointerHandled = false }
function activate(event: MouseEvent) {
  if (pointerHandled) { pointerHandled = false; return }
  if (event.defaultPrevented || event.ctrlKey || event.button !== 0 || item.disabled.value || !item.isFocusable.value) return
  if (root.modelValue.value !== item.step.value) root.changeModelValue(item.step.value)
}

const delegatedProps = reactiveOmit(props, "class")

const forwarded = useForwardProps(delegatedProps)
</script>

<template>
  <StepperTrigger
    @mousedown="rememberPointer"
    @keydown="resetPointer"
    @pointercancel="resetPointer"
    @click="activate"
    v-bind="forwarded"
    :class="cn('p-1 flex flex-col items-center text-center gap-1 rounded-md', props.class)"
  >
    <slot />
  </StepperTrigger>
</template>
