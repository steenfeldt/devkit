<script setup lang="ts">
import { useId, type Component } from 'vue'
import { Badge } from '../components/ui/badge'
import { Card, CardContent } from '../components/ui/card'
import ProfileCardTitle from './ProfileCardTitle.vue'
import type { ProfileBadge } from './types'

withDefaults(defineProps<{ title: string; icon?: Component; badges: readonly ProfileBadge[]; emptyLabel?: string }>(), {
  icon: undefined,
  emptyLabel: 'None',
})
const titleId = `profile-card-${useId()}`
</script>

<template>
  <Card data-slot="profile-badge-card" :aria-labelledby="titleId">
    <ProfileCardTitle :id="titleId" :title="title" :icon="icon" />
    <CardContent class="flex flex-wrap items-center gap-2">
      <Badge v-if="!badges.length" variant="outline">{{ emptyLabel }}</Badge>
      <Badge v-for="badge in badges" :key="badge.key" :variant="badge.variant ?? 'secondary'" class="gap-1">
        <component :is="badge.icon" v-if="badge.icon" class="h-3 w-3" aria-hidden="true" />
        {{ badge.label }}
      </Badge>
    </CardContent>
  </Card>
</template>
