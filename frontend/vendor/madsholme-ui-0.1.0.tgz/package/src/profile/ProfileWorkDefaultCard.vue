<script setup lang="ts">
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'

withDefaults(defineProps<{
  saving?: boolean
  error?: string
  title?: string
  description?: string
}>(), {
  saving: false,
  error: '',
  title: 'Work default',
  description: 'Applies to new login sessions. Your current mode stays unchanged.',
})

const mode = defineModel<'user' | 'admin'>({ required: true })
</script>

<template>
  <Card data-slot="profile-work-default-card">
    <CardHeader>
      <CardTitle as="h2">{{ title }}</CardTitle>
      <CardDescription>{{ description }}</CardDescription>
    </CardHeader>
    <CardContent class="flex flex-wrap items-center gap-3">
      <div class="flex gap-2" role="group" :aria-label="title">
        <Button type="button" :variant="mode === 'user' ? 'default' : 'outline'" :aria-pressed="mode === 'user'" :disabled="saving" @click="mode = 'user'">User</Button>
        <Button type="button" :variant="mode === 'admin' ? 'default' : 'outline'" :aria-pressed="mode === 'admin'" :disabled="saving" @click="mode = 'admin'">Admin</Button>
      </div>
      <span v-if="saving" role="status" class="text-sm text-muted-foreground">Saving…</span>
      <p v-if="error" role="alert" class="m-0 w-full text-sm text-destructive">{{ error }}</p>
    </CardContent>
  </Card>
</template>
