<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { cn } from '../../../lib/utils'

const props = withDefaults(defineProps<{ class?: HTMLAttributes['class'] }>(), { class: undefined })
</script>

<template>
  <p
    data-slot="card-description"
    :class="cn('ui-card-description m-0 text-sm text-muted-foreground', props.class)"
  >
    <slot />
  </p>
</template>
