import {
  defaultSystemThemes,
  systemPreference,
  themeKeys,
  type SystemThemes,
  type ThemeKey,
  type ThemePreference,
} from './registry'

/** Values that older frontends and backends stored, mapped to their canonical theme. */
export const legacyThemeAliases: Readonly<Record<string, ThemeKey>> = Object.freeze({
  darkv2: 'midnight-mirage',
  darkv3: 'dim',
  'mike-magic': 'magic-mike',
  rnv2: 'rn-light',
  lightv2: 'sw-light',
})

const keySet: ReadonlySet<string> = new Set(themeKeys)

export function isThemeKey(value: unknown): value is ThemeKey {
  return typeof value === 'string' && keySet.has(value)
}

export function isThemePreference(value: unknown): value is ThemePreference {
  return value === systemPreference || isThemeKey(value)
}

/**
 * Normalizes a stored or backend value. Canonical keys and `system` pass through, legacy
 * aliases map to their theme, and anything else (missing, empty, unknown) means nothing was
 * chosen, which is `system`.
 */
export function resolvePreference(value: string | null | undefined): ThemePreference {
  if (!value) return systemPreference
  if (isThemePreference(value)) return value
  return Object.prototype.hasOwnProperty.call(legacyThemeAliases, value) ? legacyThemeAliases[value]! : systemPreference
}

export function resolveSystemTheme(prefersDark: boolean, systemThemes: SystemThemes = defaultSystemThemes): ThemeKey {
  return prefersDark ? systemThemes.dark : systemThemes.light
}

/** The theme to show for a stored or backend value. */
export function resolveTheme(
  value: string | null | undefined,
  prefersDark: boolean,
  systemThemes: SystemThemes = defaultSystemThemes,
): ThemeKey {
  const preference = resolvePreference(value)
  return preference === systemPreference ? resolveSystemTheme(prefersDark, systemThemes) : preference
}

/** The value sent to a backend: the canonical key, or `system`. */
export function toApiTheme(preference: ThemePreference): string {
  return preference
}
