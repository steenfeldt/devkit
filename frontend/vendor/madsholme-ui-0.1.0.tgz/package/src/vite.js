/** Prebundle the CommonJS-bearing chart graph used by source-distributed UI exports. */
export function uiDependencies() {
  return {
    name: '@madsholme/ui:dependencies',
    config() {
      return {
        optimizeDeps: {
          include: ['@madsholme/ui > @unovis/ts', '@madsholme/ui > @unovis/vue'],
        },
      }
    },
  }
}
