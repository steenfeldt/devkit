<script setup lang="ts">
import { Search, UserCheck } from 'lucide-vue-next'
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Sheet, SheetContent, SheetDescription, SheetFooter, SheetHeader, SheetTitle } from '../components/ui/sheet'
import type { ImpersonationTarget } from '../types'

const props = withDefaults(defineProps<{
  open: boolean
  /** Results for the latest `search` the product received. */
  targets?: readonly ImpersonationTarget[]
  /** A search is running. */
  searching?: boolean
  /** A start request is running; the dialog cannot be closed. */
  pending?: boolean
  /** Message written by the product, e.g. "That user is no longer available. Search again." */
  error?: string
  /** Debounce before `search` is emitted. */
  debounceMs?: number
  minLength?: number
}>(), { targets: () => [], searching: false, pending: false, error: '', debounceMs: 250, minLength: 2 })

const emit = defineEmits<{
  'update:open': [open: boolean]
  search: [term: string]
  start: [id: ImpersonationTarget['id']]
  /** The dialog closed; the shell moves focus back (there is no trigger to return to). */
  closed: []
}>()

const term = ref('')
const searchedTerm = ref('')
const searchInput = ref<{ $el: HTMLInputElement } | null>(null)
let timer: ReturnType<typeof setTimeout> | undefined

const trimmed = computed(() => term.value.trim())
const needsMoreInput = computed(() => trimmed.value.length > 0 && trimmed.value.length < props.minLength)
const showEmpty = computed(() => !props.searching && !props.error && searchedTerm.value.length >= props.minLength
  && searchedTerm.value === trimmed.value && props.targets.length === 0)

const isOpen = computed({
  get: () => props.open,
  set: (open: boolean) => { if (open || !props.pending) emit('update:open', open) },
})

function clearTimer(): void {
  if (timer) clearTimeout(timer)
  timer = undefined
}

watch(term, () => {
  clearTimer()
  if (trimmed.value.length < props.minLength) return
  timer = setTimeout(() => {
    searchedTerm.value = trimmed.value
    emit('search', trimmed.value)
  }, props.debounceMs)
})

watch(() => props.open, (open) => {
  if (open) return
  clearTimer()
  term.value = ''
  searchedTerm.value = ''
})

onBeforeUnmount(clearTimer)

function blockWhilePending(event: Event): void {
  if (props.pending) event.preventDefault()
}

function onCloseAutoFocus(event: Event): void {
  event.preventDefault()
  emit('closed')
}

function focusSearch(event: Event): void {
  event.preventDefault()
  searchInput.value?.$el.focus()
}
</script>

<template>
  <Sheet v-model:open="isOpen">
    <SheetContent
      id="impersonation-dialog"
      side="right"
      class="flex w-full flex-col sm:max-w-lg"
      data-testid="impersonation-dialog"
      @open-auto-focus="focusSearch"
      @close-auto-focus="onCloseAutoFocus"
      @escape-key-down="blockWhilePending"
      @pointer-down-outside="blockWhilePending"
      @interact-outside="blockWhilePending"
    >
      <SheetHeader>
        <SheetTitle>Impersonate user</SheetTitle>
        <SheetDescription>Search by username or full name, then choose the account to act as.</SheetDescription>
      </SheetHeader>

      <div data-slot="impersonation-dialog-body" class="space-y-5 py-6">
        <div>
          <label for="impersonation-search" class="text-sm font-medium">User search</label>
          <div class="relative mt-2">
            <Search class="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              id="impersonation-search"
              ref="searchInput"
              v-model="term"
              class="pl-9"
              placeholder="Search by username or full name"
              autocomplete="off"
              :aria-describedby="needsMoreInput ? 'impersonation-search-hint' : undefined"
            />
          </div>
          <p v-if="needsMoreInput" id="impersonation-search-hint" class="m-0 mt-2 text-xs text-muted-foreground">
            Enter at least {{ minLength }} characters.
          </p>
        </div>

        <p v-if="error" role="alert" class="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {{ error }}
        </p>

        <div class="space-y-2">
          <p v-if="searching" role="status" class="m-0 rounded-md border border-border px-3 py-4 text-sm text-muted-foreground">
            Searching users…
          </p>
          <p v-else-if="showEmpty" role="status" class="m-0 rounded-md border border-border px-3 py-4 text-sm text-muted-foreground">
            No matching users.
          </p>
          <ul v-else-if="targets.length" data-slot="impersonation-targets" class="m-0 list-none space-y-2 p-0" aria-label="Users you can act as">
            <li
              v-for="target in targets"
              :key="target.id"
              data-slot="impersonation-target"
              class="flex items-start gap-3 rounded-md border border-border px-3 py-3"
            >
              <UserCheck class="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" :stroke-width="1.8" aria-hidden="true" />
              <span class="min-w-0 flex-1">
                <span class="block truncate text-sm font-medium">{{ target.name }}</span>
                <span v-if="target.username" class="block truncate text-xs text-muted-foreground">{{ target.username }}</span>
                <span v-if="target.detail" class="block truncate text-xs text-muted-foreground">{{ target.detail }}</span>
              </span>
              <!-- "Act as user: <name>" keeps the visible text in the name (WCAG 2.5.3, label in name). -->
              <Button
                size="sm"
                type="button"
                class="shrink-0"
                :aria-label="`Act as user: ${target.name}`"
                :disabled="pending"
                @click="$emit('start', target.id)"
              >
                Act as user
              </Button>
            </li>
          </ul>
        </div>
      </div>

      <SheetFooter class="mt-auto">
        <Button variant="outline" type="button" :disabled="pending" @click="isOpen = false">Cancel</Button>
      </SheetFooter>
    </SheetContent>
  </Sheet>
</template>
