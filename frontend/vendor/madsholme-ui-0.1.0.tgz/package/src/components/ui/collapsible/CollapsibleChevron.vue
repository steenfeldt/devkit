<script setup lang="ts">
import type { HTMLAttributes } from 'vue'
import { ChevronDown } from 'lucide-vue-next'
import { injectCollapsibleRootContext } from 'reka-ui'
import { cn } from '../../../lib/utils'
const props = defineProps<{ class?: HTMLAttributes['class'] }>()
const { open } = injectCollapsibleRootContext()
</script>
<template>
  <ChevronDown data-slot="collapsible-chevron" aria-hidden="true" :class="cn('size-4 shrink-0 transition-transform duration-200 motion-reduce:transition-none', open && 'rotate-180', props.class)" />
</template>
