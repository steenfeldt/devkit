<script setup lang="ts">
import { inject } from "vue"
import { comboboxOptionsKey } from "./context"
import type { ComboboxInputEmits, ComboboxInputProps } from "reka-ui"
import type { HTMLAttributes } from "vue"
import { SearchIcon } from "lucide-vue-next"
import { reactiveOmit } from "@vueuse/core"
import { cn } from "../../../lib/utils"
import { ComboboxInput, useForwardPropsEmits, injectComboboxRootContext, injectListboxRootContext } from "reka-ui"

defineOptions({
  inheritAttrs: false,
})

const props = defineProps<ComboboxInputProps & {
  class?: HTMLAttributes["class"]
}>()

const emits = defineEmits<ComboboxInputEmits>()

const delegatedProps = reactiveOmit(props, "class")

const forwarded = useForwardPropsEmits(delegatedProps, emits)
const options = inject(comboboxOptionsKey, undefined)
const root = injectComboboxRootContext()
const listbox = injectListboxRootContext()
function wrap(event: KeyboardEvent) {
  if (!options?.loop.value || !root.open.value || root.disabled.value || event.defaultPrevented || event.isComposing || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return
  if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return
  const content = document.getElementById(root.contentId)
  const items = Array.from(content?.querySelectorAll<HTMLElement>('[role=option]:not([data-disabled])') ?? [])
    .filter(item => !item.closest('[hidden]'))
  const current = root.highlightedElement.value
  const next = event.key === 'ArrowDown' && current === items.at(-1) ? items[0]
    : event.key === 'ArrowUp' && current === items[0] ? items.at(-1) : undefined
  if (!next) return
  event.preventDefault()
  event.stopPropagation()
  listbox.changeHighlight(next)
}
</script>

<template>
  <div
    data-slot="command-input-wrapper"
    @keydown.capture="wrap"
    class="flex h-9 items-center gap-2 border-b px-3"
  >
    <SearchIcon class="size-4 shrink-0 opacity-50" />
    <ComboboxInput
      data-slot="command-input"
      :class="cn(
        'placeholder:text-muted-foreground flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-hidden disabled:cursor-not-allowed disabled:opacity-50',
        props.class,
      )"

      v-bind="{ ...$attrs, ...forwarded }"
    >
      <slot />
    </ComboboxInput>
  </div>
</template>
