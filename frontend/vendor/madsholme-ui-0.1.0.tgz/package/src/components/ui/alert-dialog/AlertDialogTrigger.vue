<script setup lang="ts">
import type { AlertDialogTriggerProps } from 'reka-ui'
import { AlertDialogTrigger } from 'reka-ui'

const props = defineProps<AlertDialogTriggerProps>()
</script>

<template>
  <!-- With as-child the child keeps its own data-slot (for example "button"). -->
  <AlertDialogTrigger v-bind="props.asChild ? props : { ...props, 'data-slot': 'alert-dialog-trigger' }">
    <slot />
  </AlertDialogTrigger>
</template>
