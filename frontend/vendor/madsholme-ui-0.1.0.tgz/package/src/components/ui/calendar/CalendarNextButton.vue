<script lang="ts" setup>
import type { CalendarNextProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import { ChevronRight } from 'lucide-vue-next'
import { CalendarNext, useForwardProps } from 'reka-ui'
import { cn } from '../../../lib/utils'
import { buttonVariants } from '../button'

const props = withDefaults(defineProps<CalendarNextProps & {
  class?: HTMLAttributes['class']
  /** Accessible name; the button shows only an icon. */
  label?: string
}>(), {
  class: undefined,
  label: 'Next month',
})

const delegatedProps = reactiveOmit(props, 'class', 'label')

const forwardedProps = useForwardProps(delegatedProps)
</script>

<template>
  <CalendarNext
    data-slot="calendar-next-button"
    :aria-label="label"
    :class="cn(
      buttonVariants({ variant: 'outline' }),
      'h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100',
      props.class,
    )"
    v-bind="forwardedProps"
  >
    <slot>
      <ChevronRight
        class="h-4 w-4"
        aria-hidden="true"
      />
    </slot>
  </CalendarNext>
</template>
