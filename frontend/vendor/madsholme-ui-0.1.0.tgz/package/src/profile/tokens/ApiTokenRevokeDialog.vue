<script setup lang="ts">
import { computed, watch } from 'vue'
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../components/ui/alert-dialog'
import { Button } from '../../components/ui/button'

const props = withDefaults(defineProps<{ open: boolean; tokenName: string; pending?: boolean; error?: string }>(), {
  pending: false,
  error: '',
})
const emit = defineEmits<{ 'update:open': [open: boolean]; confirm: [] }>()

// There is no Reka trigger (the revoke button lives in the list), so remember what had focus and return to it.
let returnFocusTo: HTMLElement | null = null
watch(() => props.open, (open) => {
  if (open && typeof document !== 'undefined') returnFocusTo = document.activeElement as HTMLElement | null
}, { immediate: true })

function onCloseAutoFocus(event: Event): void {
  const element = returnFocusTo
  returnFocusTo = null
  if (!element?.isConnected) return
  event.preventDefault()
  // One task later: the shell clears the page's `inert` (useInertWhileHidden) in a mutation callback,
  // and an inert element cannot take focus.
  setTimeout(() => element.focus())
}

// It cannot be closed while the revoke request runs.
const isOpen = computed({
  get: () => props.open,
  set: (open: boolean) => { if (open || !props.pending) emit('update:open', open) },
})
</script>

<template>
  <AlertDialog v-model:open="isOpen">
    <AlertDialogContent data-testid="revoke-token-dialog" @close-auto-focus="onCloseAutoFocus">
      <AlertDialogHeader>
        <AlertDialogTitle>Revoke {{ tokenName }}?</AlertDialogTitle>
        <AlertDialogDescription>API clients using this token will lose access immediately. This cannot be undone.</AlertDialogDescription>
      </AlertDialogHeader>
      <p v-if="error" role="alert" class="m-0 text-sm text-destructive">{{ error }}</p>
      <AlertDialogFooter>
        <AlertDialogCancel :disabled="pending">Keep token</AlertDialogCancel>
        <Button type="button" variant="destructive" :disabled="pending" @click="emit('confirm')">
          {{ pending ? 'Revoking…' : 'Revoke token' }}
        </Button>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
</template>
