# @madsholme/themes

Themes for the Swift product family (SwiftPatch, SwiftConfig, SwiftDeploy and new projects).
The package contains:

- every theme's CSS variables, plus the polish layer, the header themes and the WCAG contrast
  layer;
- the theme registry, with keys, labels, `darkThemeKeys` and surface metadata;
- a Tailwind 4.3 theme (`css/tailwind-theme.css`) and compatibility CSS (`css/tailwind-compat.css`);
- a framework-free controller that applies and persists the theme, including "match system";
- a pre-paint boot script.

It has no Vue dependency and owns no product behavior: products pass in the theme from their
profile and save it through their own API.

The reconciliation of the three products' copies is recorded in
[`docs/theme-reconciliation.md`](../../docs/theme-reconciliation.md).

## Install

GitHub Packages needs a token with `read:packages`, even for reads. Add this to the product's
`.npmrc`, with the token in `NODE_AUTH_TOKEN` (a CI secret in CI):

```ini
@madsholme:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```sh
pnpm add @madsholme/themes
```

Install it in the package that owns the theme store: `packages/shared` in SwiftDeploy and
SwiftConfig, the app in SwiftPatch.

## CSS

Requires Tailwind 4.3 (`tailwindcss ^4.3.0` peer, with `@tailwindcss/vite` or the PostCSS plugin).
Replace `@import 'tailwindcss'` with this sequence:

```css
/* main.css */
@layer theme, base, components, utilities;
@import 'tailwindcss/theme.css' layer(theme);
@import 'tailwindcss/preflight.css' layer(base);
@import '@madsholme/themes/css/tailwind-compat.css' layer(base);
@import '@madsholme/themes/css/tailwind-theme.css';
@import 'tw-animate-css';   /* keyframes and animate-* utilities for the ui components */
@import '@madsholme/themes/css' layer(utilities);               /* tokens, contrast, base, polish */
@import '@madsholme/themes/css/overrides.css' layer(utilities); /* header themes, per-theme effects */
@import 'tailwindcss/utilities.css' layer(utilities);
@source '../node_modules/@madsholme/ui/src';       /* if you use @madsholme/ui */
@source '../node_modules/@madsholme/branding/src'; /* if you use @madsholme/branding */
/* product CSS follows */
```

Products that run without Preflight (SwiftPatch) leave out the two lines that import
`tailwindcss/preflight.css` and `tailwind-compat.css`:

```css
@layer theme, base, components, utilities;
@import 'tailwindcss/theme.css' layer(theme);
@import '@madsholme/themes/css/tailwind-theme.css';
@import 'tw-animate-css';   /* keyframes and animate-* utilities for the ui components */
@import '@madsholme/themes/css' layer(utilities);
@import '@madsholme/themes/css/overrides.css' layer(utilities);
@import 'tailwindcss/utilities.css' layer(utilities);
```

The `tw-animate-css` line is needed by `@madsholme/ui` (a peer dependency of that package): it
supplies the keyframes and `animate-*` utilities the components' open and close animations use.
Products that do not use `@madsholme/ui` can leave the line out.

**Why this order.** In Tailwind 3 the package CSS and the utilities shared one unlayered origin,
so specificity decided between them (polish rules beat plain utilities), and the variant
utilities (`hover:`, `dark:`, `md:`) came last. Putting the package CSS in `utilities`, ahead of
Tailwind's utilities, reproduces both. Every override rule is at least (0,2,0), so it beats plain
utilities and loses ties to variants. The trade-off: a product's own `@layer base` and
`@layer components` CSS sits below the package CSS. Product CSS that must win over the package
CSS goes in `layer(utilities)` after the overrides, as the theme gallery's `gallery.css` does.
The reasoning and the measurements are in
[`docs/theme-reconciliation.md`](../../docs/theme-reconciliation.md) §7.

**Layer consequences for product CSS.**

- Because the package CSS is in `utilities`, its `base.css` rules (`* { border-color }`,
  `body { color; background }`) beat any product CSS in `@layer base` or `@layer components`,
  whatever the specificity. A product `body { background: … }` in `@layer base` has no effect. Put
  such rules in `layer(utilities)` after the overrides, or leave them unlayered.
- Product CSS in `layer(utilities)` placed before `tailwindcss/utilities.css` (as the theme
  gallery's `gallery.css` is) still comes before Tailwind's utilities. It loses specificity ties to
  plain utilities (`.chip` against `border-teal-200`), unlike v3, where CSS after
  `@tailwind utilities` won ties. To win ties, import it after `tailwindcss/utilities.css`, still in
  `layer(utilities)`, or leave it unlayered.
- Unlayered product CSS beats everything.

**Upgrading classes.** If you run `@tailwindcss/upgrade` on product code, do not accept its
`rounded*` renames. Keep `rounded`, `rounded-sm`, `rounded-md`, `rounded-lg` and `rounded-xl`
unchanged: the theme defines those radii, and bare `rounded` is still 0.25rem. Its `shadow`,
`outline`, `ring` and `backdrop-blur` renames are correct (`shadow-sm` to `shadow-xs`, `shadow` to
`shadow-sm`, `outline-none` to `outline-hidden`, `ring` to `ring-3`, and so on).

The sequence uses these two Tailwind-specific files:

- `css/tailwind-theme.css` is generated from `src/tailwind/tokens.ts` and `darkThemeKeys` (run
  `pnpm --filter @madsholme/themes generate`; a test fails on drift). It holds `@theme inline` (every colour token mapped
  onto the theme variables, for example `--color-primary: var(--primary)`, and the radius
  scale), Tailwind 3.4's font stacks and `text-*` line heights, and `@custom-variant dark`, which
  matches `.dark` and every dark `data-theme`.
- `css/tailwind-compat.css` restores Preflight behaviour from Tailwind 3 that v4 dropped: the theme
  border colour as the default, `cursor: pointer` on buttons (`default` when disabled),
  `option { padding: revert }` and `dialog { margin: revert }`. Import it in `layer(base)` right
  after Preflight.

The package CSS has no `@tailwind`, `@apply`, `@layer` or `theme()`, so projects without
Tailwind import the same two files. It works with Tailwind's preflight on or off.

| File | Contents |
| --- | --- |
| `css/tokens.css` | One variable block per theme: `:root` (light), `.dark`, `[data-theme="<key>"]` |
| `css/contrast.css` | Component-pair tokens `--sd-<pair>-background` / `--sd-<pair>-foreground`, adapted per theme to meet WCAG AA |
| `css/base.css` | Page canvas and default border colour |
| `css/polish.css` | Elevation (`--sd-shadow-*`, `--sd-canvas`, `--sd-inset`, …), surface hooks, category tones, status tokens and hooks |
| `css/header-themes.css` | Per-theme `.site-header` treatments, header navigation states, themed menus, High Contrast edges and focus |
| `css/theme-effects.css` | Per-theme restyling of `.bg-card`, `.bg-primary`, `.bg-secondary`, `.text-primary`, selection colours, Matrix extras |

## Colour tokens

Every colour token (`--background`, `--primary`, `--sd-shadow-color`, the `--sd-*` contrast pairs and
so on) is a full `oklch()` colour, for example `--primary: oklch(0.5432 0.1012 233.71)`. Use it as
`var(--primary)`, with no `hsl()` wrapper. Named keywords such as `transparent` and `currentColor`
are unchanged.

**Token roles.** Use the role, not the colour you see in one theme:

| Token | Role | Tailwind |
| --- | --- | --- |
| `--primary` | actions, links, the focus ring, the brand colour | `bg-primary text-primary-foreground` |
| `--highlight` | the theme's second hue: stat tiles, charts, decorative emphasis. Not for text alone unless `text-highlight` contrast is checked on that surface | `bg-highlight text-highlight-foreground` |
| `--accent` | hovered, selected and open surfaces: menu items, navigation links, outline and ghost buttons. A tint, a visible step from `--muted` and `--secondary`, never a saturated fill | `hover:bg-accent hover:text-accent-foreground` |
| `--secondary`, `--muted` | quiet surfaces and secondary text | `bg-secondary text-secondary-foreground`, `bg-muted text-muted-foreground` |
| `--info`, `--success`, `--warning`, `--destructive` | statuses, each with its `--sd-*-foreground` contrast pair for text on a card (`--sd-info-foreground` and so on, see `css/contrast.css`) | `bg-info text-info-foreground`, `text-success`, … |

`--highlight` and `--info` exist in every theme. In the single-hue themes (Ink, Matrix, High
Contrast, Signal) the highlight stays inside that hue. Stat tiles (`.sd-card.sd-stat`) are tinted
with `--highlight` unless they set `--sd-stat-color` inline. The choice of each value is recorded in
[`docs/theme-reconciliation.md`](../../docs/theme-reconciliation.md) §13.

- **Alpha.** Use `color-mix(in srgb, var(--x) 15%, transparent)`, or a Tailwind slash utility
  (`bg-warning/15`, which Tailwind 4 compiles to `color-mix(in oklab, …)`).
- **Gradients.** Pin each gradient to the space it blended in before: `in srgb` when its stops were
  legacy colours (`hsl(var(--x))`, `hsl(var(--x) / a)`, `rgb()`, hex, named), `in oklab` when a stop
  already was a `color-mix()` or another modern colour. A gradient with no `in` and an `oklch()` stop
  blends in OKLab, so a converted legacy gradient without `in srgb` looks different. `in srgb`
  attaches to the direction or position argument when there is one,
  `linear-gradient(90deg in srgb, var(--a), var(--b))`, and is its own first argument otherwise,
  `linear-gradient(in srgb, var(--a), var(--b))`. Every gradient in the package states its space.
- **Shadows.** `--sd-shadow-rgb` (three 0-255 channels) is now `--sd-shadow-color`, a full colour.
  Use `color-mix(in srgb, var(--sd-shadow-color) 10%, transparent)` for its alpha.
- **Tailwind.** `css/tailwind-theme.css` maps each token one to one (`--color-primary: var(--primary)`).

Browser baseline: Chrome and Edge 111+, Safari 16.4+, Firefox 128+. Tailwind 4 itself requires
these, and the package CSS needs `oklch()`, `color-mix()` and gradient colour interpolation
(`in srgb`, Firefox 127+). Tailwind wraps its own `color-mix()` output in an opaque fallback inside
`@supports (color: color-mix(in lab, red, red))`; the package CSS has no fallbacks, and Lightning
CSS adds none.

**Migrating product CSS and classes:**

| Before | After |
| --- | --- |
| `hsl(var(--x))` | `var(--x)` |
| `hsl(var(--x) / a)` | `color-mix(in srgb, var(--x) a%, transparent)`, or a slash utility such as `bg-x/15` |
| `bg-[hsl(var(--x)/0.15)]` | `bg-x/15` |
| `rgb(var(--sd-shadow-rgb) / a)` | `color-mix(in srgb, var(--sd-shadow-color) a%, transparent)` |
| `linear-gradient(90deg, hsl(var(--a)), hsl(var(--b)))` | `linear-gradient(90deg in srgb, var(--a), var(--b))` |
| `linear-gradient(hsl(var(--a)), hsl(var(--b)))` | `linear-gradient(in srgb, var(--a), var(--b))` |
| `linear-gradient(90deg, color-mix(in srgb, hsl(var(--a)) 14%, transparent), transparent)` | `linear-gradient(90deg in oklab, color-mix(in srgb, var(--a) 14%, transparent), transparent)` (it blended in OKLab before) |

**Converter.** `pnpm --filter @madsholme/themes convert:oklch [--check] [files…]` rewrites every
colour in the given CSS files as an exact `oklch()`, applies the rules above, and pins gradients to
the space they blended in before. With no files it converts this package's own CSS. Pass absolute
paths, or paths relative to the directory you run pnpm from. `--check` prints per-file counts and
writes nothing. It refuses, with the file and line, anything it cannot rewrite exactly (for example
`hsl(var(--x) / var(--a))`, bare channels such as `199 70% 36% / .5` or `15, 23, 42`, legacy or
prefixed gradients). It reads plain CSS only, so `.vue` `<style>` blocks and TS are converted by
hand. The converter, `convertCss` in `packages/themes/scripts/lib/oklch.ts`, is not part of the
published package; run it from a SwiftDesign checkout. How the values were chosen is recorded in
[`docs/theme-reconciliation.md`](../../docs/theme-reconciliation.md) §12.

### Product checklist

Every miss fails silently: `hsl(var(--x))` around an `oklch()` value is invalid at computed-value
time, so the property falls back to its inherited or initial value with no error. Check each of these
when a product adopts the package:

1. **Colours built in JS/TS.** Template strings such as `` `hsl(var(--${name}))` `` or
   `` `hsl(var(--x) / ${alpha})` ``, for example SwiftConfig's `environment-domain-colors.ts` and
   the CodeMirror theme in `ReadOnlyCodeViewer.vue`. Write `var(--x)` or
   `color-mix(in srgb, var(--x) N%, transparent)`.
2. **Tokens without a Tailwind mapping.** `css/tailwind-theme.css` does not map `--sidebar-*`,
   `--code-*`, `--status-*` or `--tone-*`. A product that uses them as utilities maps them in its own
   `@theme` as `--color-x: var(--x)`, not `hsl(var(--x))`.
3. **Product CSS that redefines package tokens.** Values written as HSL triplets, for example
   SwiftPatch's `header-themes.css` (`--background: 316 68% 47%`), must become `oklch()`. Run the
   converter on the file.
4. **SwiftPatch's `patch-*` colours.** `hsl(var(--swiftpatch-…) / <alpha-value>)` in
   `tailwind.config.ts` becomes `--color-patch-…: var(--sd-…)` in the product's `@theme`, using the
   `--sd-*` pairs from `css/contrast.css`.
5. **Arbitrary values and scoped styles.** `bg-[hsl(var(--x)/0.15)]` becomes `bg-x/15` (or
   `bg-[color-mix(in_srgb,var(--x)_15%,transparent)]` when there is no utility), and `<style>` blocks
   in `.vue` files follow the table above.
6. **Find the leftovers.** Run this over the product's `src`, and add its Tailwind config and any CSS
   outside `src` to the paths:

   ```sh
   grep -rnE 'hsla?\(var\(--|rgba?\(var\(--|--[a-z0-9-]+:\s*-?[0-9.]+(deg)?\s+[0-9.]+%\s+[0-9.]+%' src
   ```

   It prints token wrappers and HSL-triplet definitions. It must print nothing.

## Tailwind

There is no `tailwind.config` and no JS preset (`@madsholme/themes/tailwind` does not exist).
Utilities such as `bg-primary`, `text-muted-foreground`, `rounded-lg` and `dark:` come from
`css/tailwind-theme.css` in the sequence above. `darkModeSelector` and `tailwindTokens` stay
exported from the package root. Keep product extensions, such as SwiftPatch's `patch-*` colours,
in the product's own CSS with `@theme`.

**Sources:** none are needed for this package, because its source uses no Tailwind classes. The
`ui` and `branding` packages ship classes; their READMEs show the `@source` lines.

## Applying the theme before first paint

```ts
// vite.config.ts
import { themeBoot } from '@madsholme/themes/vite'

export default defineConfig({
  plugins: [themeBoot({ storageKey: 'theme' })], // SwiftPatch: 'swiftpatch.theme'
})
```

The plugin serves the boot script in dev and emits it in the build. It injects
`<script src="…/theme-boot.<hash>.js" data-storage-key="…">` as the first child of `<head>`. The
script reads the cached preference and sets `.dark` or `data-theme` before the stylesheet paints.
It is an external same-origin file, so a `script-src 'self'` CSP needs no change.

Without Vite, copy `@madsholme/themes/boot` into the static root and add the tag by hand:

```html
<script src="/theme-boot.js" data-storage-key="theme"></script>
```

Optional `data-system-light` and `data-system-dark` attributes must match the controller's
`systemThemes`.

## Theme controller

Products whose backend accepts named themes only set `allowSystem: false, fallbackTheme: 'light'`
on both `createThemeController` and `themeBoot`. Missing, invalid and cached `system` values then
resolve to the fallback without following OS changes. Selecting `system` rejects before applying
or saving it. Defaults remain unchanged for other consumers. Pass `theme.allowSystem: false` to
`AppShell` and `:allow-system="false"` to
`ProfileThemeCard` to hide their system controls.

A product may also set `fallbackTheme` while allowing system matching: missing or invalid cached
values use that named default, while an explicit `system` preference follows the OS. Use the same
options for the controller and `themeBoot` to keep the first paint consistent.

```ts
import { createThemeController } from '@madsholme/themes'

const controller = createThemeController({
  storageKey: 'theme',
  profile: { save: (preference) => saveThemeOrThrow(preference) }, // reject on failure
})

controller.init()                              // before the app mounts
controller.applyProfile(user.theme)            // whenever the session reports the profile
controller.clearProfile()                      // on logout
await controller.select('nord')                // a picker choice
await controller.setFollowSystem(true)         // the "match system" toggle
```

- **Preference and theme.** The preference is a theme key or `system`, and `system` follows the
  OS: RN Light for a light setting, RN for a dark one, re-applied live when the setting changes.
  When nothing has been chosen (no cache and an empty profile value), the preference is
  `system`. Products save `system` to the user's profile like any other key, which needs backend
  support for that value.
- **The profile wins.** `applyProfile` applies the profile's preference over the cache and
  enables saving. Before a profile is applied, and after `clearProfile`, selections apply
  locally only.
- **Latest wins.** Every selection applies immediately and pickers never disable. At most one
  save is in flight; a newer selection replaces any queued one and is sent when the in-flight
  save settles. A failure rolls back to the last confirmed preference, sets `saveError` and calls
  `onSaveError`, but only if nothing newer is pending.
- **Identity changes.** `applyProfile` and `clearProfile` invalidate older saves, and so does a
  changed `identityToken()` (SwiftPatch's authorization epoch). A late failure from a previous
  identity never rolls back the current one.
- **Impersonation.** The initiator always keeps their own theme. With
  `impersonation: 'keep-initiator-locally'`, `applyProfile(value, { impersonating: true })`
  ignores the impersonated user's theme, keeps the initiator's cached choice on screen, and
  saves nothing. Use this mode when the backend serves the impersonated user's profile. Use the
  default `'session-is-initiator'` when the session already reports the initiator's theme.

### Keeping a product's Pinia store

```ts
import { createThemeController, themeKeys, type ThemeKey } from '@madsholme/themes'
import { defineStore } from 'pinia'
import { reactive, toRefs } from 'vue'

const controller = createThemeController({
  storageKey: 'theme',
  profile: { save: saveThemeOrThrow },
  impersonation: 'keep-initiator-locally',
  onSaveError: () => toast.error('Could not save theme preference.'),
})

export type Theme = ThemeKey
export const themeValues = themeKeys
export const initTheme = () => controller.init()
export const useThemeStore = defineStore('theme', () => {
  const state = reactive({ ...controller.getState() })
  controller.subscribe((next) => Object.assign(state, next))
  return {
    ...toRefs(state),
    setTheme: controller.select,
    setFollowSystem: controller.setFollowSystem,
    setThemeFromApi: controller.applyProfile,
    clearProfile: controller.clearProfile,
  }
})
```

## Profile animation preference

Animations default to **on**. The independent animation controller does not change theme selection.
Turning it off sets `data-animations="off"` on `<html>` and suppresses decorative CSS animation,
transitions and smooth scrolling across the app, including portals and theme effects. Durations
become 0.01 ms, delays zero and iterations one, so component close events still complete. Continuous
`.animate-spin` and `.animate-pulse` loaders remain active. This controls CSS motion, not product-owned
JavaScript, canvas or video animation. Turning it on removes the override; the existing OS
`prefers-reduced-motion` rules still apply, including live OS changes.

```ts
import { createAnimationController } from '@madsholme/themes'

const animations = createAnimationController({
  storageKey: 'myapp.animations',
  profile: { save: (enabled) => saveAnimationsOrThrow(enabled) },
  impersonation: 'keep-initiator-locally', // when APIs target the impersonated user
  // identityToken: () => session.authorizationEpoch,
})
animations.init()                          // before mounting the app
animations.applyProfile(user.animationsEnabled) // on login/profile/identity changes
await animations.select(false)             // immediate apply, then save
animations.clearProfile()                  // on logout
```

The profile adapter belongs to the product. Add a boolean profile field with default `true` to
its backend when adopting this feature; missing/null/invalid values default to on. Only literal
`false` disables motion. Before a profile is applied, or without an adapter, choices persist only
in the browser. Storage failures do not prevent the preference from applying. The template uses
this local-only mode because it has no backend.

Saves are serialized and the latest queued choice wins. A failed save restores the last confirmed
value in the DOM, state and cache and exposes `saveError`; a newer pending selection takes priority.
`applyProfile` and `clearProfile` invalidate old work, as does a changed `identityToken` when a save
settles. Call `applyProfile(value, { impersonating: true })` when impersonation changes. In
`keep-initiator-locally` mode the initiating user's preference stays on screen and selections are
local only. Use the default `session-is-initiator` when the backend already reads/writes the
initiator's preferences. `subscribe` observes `enabled`, `saving`, `saveError`, `profileActive` and
`impersonating`; its return value unsubscribes. `dispose` drops pending work and subscriptions.

Configure the same cache key in the existing Vite boot plugin to avoid initial motion on reload:

```ts
themeBoot({ storageKey: 'myapp.theme', animationsStorageKey: 'myapp.animations' })
```

Without Vite, add `data-animations-storage-key="myapp.animations"` to the external boot script tag.
Omitting this optional attribute preserves the previous boot behavior. The cache stores literal
`"true"`/`"false"` strings; use separate theme and animation storage keys.

## Hooks the CSS styles

Products, and later `@madsholme/ui`, render these. They are API.

| Hook | Effect |
| --- | --- |
| `.dark`, `[data-theme="<key>"]` on `<html>` | Selects the theme (`light` sets neither) |
| `.site-header`, `[data-site-header-interactive]`, `[data-nav-current="true"]`, `[data-active="true"]`, `[data-state="open"]`, `[data-navigation-menu-*]`, `.lucide` | Header themes and navigation states |
| `.sd-card`, `.sd-lift`, `.sd-stat` (+ `--sd-stat-color`), `.sd-ink` (+ `--sd-ink`) | Raised surfaces, hover lift, stat tiles, accent ink |
| `.sd-page-title`, `.sd-panel-heading`, `.sd-stat-value`, `.sd-table` | Page title, panel heading band, stat value, data table (and the Matrix and Alex treatments) |
| `.sd-tone-badge`, `.sd-tone-text`, `.sd-tone--env-*`, `.sd-tone--zone-*`, `[data-form-section="business\|platform\|network\|misc"]` (alias `data-tone-section`) | Category tones |
| `.status--{pending,queued,scheduled,executing,failed,done,unknown}` with `.status-tone`, `.status-ink`, `.status-panel`, `.status-edge`, `.status-fill` | Status colours in the themes that remap them (High Contrast, Colour-blind Safe) |

**Flat top bars.** In Alex, Solar Bloom, Rosé Pine, Cosmic Light, Nova Drift, Orbital Light, Tron
Light, Cyberpunk and Ember, hovered and open header items (`[data-site-header-interactive]`) paint
no box: `css/header-themes.css` sets their background to transparent, with `!important` where the
shell's `hover:bg-accent` utility would otherwise bring it back. The current item
(`[data-nav-current="true"]`) is marked by the underline only, and keyboard focus shows a 2px
`currentColor` outline (`outline-offset: 2px`) in the item's text colour, which clears the
non-text contrast on every header stop (measured 4.90 to 18.29:1; the test requires 3:1); the page
`--ring` does not. The other themes keep their hover box.

**Motion.** `css/polish.css` eases the shell on one timing token, `--sd-motion: .18s`, with the
existing `--sd-ease`: header items (`[data-site-header-interactive]`) transition background,
colour, border, box-shadow and transform; the admin-mode and global-notification banners
(`[data-slot="admin-mode-banner"]`, `[data-slot="global-notification-banner"]`) play
`@keyframes sd-reveal-down` once on mount; stat tiles (`.sd-card.sd-stat`) and `.sd-lift` cards
use the shared timing. Under `prefers-reduced-motion: reduce` every one of these, the ui
navigation-menu chevron (`[data-slot="navigation-menu-trigger-icon"]`) and every `tw-animate-css`
utility collapses to 0.01 ms; the loaders `animate-spin` and `animate-pulse` keep running. Component
enter and exit animations themselves come from the consumer's `tw-animate-css` import (see "CSS").
Decisions: [`docs/theme-reconciliation.md`](../../docs/theme-reconciliation.md) §14.

The full surface, which includes exports, theme keys, tokens, custom properties and hooks, is
snapshotted in [`test/fixtures/public-surface.json`](test/fixtures/public-surface.json).

## Compatibility

Removing or renaming anything in the public surface is a breaking change: a major version with a
migration note in the changeset. Before 1.0, breaking changes bump the minor version. Every
change needs a changeset (`pnpm changeset`).

## Development

```sh
pnpm --filter @madsholme/themes test        # unit, CSS contract, contrast, lossless, boot, build tests
pnpm --filter @madsholme/themes typecheck
pnpm --filter @madsholme/themes build       # pack smoke test against a Vite 5 / TS 5.4 consumer
pnpm --filter @madsholme/themes generate    # dark selector lists, Tailwind theme file, boot script, node/ bundles
pnpm --filter @madsholme/themes surface     # re-snapshot the public surface after an API change
pnpm test:visual                            # theme gallery screenshots (see apps/theme-gallery)
```

**Adding a theme.**

1. Add an entry to `src/registry.ts`.
2. Add its variable block to `css/tokens.css`.
3. Run `pnpm generate` and `pnpm surface`.
4. Render the gallery baselines.

The dark-selector, contrast and surface tests fail until all of these are done.

The generated files are committed:

- `boot/theme-boot.js`;
- the `node/` bundles, which ship the Vite plugin as JavaScript because
  Node will not load TypeScript from `node_modules`;
- the `@dark-themes` selector lists in `css/`;
- `css/tailwind-theme.css`.

Tests check that each is up to date.


## Reusable motion

See the [complete animation reference](../../docs/animations.md) for every class, default timing,
stagger behavior, composition limits and motion preferences.

The normal CSS import sequence includes 24 opt-in `sd-animate-*` presets. Inspect `/motion` in
the template app or import `motionPresets` from `@madsholme/themes` for names and categories.

- Entrance/exit: `fade-in`, `fade-out`, `slide-up`, `slide-down`, `slide-left`, `slide-right`,
  `exit-up`, `exit-down`, `exit-left`, `exit-right`, `scale-in`, `scale-out`,
  `blur-in`, `blur-out`, `reveal`, `conceal`.
- Attention: `shake`, `nod`, `bounce`, `pop`, `wiggle`, `ping`.
- Continuous loading: `spin`, `pulse`.

```html
<div class="sd-animate-slide-up sd-motion-fast">Saved report</div>
<div class="sd-motion-stagger">
  <div class="sd-animate-fade-in" style="--sd-motion-index: 0">First</div>
  <div class="sd-animate-fade-in" style="--sd-motion-index: 1">Second</div>
</div>
```

Override `--sd-animation-duration`, `--sd-animation-easing`, `--sd-animation-delay` or
`--sd-stagger-step` where needed. Stagger delays cap at 480ms by default; override
`--sd-stagger-max-delay` to adjust the cap. Fast is 120ms; slow is 400ms. Default transitions take 220ms,
attention cues 400ms. Use a wrapper if the element already has a transform. Replay by remounting
or removing/reapplying the class. Exit presets finish hidden; the application owns removal.

Reduced motion and `data-animations="off"` finish nonessential animations immediately, preserving
presence lifecycle events. Spin and pulse remain active as busy indicators; pair them with a
text status. Use motion to explain state changes rather than animate every surface. Tailwind's
standard animation utilities and `tw-animate-css` continue to work with the shared policy.
