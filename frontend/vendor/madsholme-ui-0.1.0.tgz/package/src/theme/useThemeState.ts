import type { ThemeController, ThemeState } from '@madsholme/themes'
import { computed, getCurrentScope, onScopeDispose, readonly, shallowRef, type ComputedRef, type DeepReadonly, type ShallowRef } from 'vue'

export interface ThemeStateRefs {
  readonly state: DeepReadonly<ShallowRef<ThemeState>>
  readonly preference: ComputedRef<ThemeState['preference']>
  readonly theme: ComputedRef<ThemeState['theme']>
  readonly followsSystem: ComputedRef<boolean>
  readonly saving: ComputedRef<boolean>
  readonly saveError: ComputedRef<string>
  readonly select: ThemeController['select']
  readonly setFollowSystem: ThemeController['setFollowSystem']
}

/**
 * Reactive view of a @madsholme/themes controller. Products can keep their Pinia store as a thin wrapper
 * around this, and pass the refs to the shell and the profile theme card.
 */
export function useThemeState(controller: ThemeController): ThemeStateRefs {
  const state = shallowRef(controller.getState())
  const stop = controller.subscribe((next) => { state.value = next })
  if (getCurrentScope()) onScopeDispose(stop)
  return {
    state: readonly(state),
    preference: computed(() => state.value.preference),
    theme: computed(() => state.value.theme),
    followsSystem: computed(() => state.value.followsSystem),
    saving: computed(() => state.value.saving),
    saveError: computed(() => state.value.saveError),
    select: controller.select,
    setFollowSystem: controller.setFollowSystem,
  }
}
