<script setup lang="ts" generic="TData">
import { computed, ref } from 'vue'
import { FlexRender, getCoreRowModel, getPaginationRowModel, getSortedRowModel, useVueTable, type ColumnDef, type SortingState } from '@tanstack/vue-table'
import { ArrowDown, ArrowUp, ArrowUpDown } from 'lucide-vue-next'
import { Button } from '../button'
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '../table'
const props = withDefaults(defineProps<{
  data: TData[]
  columns: ColumnDef<TData>[]
  caption: string
  pageSize?: number
  loading?: boolean
  emptyLabel?: string
  loadingLabel?: string
  previousLabel?: string
  nextLabel?: string
  getRowId?: (row: TData, index: number) => string
}>(), { pageSize: 10, emptyLabel: 'No results.', loadingLabel: 'Loading…', previousLabel: 'Previous', nextLabel: 'Next' })
const sorting = ref<SortingState>([])
const pagination = ref({ pageIndex: 0, pageSize: props.pageSize })
const table = useVueTable({
  get data() { return props.data }, get columns() { return props.columns },
  getRowId: props.getRowId,
  state: { get sorting() { return sorting.value }, get pagination() { return { ...pagination.value, pageSize: Math.max(1, props.pageSize) } } },
  onSortingChange: updater => { sorting.value = typeof updater === 'function' ? updater(sorting.value) : updater },
  onPaginationChange: updater => { pagination.value = typeof updater === 'function' ? updater(pagination.value) : updater },
  getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel(),
})
const rows = computed(() => table.getRowModel().rows)
</script>
<template>
  <div data-slot="data-table" class="grid min-w-0 gap-3" :aria-busy="loading">
    <div class="overflow-hidden rounded-lg border">
      <Table>
        <TableCaption>{{ caption }}</TableCaption>
        <TableHeader><TableRow v-for="group in table.getHeaderGroups()" :key="group.id">
          <TableHead v-for="header in group.headers" :key="header.id" :aria-sort="header.column.getCanSort() ? (header.column.getIsSorted() === 'asc' ? 'ascending' : header.column.getIsSorted() === 'desc' ? 'descending' : 'none') : undefined">
            <template v-if="!header.isPlaceholder">
              <Button v-if="header.column.getCanSort()" type="button" variant="ghost" size="sm" @click="header.column.toggleSorting()">
                <FlexRender :render="header.column.columnDef.header" :props="header.getContext()" />
                <component :is="header.column.getIsSorted() === 'asc' ? ArrowUp : header.column.getIsSorted() === 'desc' ? ArrowDown : ArrowUpDown" class="size-4" aria-hidden="true" />
              </Button>
              <FlexRender v-else :render="header.column.columnDef.header" :props="header.getContext()" />
            </template>
          </TableHead>
        </TableRow></TableHeader>
        <TableBody>
          <TableRow v-if="loading || !rows.length"><TableCell :colspan="columns.length" class="h-24 text-center"><span role="status">{{ loading ? loadingLabel : emptyLabel }}</span></TableCell></TableRow>
          <TableRow v-for="row in loading ? [] : rows" :key="row.id"><TableCell v-for="cell in row.getVisibleCells()" :key="cell.id"><FlexRender :render="cell.column.columnDef.cell" :props="cell.getContext()" /></TableCell></TableRow>
        </TableBody>
      </Table>
    </div>
    <div class="flex flex-wrap items-center justify-end gap-2">
      <span class="text-sm text-muted-foreground" aria-live="polite">{{ table.getState().pagination.pageIndex + 1 }} / {{ Math.max(1, table.getPageCount()) }}</span>
      <Button type="button" variant="outline" size="sm" :disabled="loading || !table.getCanPreviousPage()" @click="table.previousPage()">{{ previousLabel }}</Button>
      <Button type="button" variant="outline" size="sm" :disabled="loading || !table.getCanNextPage()" @click="table.nextPage()">{{ nextLabel }}</Button>
    </div>
  </div>
</template>
