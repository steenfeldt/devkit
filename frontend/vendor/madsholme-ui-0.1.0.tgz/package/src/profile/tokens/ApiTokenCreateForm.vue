<script setup lang="ts">
import { KeyRound, Loader2 } from 'lucide-vue-next'
import { computed, ref, useId } from 'vue'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Input } from '../../components/ui/input'
import { NativeSelect } from '../../components/ui/native-select'
import { formatTokenLifetime } from '../format'
import type { ApiTokenAccessOption } from '../types'

const props = withDefaults(defineProps<{
  lifetimeSeconds: number
  pending?: boolean
  error?: string
  /** Offer an access level (SwiftConfig, SwiftPatch). Null hides the field (SwiftDeploy). */
  accessOptions?: readonly ApiTokenAccessOption[] | null
  title?: string
  namePlaceholder?: string
  locale?: string
}>(), {
  pending: false,
  error: '',
  accessOptions: null,
  title: 'Generate a token',
  namePlaceholder: 'e.g. My Ansible run',
  locale: 'en-GB',
})

const emit = defineEmits<{ submit: [value: { name: string; access?: 'read' | 'write' }] }>()
const id = useId()
const name = ref('')
const access = ref<'read' | 'write'>(props.accessOptions?.[0]?.value ?? 'read')
const lifetime = computed(() => formatTokenLifetime(props.lifetimeSeconds, props.locale))
const accessHelp = computed(() => props.accessOptions?.find((option) => option.value === access.value)?.description)

function submit(): void {
  const trimmed = name.value.trim()
  if (!trimmed || props.pending) return
  emit('submit', props.accessOptions ? { name: trimmed, access: access.value } : { name: trimmed })
}

defineExpose({ reset: () => { name.value = '' } })
</script>

<template>
  <Card data-slot="api-token-create-form">
    <CardHeader>
      <CardTitle as="h2" class="flex items-center gap-2"><KeyRound class="h-5 w-5" aria-hidden="true" /> {{ title }}</CardTitle>
      <CardDescription>
        <slot name="description">Tokens expire {{ lifetime }} after creation. They use your current permissions without administrator mode.</slot>
      </CardDescription>
    </CardHeader>
    <CardContent>
      <form class="flex flex-col gap-4" @submit.prevent.stop="submit">
        <div class="flex flex-col gap-2">
          <label :for="`api-token-name-${id}`" class="text-sm font-medium">Token name</label>
          <Input
            :id="`api-token-name-${id}`"
            v-model="name"
            maxlength="100"
            required
            autocomplete="off"
            :placeholder="namePlaceholder"
            :disabled="pending"
            :aria-invalid="Boolean(error)"
            :aria-describedby="`api-token-name-help-${id}`"
          />
          <p :id="`api-token-name-help-${id}`" class="m-0 text-xs text-muted-foreground">Choose a name you will recognize later. The token itself is shown only once.</p>
        </div>
        <div v-if="accessOptions" class="flex flex-col gap-2">
          <label :for="`api-token-access-${id}`" class="text-sm font-medium">Access</label>
          <NativeSelect :id="`api-token-access-${id}`" v-model="access" :disabled="pending" :aria-describedby="accessHelp ? `api-token-access-help-${id}` : undefined">
            <option v-for="option in accessOptions" :key="option.value" :value="option.value">{{ option.label }}</option>
          </NativeSelect>
          <p v-if="accessHelp" :id="`api-token-access-help-${id}`" class="m-0 text-xs text-muted-foreground">{{ accessHelp }}</p>
        </div>
        <p v-if="error" role="alert" class="m-0 text-sm text-destructive">{{ error }}</p>
        <Button type="submit" class="self-start" :disabled="pending">
          <Loader2 v-if="pending" class="mr-2 h-4 w-4 animate-spin" aria-hidden="true" />
          {{ pending ? 'Generating…' : 'Generate token' }}
        </Button>
      </form>
    </CardContent>
  </Card>
</template>
