/** Minimal DOM test substitutes, never imported by the production barrel.
 * Call in a jsdom setup file before importing Unovis. No layout or drawing is simulated. */
const installed = Symbol.for('@madsholme/ui/testing/canvas')

export function installJsdomShims(): void {
  if (typeof window === 'undefined' || typeof navigator === 'undefined' || !/jsdom/i.test(navigator.userAgent)) return

  if (typeof globalThis.ResizeObserver === 'undefined') {
    globalThis.ResizeObserver = class implements ResizeObserver {
      observe() {}
      unobserve() {}
      disconnect() {}
    }
  }
  window.ResizeObserver ??= globalThis.ResizeObserver
  if (typeof window.matchMedia !== 'function') {
    window.matchMedia = (query: string): MediaQueryList => {
      const events = new EventTarget()
      return {
        matches: false, media: query, onchange: null,
        addListener(listener) { if (listener) events.addEventListener('change', listener as EventListener) },
        removeListener(listener) { if (listener) events.removeEventListener('change', listener as EventListener) },
        addEventListener: events.addEventListener.bind(events),
        removeEventListener: events.removeEventListener.bind(events),
        dispatchEvent: events.dispatchEvent.bind(events),
      }
    }
  }
  // jsdom has no SVG layout engine. Axes need the method to exist, but its
  // zero box deliberately makes no claim about rendered text dimensions.
  if (!('getBBox' in window.SVGElement.prototype)) {
    Object.defineProperty(window.SVGElement.prototype, 'getBBox', {
      configurable: true,
      writable: true,
      value: () => ({ x: 0, y: 0, width: 0, height: 0 }),
    })
  }
  const prototype = window.HTMLCanvasElement.prototype
  if ((prototype.getContext as unknown as Record<symbol, boolean>)[installed]) return
  const contexts = new WeakMap<HTMLCanvasElement, CanvasRenderingContext2D>()
  const getContext = function (this: HTMLCanvasElement, kind: string) {
    if (kind !== '2d') return null
    let context = contexts.get(this)
    if (!context) {
      const noop = () => {}
      context = {
        canvas: this, font: '10px sans-serif',
        measureText: (text: string) => ({ width: String(text).length * 6 } as TextMetrics),
        clearRect: noop, fillRect: noop, strokeRect: noop, beginPath: noop, closePath: noop,
        moveTo: noop, lineTo: noop, arc: noop, fill: noop, stroke: noop,
        save: noop, restore: noop, translate: noop, rotate: noop, scale: noop,
        setTransform: noop, resetTransform: noop, drawImage: noop, fillText: noop, strokeText: noop,
        setLineDash: noop, getLineDash: () => [],
      } as unknown as CanvasRenderingContext2D
      contexts.set(this, context)
    }
    return context
  }
  Object.defineProperty(getContext, installed, { value: true })
  prototype.getContext = getContext as typeof prototype.getContext
}
