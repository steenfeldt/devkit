<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { cn } from "../../../lib/utils"
import { Separator } from "../separator"

const props = defineProps<{
  class?: HTMLAttributes["class"]
}>()
</script>

<template>
  <div
    data-slot="field-separator"
    :data-content="!!$slots.default"
    :class="cn(
      'flex items-center gap-2 -my-2 min-h-5 text-sm group-data-[variant=outline]/field-group:-mb-2',
      props.class,
    )"
  >
    <Separator class="w-auto flex-1" />
    <span
      v-if="$slots.default"
      class="shrink-0"
      data-slot="field-separator-content"
    >
      <slot />
    </span>
    <Separator v-if="$slots.default" class="w-auto flex-1" />
  </div>
</template>
