<script setup lang="ts">
import type { AlertDialogActionProps } from 'reka-ui'
import type { HTMLAttributes } from 'vue'
import { reactiveOmit } from '@vueuse/core'
import { AlertDialogAction } from 'reka-ui'
import { cn } from '../../../lib/utils'
import { buttonVariants, type ButtonVariants } from '../button'

const props = withDefaults(defineProps<AlertDialogActionProps & { class?: HTMLAttributes['class']; variant?: ButtonVariants['variant'] }>(), { variant: 'default' })

const delegatedProps = reactiveOmit(props, 'class', 'variant')
</script>

<template>
  <AlertDialogAction
    v-bind="delegatedProps"
    data-slot="alert-dialog-action"
    :class="cn('ui-button', `ui-button--${variant}`, buttonVariants({ variant }), props.class)"
  >
    <slot />
  </AlertDialogAction>
</template>
