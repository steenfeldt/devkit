import type { TokenDateOptions } from './types'

/** SwiftDeploy's token dates: en-GB, Copenhagen time, medium date and short time. */
export function formatTokenDate(value: string, { locale = 'en-GB', timeZone = 'Europe/Copenhagen' }: TokenDateOptions = {}): string {
  return new Intl.DateTimeFormat(locale, { timeZone, dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value))
}

/** "8 hours", "30 minutes", "45 seconds". */
export function formatTokenLifetime(seconds: number, locale = 'en-GB'): string {
  const [value, unit] = seconds >= 3600
    ? [seconds / 3600, 'hour'] as const
    : seconds >= 60 ? [seconds / 60, 'minute'] as const : [seconds, 'second'] as const
  return new Intl.NumberFormat(locale, { style: 'unit', unit, unitDisplay: 'long', maximumFractionDigits: 2 }).format(value)
}

/** Up to two initials, or "?". */
export function getInitials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join('') || '?'
}
