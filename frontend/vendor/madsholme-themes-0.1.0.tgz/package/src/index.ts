export {
  darkThemeKeys,
  defaultPreference,
  defaultSystemThemes,
  getTheme,
  isDarkTheme,
  systemPreference,
  themeKeys,
  themeSurfaces,
  themes,
  type HeaderTone,
  type SystemPreference,
  type SystemThemes,
  type ThemeDefinition,
  type ThemeKey,
  type ThemePreference,
  type ThemeScheme,
  type ThemeSurface,
} from './registry'
export {
  appShellThemeOptions,
  compactThemeOptions,
  persistedThemeOptions,
  profileThemeOptions,
  systemThemeToggle,
  themeOptions,
  type ThemeOption,
} from './options'
export {
  isThemeKey,
  isThemePreference,
  legacyThemeAliases,
  resolvePreference,
  resolveSystemTheme,
  resolveTheme,
  toApiTheme,
} from './resolve'
export {
  applyThemeToDocument,
  prefersDarkQuery,
  prefersDarkScheme,
  themeAttributes,
  type MatchMedia,
  type ThemeAttributes,
} from './dom'
export {
  createThemeController,
  defaultSaveErrorMessage,
  type ImpersonationThemeSource,
  type SelectResult,
  type ThemeController,
  type ThemeControllerOptions,
  type ThemeProfileAdapter,
  type ThemeSaveErrorEvent,
  type ThemeState,
  type ThemeStorage,
} from './controller'
export { darkModeSelector, darkRoots, tailwindTokens } from './tailwind/tokens'
export { createAnimationController, type AnimationController, type AnimationControllerOptions, type AnimationState } from './animations'
export { motionPresets, type MotionPreset, type MotionPresetName } from './motion'
