import { cva, type VariantProps } from 'class-variance-authority'
export { default as Typography } from './Typography.vue'
export const typographyVariants = cva('text-foreground', { variants: { variant: {
  h1: 'text-3xl font-semibold tracking-tight text-balance', h2: 'text-2xl font-semibold tracking-tight text-balance',
  h3: 'text-xl font-semibold', h4: 'text-lg font-semibold', body: 'text-base leading-7',
  lead: 'text-xl leading-8 text-muted-foreground', small: 'text-sm leading-5', muted: 'text-sm text-muted-foreground',
  code: 'rounded bg-muted px-1.5 py-0.5 font-mono text-sm', quote: 'border-l-2 border-border pl-4 italic',
} }, defaultVariants: { variant: 'body' } })
export type TypographyVariants = VariantProps<typeof typographyVariants>
