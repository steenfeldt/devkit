// shadcn-vue components
export * from './components/ui'
export { cn } from './lib/utils'

// Application shell
export { default as AppShell } from './shell/AppShell.vue'
export { default as AdminModeBanner } from './shell/AdminModeBanner.vue'
export { default as GlobalNotificationBanner } from './shell/GlobalNotificationBanner.vue'
export { default as MobileNavigation } from './shell/MobileNavigation.vue'
export { default as ProfileMenu } from './shell/ProfileMenu.vue'
export { default as SkipLink } from './shell/SkipLink.vue'
export { default as ThemeQuickPicker } from './shell/ThemeQuickPicker.vue'
export { default as TopNavigation } from './shell/TopNavigation.vue'
export { collapseClasses, shellContainerClass, type CollapseBreakpoint } from './shell/classes'
export { currentNavGroupId, groupPrefixes } from './shell/navigation'
export { noticeIcons, sortGlobalNotices } from './shell/notifications'

// Impersonation
export { default as ImpersonationBanner } from './impersonation/ImpersonationBanner.vue'
export { default as ImpersonationDialog } from './impersonation/ImpersonationDialog.vue'

// Theme helpers
export { themeIcons, withThemeIcons, type ThemeChoice } from './theme/icons'
export { useThemeState, type ThemeStateRefs } from './theme/useThemeState'

// Profile page building blocks
export { default as ProfilePageLayout } from './profile/ProfilePageLayout.vue'
export { default as ProfileIdentityHeader } from './profile/ProfileIdentityHeader.vue'
export { default as ProfileDetailsCard } from './profile/ProfileDetailsCard.vue'
export { default as ProfileAuthorizationIdentityCard } from './profile/ProfileAuthorizationIdentityCard.vue'
export { default as ProfileBadgeCard } from './profile/ProfileBadgeCard.vue'
export { default as ProfileApiAccessCard } from './profile/ProfileApiAccessCard.vue'
export { default as ProfileThemeCard } from './profile/ProfileThemeCard.vue'
export { default as ProfileWorkDefaultCard } from './profile/ProfileWorkDefaultCard.vue'
export { default as ApiTokenList } from './profile/tokens/ApiTokenList.vue'
export { default as ApiTokenCreateForm } from './profile/tokens/ApiTokenCreateForm.vue'
export { default as GeneratedTokenDisplay } from './profile/tokens/GeneratedTokenDisplay.vue'
export { default as ApiTokenRevokeDialog } from './profile/tokens/ApiTokenRevokeDialog.vue'
export { default as ApiTokenUsageNote } from './profile/tokens/ApiTokenUsageNote.vue'
export { default as McpTokenCreateForm } from './profile/tokens/McpTokenCreateForm.vue'
export { default as McpTokenList } from './profile/tokens/McpTokenList.vue'
export { default as McpClientSetup } from './profile/tokens/McpClientSetup.vue'
export { buildMcpClientExamples, mcpGrantBadges, mcpGrantLevelLabels } from './profile/mcp'
export type { McpClientExampleOptions, McpGrantBadge } from './profile/mcp'
export { formatTokenDate, formatTokenLifetime, getInitials } from './profile/format'
export type {
  ApiTokenAccessOption,
  ApiTokenSummary,
  AuthorizationIdentity,
  GeneratedApiToken,
  McpBrowserOAuth,
  McpClientGuidance,
  McpClientExample,
  McpClientSnippet,
  McpGrantArea,
  McpGrantLevel,
  McpGrants,
  McpTokenLifetimes,
  McpTokenSummary,
  ProfileBadge,
  ProfileDetailRow,
  ProfileGroup,
  TokenDateOptions,
} from './profile/types'

// Types
export type {
  GlobalNotice,
  ImpersonationParty,
  ImpersonationTarget,
  NavGroup,
  NavLink,
  ShellAdminMode,
  ShellImpersonation,
  ShellThemeState,
  ShellUser,
} from './types'
export { default as ProfileAnimationCard } from './profile/ProfileAnimationCard.vue'
export { useAnimationState } from './theme/useAnimationState'
