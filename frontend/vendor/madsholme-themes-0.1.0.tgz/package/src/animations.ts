import type { SelectResult, ThemeStorage } from './controller'

export interface AnimationState {
  readonly enabled: boolean
  readonly saving: boolean
  readonly saveError: string
  readonly profileActive: boolean
  readonly impersonating: boolean
}

export interface AnimationControllerOptions {
  storageKey: string
  /** Defaults to localStorage. Null disables caching. */
  storage?: ThemeStorage | null
  /** Defaults to document.documentElement. */
  root?: () => HTMLElement | null
  /** Product-owned persistence; reject on failure. */
  profile?: { save(enabled: boolean): Promise<void> }
  /** Defaults to session-is-initiator, like the theme controller. */
  impersonation?: 'session-is-initiator' | 'keep-initiator-locally'
  identityToken?: () => unknown
  saveErrorMessage?: string
  onSaveError?: (event: { error: unknown; attempted: boolean; restored: boolean }) => void
}

export interface AnimationController {
  getState(): AnimationState
  subscribe(listener: (state: AnimationState) => void): () => void
  init(): boolean
  select(enabled: boolean): Promise<SelectResult>
  /** Only literal false disables animations; missing/invalid profile values default to on. */
  applyProfile(value: unknown, context?: { impersonating?: boolean }): boolean
  /** Invalidate pending saves; keep the current preference locally. */
  clearProfile(): void
  dispose(): void
}

/** Independent of theme selection. OS reduced motion remains enforced by CSS. */
export function createAnimationController(options: AnimationControllerOptions): AnimationController {
  let storage: ThemeStorage | null = options.storage ?? null
  if (options.storage === undefined) {
    try { storage = typeof localStorage === 'undefined' ? null : localStorage } catch { /* Storage may be blocked. */ }
  }
  const root = options.root ?? (() => typeof document === 'undefined' ? null : document.documentElement)
  const listeners = new Set<(state: AnimationState) => void>()
  const read = () => {
    try { return storage?.getItem(options.storageKey) !== 'false' } catch { return true }
  }
  let state: AnimationState = { enabled: read(), saving: false, saveError: '', profileActive: false, impersonating: false }
  let confirmed = state.enabled
  let revision = 0
  let inFlight = false
  let queued: { enabled: boolean; settle: (result: SelectResult) => void } | null = null

  function update(patch: Partial<AnimationState>): void {
    state = { ...state, ...patch }
    for (const listener of [...listeners]) listener(state)
  }

  function show(enabled: boolean, patch: Partial<AnimationState> = {}): void {
    const element = root()
    if (enabled) element?.removeAttribute('data-animations')
    else element?.setAttribute('data-animations', 'off')
    try { storage?.setItem(options.storageKey, String(enabled)) } catch { /* Apply even without storage. */ }
    update({ ...patch, enabled })
  }

  function dropQueued(): void {
    const previous = queued
    queued = null
    previous?.settle('superseded')
  }

  function invalidate(): void {
    revision += 1
    inFlight = false
    dropQueued()
  }

  async function send(enabled: boolean): Promise<SelectResult> {
    const requestRevision = revision
    const identity = options.identityToken?.()
    inFlight = true
    update({ saving: true })
    let failed = false
    let failure: unknown
    try { await options.profile!.save(enabled) } catch (error) { failed = true; failure = error }
    if (requestRevision !== revision) return 'superseded'
    inFlight = false
    // Ignore successes as well as failures from an old identity; never send its queued choice.
    if (options.identityToken && identity !== options.identityToken()) {
      invalidate()
      update({ saving: false })
      return 'superseded'
    }
    if (!failed) confirmed = enabled
    const next = queued
    queued = null
    if (next) {
      if (next.enabled === confirmed) {
        update({ saving: false })
        next.settle('saved')
      } else {
        void send(next.enabled).then(next.settle)
      }
      return 'superseded'
    }
    if (failed) {
      show(confirmed, { saving: false, saveError: options.saveErrorMessage ?? 'Unable to save animations. Please try again.' })
      options.onSaveError?.({ error: failure, attempted: enabled, restored: confirmed })
      return 'rolled-back'
    }
    update({ saving: false })
    return 'saved'
  }

  return {
    getState: () => state,
    subscribe(listener) {
      listeners.add(listener)
      return () => { listeners.delete(listener) }
    },
    init() {
      const enabled = read()
      if (!state.profileActive) confirmed = enabled
      show(enabled)
      return enabled
    },
    async select(enabled) {
      if (typeof enabled !== 'boolean') throw new TypeError('Animations must be a boolean')
      show(enabled, { saveError: '' })
      if (!options.profile || !state.profileActive || (state.impersonating && options.impersonation === 'keep-initiator-locally')) return 'applied-locally'
      if (inFlight) {
        dropQueued()
        return new Promise<SelectResult>((settle) => { queued = { enabled, settle } })
      }
      return send(enabled)
    },
    applyProfile(value, context = {}) {
      invalidate()
      const impersonating = context.impersonating === true
      const patch = { profileActive: true, impersonating, saving: false, saveError: '' }
      if (impersonating && options.impersonation === 'keep-initiator-locally') update(patch)
      else {
        confirmed = value !== false
        show(confirmed, patch)
      }
      return state.enabled
    },
    clearProfile() {
      invalidate()
      update({ profileActive: false, impersonating: false, saving: false, saveError: '' })
    },
    dispose() {
      invalidate()
      listeners.clear()
    },
  }
}
