import { createHash } from 'node:crypto'
import { readFileSync } from 'node:fs'
import type { Plugin } from 'vite'
import type { SystemThemes, ThemeKey } from './registry'
import { isThemeKey } from './resolve'

export interface ThemeBootOptions {
  /** The storage key the app's theme controller uses, e.g. `theme` or `swiftpatch.theme`. */
  storageKey: string
  /** Optional animation controller cache key; applies a saved off preference before paint. */
  animationsStorageKey?: string
  /** Defaults to RN Light and RN. Must match the controller's `systemThemes`. */
  systemThemes?: SystemThemes
  /** Must match the controller. */
  allowSystem?: boolean
  fallbackTheme?: ThemeKey
}

/**
 * Serves the pre-paint boot script in dev, emits it in the build, and injects
 * `<script src="…/theme-boot.<hash>.js" data-storage-key="…">` as the first child of `<head>`.
 * The script is an external same-origin file, so a `script-src 'self'` CSP needs no change.
 */
export function themeBoot(options: ThemeBootOptions): Plugin {
  if (!options.storageKey) throw new TypeError('themeBoot: storageKey is required')
  const { systemThemes } = options
  if (systemThemes && !(isThemeKey(systemThemes.light) && isThemeKey(systemThemes.dark))) {
    throw new TypeError('themeBoot: systemThemes must name two theme keys')
  }
  const code = readFileSync(new URL('../boot/theme-boot.js', import.meta.url), 'utf8')
  const fileName = `theme-boot.${createHash('sha256').update(code).digest('hex').slice(0, 8)}.js`
  let base = '/'
  const url = () => `${base.endsWith('/') ? base : `${base}/`}${fileName}`

  return {
    name: '@madsholme/themes:boot',
    configResolved(config) {
      base = config.base
    },
    configureServer(server) {
      server.middlewares.use((request, response, next) => {
        if (request.url?.split('?')[0] !== url()) return next()
        response.setHeader('Content-Type', 'text/javascript; charset=utf-8')
        response.end(code)
      })
    },
    generateBundle() {
      this.emitFile({ type: 'asset', fileName, source: code })
    },
    transformIndexHtml: {
      order: 'post',
      handler() {
        const attrs: Record<string, string> = { src: url(), 'data-storage-key': options.storageKey }
        if (options.allowSystem === false) attrs['data-allow-system'] = 'false'
        if (options.fallbackTheme) attrs['data-fallback-theme'] = options.fallbackTheme
        if (options.animationsStorageKey) attrs['data-animations-storage-key'] = options.animationsStorageKey
        if (systemThemes) {
          attrs['data-system-light'] = systemThemes.light
          attrs['data-system-dark'] = systemThemes.dark
        }
        return [{ tag: 'script', attrs, injectTo: 'head-prepend' }]
      },
    },
  }
}
