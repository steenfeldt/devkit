<script setup lang="ts">
import { Badge } from '../../components/ui/badge'
import { Button } from '../../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Skeleton } from '../../components/ui/skeleton'
import { formatTokenDate } from '../format'
import { mcpGrantBadges } from '../mcp'
import type { McpGrantArea, McpTokenSummary } from '../types'

withDefaults(defineProps<{
  tokens: readonly McpTokenSummary[]
  /** Every area the product knows, in badge order (not only the ones this account may grant). */
  areas: readonly McpGrantArea[]
  loading?: boolean
  /** A revoke request is running. */
  revoking?: boolean
  locale?: string
  timeZone?: string
  title?: string
  description?: string
  emptyText?: string
}>(), {
  loading: false,
  revoking: false,
  locale: 'en-GB',
  timeZone: 'Europe/Copenhagen',
  title: 'Your active MCP tokens',
  description: 'Expired and revoked tokens are removed from this list. Dates are in Copenhagen time.',
  emptyText: 'No active MCP tokens.',
})

defineEmits<{ revoke: [token: McpTokenSummary] }>()
</script>

<template>
  <Card class="[--muted-foreground:var(--sd-muted-card-foreground)]" data-slot="mcp-token-list">
    <CardHeader class="flex flex-row flex-wrap items-start justify-between gap-3">
      <div class="flex min-w-0 flex-col gap-1.5">
        <CardTitle as="h2">{{ title }}</CardTitle>
        <CardDescription>{{ description }}</CardDescription>
      </div>
      <slot name="actions" />
    </CardHeader>
    <CardContent>
      <div v-if="loading" class="flex flex-col gap-3" aria-label="Loading MCP tokens" aria-busy="true">
        <Skeleton v-for="row in 2" :key="row" class="h-20 w-full" />
      </div>
      <p v-else-if="!tokens.length" class="m-0 py-6 text-center text-sm text-muted-foreground">{{ emptyText }}</p>
      <ul v-else class="m-0 list-none divide-y divide-border p-0">
        <li
          v-for="token in tokens"
          :key="token.id"
          data-slot="mcp-token"
          class="flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
        >
          <div class="min-w-0 flex-1">
            <p class="m-0 break-words font-medium">{{ token.name }}</p>
            <code class="text-xs text-muted-foreground">{{ token.prefix }}…</code>
            <div class="mt-2 flex flex-wrap gap-1.5">
              <Badge v-for="grant in mcpGrantBadges(areas, token.grants)" :key="grant.key" :variant="grant.write ? 'default' : 'outline'">{{ grant.label }}</Badge>
            </div>
            <dl class="m-0 mt-2 grid gap-x-5 gap-y-1 text-xs text-muted-foreground sm:grid-cols-2">
              <div><dt class="inline">Expires: </dt><dd class="m-0 inline">{{ formatTokenDate(token.expiresAt, { locale, timeZone }) }}</dd></div>
              <div><dt class="inline">Last used: </dt><dd class="m-0 inline">{{ token.lastUsedAt ? formatTokenDate(token.lastUsedAt, { locale, timeZone }) : 'Not used yet' }}</dd></div>
              <div><dt class="inline">Created: </dt><dd class="m-0 inline">{{ formatTokenDate(token.createdAt, { locale, timeZone }) }}</dd></div>
            </dl>
          </div>
          <Button
            type="button"
            variant="outline"
            class="self-start sm:self-center"
            :disabled="revoking"
            :aria-label="`Revoke ${token.name}`"
            @click="$emit('revoke', token)"
          >Revoke</Button>
        </li>
      </ul>
    </CardContent>
  </Card>
</template>
