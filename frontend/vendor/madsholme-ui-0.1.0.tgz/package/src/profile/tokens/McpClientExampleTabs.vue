<script setup lang="ts">
import { Check, Copy } from 'lucide-vue-next'
import { ref, watch } from 'vue'
import { Button } from '../../components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs'
import type { McpClientExample } from '../types'

const props = defineProps<{
  examples: readonly McpClientExample[]
  copied: string
  label: string
}>()
const emit = defineEmits<{ copy: [code: string] }>()
const client = ref(props.examples[0]?.id ?? '')
watch(() => props.examples, (examples) => {
  if (!examples.some(example => example.id === client.value)) client.value = examples[0]?.id ?? ''
})
const paragraphs = (description?: string | readonly string[]) => description === undefined ? [] : typeof description === 'string' ? [description] : description
</script>

<template>
  <Tabs v-if="examples.length" v-model="client" class="gap-4">
    <TabsList :aria-label="label">
      <TabsTrigger v-for="example in examples" :key="example.id" :value="example.id">{{ example.label }}</TabsTrigger>
    </TabsList>
    <TabsContent v-for="example in examples" :key="example.id" :value="example.id" class="flex min-w-0 flex-col gap-4">
      <div v-for="snippet in example.snippets" :key="snippet.title" class="flex min-w-0 flex-col gap-1.5">
        <h4 class="m-0 text-sm font-medium">{{ snippet.title }}</h4>
        <p v-for="paragraph in paragraphs(snippet.description)" :key="paragraph" class="m-0 text-xs text-muted-foreground">{{ paragraph }}</p>
        <div class="relative min-w-0 rounded-lg border border-input dark:bg-input/30">
          <pre tabindex="0" role="region" :aria-label="snippet.title" class="m-0 overflow-x-auto rounded-lg p-3 pr-12 font-mono text-xs leading-relaxed focus-visible:outline-2 focus-visible:outline-ring"><code>{{ snippet.code }}</code></pre>
          <Button
            type="button"
            size="icon-xs"
            variant="ghost"
            class="absolute end-2 top-2"
            :aria-label="copied === snippet.code ? 'Copied' : `Copy ${snippet.title}`"
            @click="emit('copy', snippet.code)"
          >
            <component :is="copied === snippet.code ? Check : Copy" aria-hidden="true" />
          </Button>
        </div>
      </div>
    </TabsContent>
  </Tabs>
</template>
