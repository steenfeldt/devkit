<script setup lang="ts">
import { computed } from 'vue'
import { Avatar, AvatarFallback } from '../components/ui/avatar'
import { Badge } from '../components/ui/badge'
import { getInitials } from './format'
import type { ProfileBadge } from './types'

const props = withDefaults(defineProps<{
  displayName: string
  email?: string | null
  emailFallback?: string
  /** Usually the primary group. */
  subtitle?: string | null
  badges?: readonly ProfileBadge[]
}>(), { email: null, emailFallback: 'No email configured', subtitle: null, badges: () => [] })

const initials = computed(() => getInitials(props.displayName))
</script>

<template>
  <section data-slot="profile-identity-header" class="sd-card flex items-center gap-5 rounded-xl border bg-card p-6" aria-label="Account">
    <Avatar class="h-16 w-16 shrink-0" aria-hidden="true">
      <AvatarFallback class="bg-primary/10 text-xl font-bold text-primary">{{ initials }}</AvatarFallback>
    </Avatar>
    <div class="min-w-0">
      <div class="mb-0.5 flex flex-wrap items-center gap-2">
        <h2 class="m-0 break-words text-xl font-bold tracking-tight">{{ displayName }}</h2>
        <Badge v-for="badge in badges" :key="badge.key" :variant="badge.variant ?? 'secondary'" class="shrink-0">{{ badge.label }}</Badge>
      </div>
      <p class="m-0 break-all text-sm text-muted-foreground">{{ email || emailFallback }}</p>
      <p v-if="subtitle" class="mb-0 mt-0.5 text-xs text-muted-foreground">{{ subtitle }}</p>
      <slot name="actions" />
    </div>
  </section>
</template>
