# @madsholme/ui

## 0.1.0

### Minor Changes

- a8bad15: First release: the shared Vue components, application shell and profile-page building blocks,
  reconciled from SwiftDeploy b49e160, SwiftConfig b47bfef and SwiftPatch ba910c8 (see
  docs/ui-reconciliation.md).

  - **shadcn-vue components:** SwiftDeploy's, with SwiftPatch's `data-slot` on every part and its
    `ui-*` class hooks, plus:
    - SwiftConfig's scrolling dialog and Select;
    - SwiftPatch's NativeSelect, checkbox states, calendar accessibility and viewport-clamped
      popovers and menus;
    - `TextTooltip`.
  - **`AppShell` and its parts.** The shell takes data and emits actions; it never imports
    product code. The profile dropdown follows SwiftDeploy's order. Built in:
    - the theme quick picker ("System", RN, RN Light, SW Light as `menuitemradio`);
    - the impersonation side panel with type-ahead and an "Act as user" button per result;
    - the banner "Acting as {user} (Started by {actor})";
    - the admin-mode banner, global notifications, skip link and logout retry;
    - focus management after actor changes and dialogs.
  - **Profile building blocks:** the page layout; identity, details, authorization identity,
    badges, API access, work default and theme cards (with "Match system theme"); and the API
    token list, create form, generated token and revoke dialog.
  - **Tailwind 4.3.** The `tailwindcss` peer is `^4.3.0`, with `tailwind-merge` 3. Add
    `@source '../node_modules/@madsholme/ui/src';` to the product CSS, after the import sequence in
    the `@madsholme/themes` README. There is no `tailwind.config` and no JS preset.
  - **Colours.** Components use the `oklch()` tokens of `@madsholme/themes` as `var(--x)` or semantic
    utilities (`bg-warning/15`); alpha is `color-mix()`. Differences from the products' copies:
    `hsl(var(--x))` became `var(--x)`, and `--sd-shadow-rgb` became `--sd-shadow-color`.
  - **`useThemeState`**, `themeIcons` and `withThemeIcons` for `@madsholme/themes`.

  **Accessibility, compared with the products' copies:**

  - The profile trigger's accessible name always contains its visible text.
  - Theme choices in the menu are `menuitemradio` with `aria-checked`, and arrow keys reach them.
  - Menus are non-modal.
  - While a modal is open, the page is `inert`.
  - The "Act as user" buttons are named after their user.
  - Focus returns to the profile trigger after the impersonation dialog, and to the revoke button
    after the revoke dialog.

- b1cab2f: Add an animation profile preference, enabled by default. Themes exports a framework-free
  animation controller with local cache, optional profile persistence, rollback and identity handling,
  plus an optional animation cache key for pre-paint boot. The explicit off override suppresses CSS
  motion while retaining continuous loading indicators and existing OS reduced-motion protection.
  UI exports ProfileAnimationCard and useAnimationState. Consumers adopting profile persistence
  provide a boolean backend field (default true) and save adapter; existing theme APIs are unchanged.
- 84580ba: Support products whose profile backend only accepts named themes. Add opt-in `allowSystem: false`
  and `fallbackTheme` controller/boot options, hide system selection in the shell and profile card,
  and keep existing system-aware defaults. Minify the generated boot script with the existing
  esbuild toolchain to retain its size budget.

  Make Input and Textarea emit model changes synchronously while retaining uncontrolled defaults, so consumer forms can clear submitted values reliably. Mirror modal aria-hidden on descendants as well as the root, keeping hidden page content inert when a retained live status banner prevents its ancestor from being hidden.

  Allow a named fallback for missing/invalid values while retaining explicit system matching, so existing product defaults survive adoption.

- f03aea0: Component animations run (docs/theme-reconciliation.md §14).

  - **New peer dependency** `tw-animate-css ^1.4.0`. Import it once in the product's main CSS,
    directly after the Tailwind theme import:

    ```css
    @import "@madsholme/themes/css/tailwind-theme.css";
    @import "tw-animate-css";
    ```

    The components have carried `animate-in`, `animate-out`, `fade-*`, `zoom-*`, `slide-*` and
    `duration-*` classes since the first release; without the import they were no-ops. The
    `@madsholme/themes` README shows the full sequence.

  - **What animates:** dialog, alert dialog, sheet, dropdown menu and sub menu, select, popover,
    tooltip, navigation menu (content, viewport, indicator) and accordion open and close with their
    existing enter and exit classes. The shell's admin-mode and global-notification banners reveal
    once on mount, and header items ease their hover, press and focus states (the themes package
    supplies both).
  - **Timing note for tests.** A closing overlay stays mounted while its exit animation plays
    (150 to 200 ms). A test that acts right after closing a menu or dialog must wait for the element
    to be hidden or unmounted (`await expect(locator).toBeHidden()`), as
    `apps/template/tests/axe.spec.ts` does, or it audits or clicks through the leaving element.
  - **New `data-slot="navigation-menu-trigger-icon"`** on the `NavigationMenuTrigger` chevron, so
    the themes package can collapse its rotation under `prefers-reduced-motion: reduce`.
  - **Reduced motion.** Users with `prefers-reduced-motion: reduce` get every `animate-*` utility
    except the loaders, and every shell transition, at 0.01 ms (themes package); `animate-spin` and
    `animate-pulse` keep running.

### Patch Changes

- Updated dependencies [91e0acd]
- Updated dependencies [b1cab2f]
- Updated dependencies [84580ba]
- Updated dependencies [3574bbb]
- Updated dependencies [f03aea0]
  - @madsholme/themes@0.1.0
