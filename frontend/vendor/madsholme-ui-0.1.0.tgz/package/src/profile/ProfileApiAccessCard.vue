<script setup lang="ts">
import { RouterLink, type RouteLocationRaw } from 'vue-router'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'

withDefaults(defineProps<{
  manageTo?: RouteLocationRaw
  manageLabel?: string
  docsHref?: string | null
  docsLabel?: string
  title?: string
  description?: string
}>(), {
  manageTo: '/profile/api-tokens',
  manageLabel: 'Manage API tokens',
  docsHref: null,
  docsLabel: 'User API documentation',
  title: 'API access',
  description: 'Generate an expiring token for curl, Ansible, or other API clients.',
})
</script>

<template>
  <Card data-slot="profile-api-access-card">
    <CardHeader>
      <CardTitle as="h2">{{ title }}</CardTitle>
      <CardDescription>{{ description }}</CardDescription>
    </CardHeader>
    <CardContent class="flex flex-wrap gap-2">
      <Button as-child variant="outline"><RouterLink :to="manageTo">{{ manageLabel }}</RouterLink></Button>
      <Button v-if="docsHref" as-child variant="outline">
        <a :href="docsHref" target="_blank" rel="noopener noreferrer">{{ docsLabel }}<span class="sr-only"> (opens in a new tab)</span></a>
      </Button>
    </CardContent>
  </Card>
</template>
