<script setup lang="ts">
import { Button } from '../../components/ui/button'
import { Badge } from '../../components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card'
import { Skeleton } from '../../components/ui/skeleton'
import { formatTokenDate } from '../format'
import type { ApiTokenSummary } from '../types'

withDefaults(defineProps<{
  tokens: readonly ApiTokenSummary[]
  loading?: boolean
  /** A revoke request is running. */
  revoking?: boolean
  /** Show each token's access level (read / read and write). */
  showAccess?: boolean
  locale?: string
  timeZone?: string
  title?: string
  description?: string
  emptyText?: string
}>(), {
  loading: false,
  revoking: false,
  showAccess: false,
  locale: 'en-GB',
  timeZone: 'Europe/Copenhagen',
  title: 'Your active tokens',
  description: 'Expired and revoked tokens are removed from this list. Dates are in Copenhagen time.',
  emptyText: 'No active tokens. Generate one when you need API access.',
})

defineEmits<{ revoke: [token: ApiTokenSummary] }>()
</script>

<template>
  <Card data-slot="api-token-list">
    <CardHeader>
      <CardTitle as="h2">{{ title }}</CardTitle>
      <CardDescription>{{ description }}</CardDescription>
    </CardHeader>
    <CardContent>
      <div v-if="loading" class="flex flex-col gap-3" aria-label="Loading tokens" aria-busy="true">
        <Skeleton v-for="row in 2" :key="row" class="h-20 w-full" />
      </div>
      <p v-else-if="!tokens.length" class="m-0 py-6 text-center text-sm text-muted-foreground">{{ emptyText }}</p>
      <ul v-else class="m-0 list-none divide-y divide-border p-0">
        <li
          v-for="token in tokens"
          :key="token.id"
          data-slot="api-token"
          class="flex flex-col gap-4 py-5 first:pt-0 last:pb-0 sm:flex-row sm:items-center sm:justify-between"
        >
          <div class="min-w-0 flex-1">
            <p class="m-0 flex flex-wrap items-center gap-2 break-words font-medium">
              {{ token.name }}
              <Badge v-if="showAccess && token.access" variant="outline">{{ token.access === 'write' ? 'Read and write' : 'Read only' }}</Badge>
            </p>
            <code class="text-xs text-muted-foreground">{{ token.prefix }}…</code>
            <dl class="m-0 mt-2 grid gap-x-5 gap-y-1 text-xs text-muted-foreground sm:grid-cols-2">
              <div><dt class="inline">Expires: </dt><dd class="m-0 inline">{{ formatTokenDate(token.expiresAt, { locale, timeZone }) }}</dd></div>
              <div><dt class="inline">Last used: </dt><dd class="m-0 inline">{{ token.lastUsedAt ? formatTokenDate(token.lastUsedAt, { locale, timeZone }) : 'Not used yet' }}</dd></div>
              <div><dt class="inline">Created: </dt><dd class="m-0 inline">{{ formatTokenDate(token.createdAt, { locale, timeZone }) }}</dd></div>
            </dl>
          </div>
          <Button
            type="button"
            variant="outline"
            class="self-start sm:self-center"
            :disabled="revoking"
            :aria-label="`Revoke ${token.name}`"
            @click="$emit('revoke', token)"
          >Revoke</Button>
        </li>
      </ul>
    </CardContent>
  </Card>
</template>
