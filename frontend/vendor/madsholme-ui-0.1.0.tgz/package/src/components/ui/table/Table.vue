<script setup lang="ts">
import type { HTMLAttributes } from "vue"
import { Primitive } from "reka-ui"
import { cn } from "../../../lib/utils"

defineOptions({ inheritAttrs: false })
const props = withDefaults(defineProps<{
  class?: HTMLAttributes["class"]
  wrapped?: boolean
  containerClass?: HTMLAttributes["class"]
  containerStyle?: HTMLAttributes["style"]
}>(), { wrapped: true })
</script>

<template>
  <Primitive :as-child="!wrapped" data-slot="table-container" :class="wrapped ? cn('relative w-full overflow-auto', containerClass) : undefined" :style="wrapped ? containerStyle : undefined">
    <table v-bind="$attrs" data-slot="table" :class="cn('w-full caption-bottom text-sm', props.class)">
      <slot />
    </table>
  </Primitive>
</template>
