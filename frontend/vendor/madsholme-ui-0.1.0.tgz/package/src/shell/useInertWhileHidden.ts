import { onBeforeUnmount, onMounted, type Ref } from 'vue'

/** Mirror Reka's aria-hidden into inert, including siblings of retained live regions. */
export function useInertWhileHidden(root: Ref<HTMLElement | null>): void {
  let observer: MutationObserver | undefined
  let target: HTMLElement | null = null
  const owned = new Set<HTMLElement>()

  const sync = () => {
    if (!target) return
    const hidden = new Set<HTMLElement>(target.querySelectorAll('[aria-hidden="true"]'))
    if (target.getAttribute('aria-hidden') === 'true') hidden.add(target)
    for (const element of owned) {
      if (!hidden.has(element)) {
        element.removeAttribute('inert')
        owned.delete(element)
      }
    }
    for (const element of hidden) {
      if (!element.hasAttribute('inert')) {
        element.setAttribute('inert', '')
        owned.add(element)
      }
    }
  }

  onMounted(() => {
    let element = root.value
    while (element?.parentElement && element.parentElement !== document.body) element = element.parentElement
    target = element
    if (!target || typeof MutationObserver === 'undefined') return
    observer = new MutationObserver(sync)
    observer.observe(target, { attributes: true, subtree: true, attributeFilter: ['aria-hidden'], childList: true })
    sync()
  })

  onBeforeUnmount(() => {
    observer?.disconnect()
    for (const element of owned) element.removeAttribute('inert')
    owned.clear()
  })
}
