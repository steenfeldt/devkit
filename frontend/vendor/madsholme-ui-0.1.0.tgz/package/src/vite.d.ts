/** Add to Vite plugins to support @madsholme/ui source exports in the dev server. */
export declare function uiDependencies(): {
  name: string
  config(): { optimizeDeps: { include: string[] } }
}
