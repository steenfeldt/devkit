<script setup lang="ts">
import { onMounted, onBeforeUnmount, watch } from 'vue'
import { TooltipTrigger, TooltipPortal, TooltipContent, injectTooltipRootContext } from 'reka-ui'

const props = defineProps<{ trigger: HTMLElement; text: string }>()
const context = injectTooltipRootContext()
let originalDescription: string | null = null
let descriptionApplied = false
onMounted(() => { context.onTriggerChange(props.trigger) })
watch(context.open, (open) => {
  if (open) {
    descriptionApplied = true
    originalDescription = props.trigger.getAttribute('aria-describedby')
    props.trigger.setAttribute('aria-describedby', [originalDescription, context.contentId].filter(Boolean).join(' '))
  } else restoreDescription()
}, { flush: 'post' })
function restoreDescription() {
  if (!descriptionApplied) return
  descriptionApplied = false
  if (originalDescription === null) props.trigger.removeAttribute('aria-describedby')
  else props.trigger.setAttribute('aria-describedby', originalDescription)
}
onBeforeUnmount(restoreDescription)
defineExpose({ enter: context.onTriggerEnter, leave: context.onTriggerLeave, open: context.onOpen, close: context.onClose })
</script>

<template>
  <!-- The real child stays mounted outside the lazy root. This hidden anchor supplies
       Reka's content ID and positioning reference; context.trigger is the real child. -->
  <TooltipTrigger as="span" hidden :reference="trigger" />
  <TooltipPortal>
    <TooltipContent data-slot="tooltip-content" class="ui-tooltip z-[60] max-w-[min(22rem,calc(100vw-1.5rem))] overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md" :side-offset="6" :collision-padding="12">
      {{ text }}
    </TooltipContent>
  </TooltipPortal>
</template>
