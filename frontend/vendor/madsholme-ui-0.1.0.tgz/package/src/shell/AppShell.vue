<script setup lang="ts">
import { appShellThemeOptions, type ThemePreference } from '@madsholme/themes'
import { computed, nextTick, ref, watch } from 'vue'
import { RouterLink, useRoute, type RouteLocationRaw } from 'vue-router'
import { Button } from '../components/ui/button'
import ImpersonationBanner from '../impersonation/ImpersonationBanner.vue'
import ImpersonationDialog from '../impersonation/ImpersonationDialog.vue'
import { themeIcons, withThemeIcons, type ThemeChoice } from '../theme/icons'
import type { GlobalNotice, ImpersonationTarget, NavGroup, ShellAdminMode, ShellImpersonation, ShellThemeState, ShellUser } from '../types'
import AdminModeBanner from './AdminModeBanner.vue'
import { collapseClasses, shellContainerClass, type CollapseBreakpoint } from './classes'
import GlobalNotificationBanner from './GlobalNotificationBanner.vue'
import MobileNavigation from './MobileNavigation.vue'
import { currentNavGroupId } from './navigation'
import ProfileMenu from './ProfileMenu.vue'
import SkipLink from './SkipLink.vue'
import TopNavigation from './TopNavigation.vue'
import { useInertWhileHidden } from './useInertWhileHidden'

const props = withDefaults(defineProps<{
  homeTo: RouteLocationRaw
  /** Accessible name of the brand link, e.g. "SwiftDeploy home". */
  homeLabel: string
  navigation: readonly NavGroup[]
  /** Overrides the current group computed from the route. */
  currentNavId?: string | null
  collapseBelow?: CollapseBreakpoint
  user: ShellUser
  profileTo?: RouteLocationRaw
  theme: ShellThemeState
  adminMode?: ShellAdminMode
  impersonation?: ShellImpersonation
  logout?: { pending?: boolean; error?: string }
  notifications?: readonly GlobalNotice[]
}>(), {
  currentNavId: undefined,
  collapseBelow: 'md',
  profileTo: '/profile',
  adminMode: () => ({ active: false, canToggle: false }),
  impersonation: () => ({ active: false, canStart: false }),
  logout: () => ({}),
  notifications: () => [],
})

const emit = defineEmits<{
  'select-theme': [preference: ThemePreference]
  'toggle-admin-mode': []
  'search-impersonation': [term: string]
  'start-impersonation': [id: ImpersonationTarget['id']]
  'stop-impersonation': []
  'impersonation-dialog': [open: boolean]
  logout: []
}>()

const route = useRoute()
const currentId = computed(() => props.currentNavId !== undefined ? props.currentNavId : currentNavGroupId(props.navigation, route.path))
const collapse = computed(() => collapseClasses[props.collapseBelow])
const themeChoices = computed<readonly ThemeChoice[]>(() => (props.theme.choices ?? [
  { value: 'system', label: 'System', icon: themeIcons.system },
  ...withThemeIcons(appShellThemeOptions),
]).filter(choice => props.theme.allowSystem !== false || choice.value !== 'system'))

const openGroup = ref('')
const profileMenuOpen = ref(false)
const mobileNavigationOpen = ref(false)
const dialogOpen = ref(false)
const banner = ref<InstanceType<typeof ImpersonationBanner> | null>(null)
const profileMenu = ref<InstanceType<typeof ProfileMenu> | null>(null)
const root = ref<HTMLElement | null>(null)
useInertWhileHidden(root)

// SwiftPatch: opening the profile menu closes navigation groups; a route change closes every menu.
watch(profileMenuOpen, (open) => { if (open) openGroup.value = '' })
watch(() => route.fullPath, () => {
  profileMenuOpen.value = false
  mobileNavigationOpen.value = false
  openGroup.value = ''
})

function setDialogOpen(open: boolean): void {
  dialogOpen.value = open
  emit('impersonation-dialog', open)
}

// The product starts impersonation; once the session reports it, the dialog is done.
watch(() => props.impersonation.active, (active) => { if (active && dialogOpen.value) setDialogOpen(false) })

const showBanner = computed(() => props.impersonation.active && props.impersonation.actor && props.impersonation.effective)

/**
 * Restores focus after an actor change without a page reload: the stop action, else the
 * impersonation entry's trigger, else the profile trigger, else the main content.
 */
async function restoreFocus(): Promise<void> {
  await nextTick()
  if (banner.value?.focusStopAction()) return
  const trigger = profileMenu.value?.triggerElement()
  if (trigger?.isConnected) {
    trigger.focus()
    return
  }
  document.querySelector<HTMLElement>('#main-content')?.focus()
}

/** After the impersonation dialog closes: the stop action if impersonation started, else the profile trigger (SwiftPatch). */
function focusAfterDialog(): void {
  // One task later, after useInertWhileHidden has cleared `inert` from the page.
  setTimeout(() => { void restoreFocus() })
}

defineExpose({ restoreFocus })
</script>

<template>
  <div ref="root" data-slot="app-shell" class="sd-app-shell flex min-h-screen flex-col">
    <SkipLink />
    <ImpersonationBanner
      v-if="showBanner"
      ref="banner"
      :effective="impersonation.effective!"
      :actor="impersonation.actor!"
      :pending="impersonation.stopPending"
      :error="impersonation.stopError"
      @stop="emit('stop-impersonation')"
    />
    <AdminModeBanner v-if="adminMode.active" />

    <header data-slot="site-header" class="site-header sticky top-0 z-50 w-full border-b bg-background/95 text-foreground backdrop-blur-sm supports-[backdrop-filter]:bg-background/60">
      <div :class="[shellContainerClass, 'flex h-14 items-center gap-2 sm:gap-4 xl:gap-6']">
        <RouterLink
          :to="homeTo"
          :aria-label="homeLabel"
          data-slot="site-header-home"
          data-testid="product-name"
          class="flex shrink-0 items-center gap-2 text-foreground transition-colors hover:text-foreground/80"
        >
          <slot name="brand" />
        </RouterLink>

        <div data-slot="mobile-navigation" :class="collapse.mobile">
          <MobileNavigation v-model:open="mobileNavigationOpen" :navigation="navigation" :current-id="currentId" />
        </div>
        <div data-slot="top-navigation" :class="collapse.desktop">
          <TopNavigation v-model:open-group="openGroup" :navigation="navigation" :current-id="currentId" />
        </div>

        <div class="flex-1" />
        <slot name="header-actions" />

        <ProfileMenu
          ref="profileMenu"
          v-model:open="profileMenuOpen"
          :user="user"
          :profile-to="profileTo"
          :theme-choices="themeChoices"
          :theme-preference="theme.preference"
          :theme-error="theme.error"
          :can-toggle-admin-mode="adminMode.canToggle"
          :admin-mode-active="adminMode.active"
          :admin-mode-pending="adminMode.pending"
          :can-impersonate="impersonation.canStart && !impersonation.active"
          :logout-pending="logout.pending"
          @select-theme="emit('select-theme', $event)"
          @toggle-admin-mode="emit('toggle-admin-mode')"
          @impersonate="setDialogOpen(true)"
          @logout="emit('logout')"
        >
          <template #items><slot name="profile-menu-items" /></template>
        </ProfileMenu>
      </div>
    </header>

    <GlobalNotificationBanner :notifications="notifications" />

    <div v-if="adminMode.error" :class="[shellContainerClass, 'mt-3']">
      <div data-slot="shell-alert" role="alert" class="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
        {{ adminMode.error }}
      </div>
    </div>
    <div v-if="logout.error" :class="[shellContainerClass, 'mt-3']">
      <div data-slot="shell-alert" role="alert" class="flex flex-wrap items-center justify-between gap-2 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm">
        <span class="text-destructive">{{ logout.error }}</span>
        <Button variant="outline" size="sm" data-testid="retry-logout" type="button" :disabled="logout.pending" @click="emit('logout')">
          Retry sign out
        </Button>
      </div>
    </div>
    <slot name="alerts" />

    <main id="main-content" data-slot="app-shell-main" tabindex="-1" class="min-w-0 flex-1 focus:outline-hidden">
      <slot name="subnav" />
      <slot />
    </main>

    <ImpersonationDialog
      :open="dialogOpen"
      :targets="impersonation.targets"
      :searching="impersonation.searching"
      :pending="impersonation.startPending"
      :error="impersonation.dialogError"
      @update:open="setDialogOpen"
      @search="emit('search-impersonation', $event)"
      @start="emit('start-impersonation', $event)"
      @closed="focusAfterDialog"
    />
  </div>
</template>
