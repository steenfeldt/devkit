<script setup lang="ts">
import CollapsibleChevron from "./CollapsibleChevron.vue"
import { reactiveOmit } from "@vueuse/core"
import type { CollapsibleTriggerProps } from "reka-ui"
import { CollapsibleTrigger } from "reka-ui"

const props = defineProps<CollapsibleTriggerProps & { showChevron?: boolean }>()
const delegated = reactiveOmit(props, "showChevron")
</script>

<template>
  <CollapsibleTrigger
    data-slot="collapsible-trigger"
    v-bind="delegated"
  >
    <slot />
    <CollapsibleChevron v-if="showChevron && !asChild" />
  </CollapsibleTrigger>
</template>
