import { applyThemeToDocument, defaultMatchMedia, prefersDarkQuery, type MatchMedia } from './dom'
import {
  defaultSystemThemes,
  systemPreference,
  type SystemThemes,
  type ThemeKey,
  type ThemePreference,
} from './registry'
import { isThemePreference, resolvePreference, resolveSystemTheme } from './resolve'

export interface ThemeStorage {
  getItem(key: string): string | null
  setItem(key: string, value: string): void
}

export interface ThemeProfileAdapter {
  /** Persist the preference (a theme key or `system`) for the signed-in user. Reject on failure. */
  save(preference: ThemePreference): Promise<void>
}

export type ImpersonationThemeSource =
  /** The session already reports the initiating user's theme, and saves write the initiator's
   *  preference. */
  | 'session-is-initiator'
  /** The backend would serve and write the impersonated user's theme. While impersonating, the
   *  profile theme is ignored, the initiator's cached preference stays on screen, and nothing is
   *  saved. */
  | 'keep-initiator-locally'

export interface ThemeSaveErrorEvent {
  readonly error: unknown
  readonly attempted: ThemePreference
  readonly restored: ThemePreference
}

export interface ThemeControllerOptions {
  /** Browser storage key for the initial-render cache, e.g. `theme` or `swiftpatch.theme`. */
  storageKey: string
  /** Defaults to `localStorage`. Pass `null` to disable caching. */
  storage?: ThemeStorage | null
  /** Defaults to `document.documentElement`. */
  root?: () => HTMLElement | null
  /** Defaults to `window.matchMedia`. */
  matchMedia?: MatchMedia
  /** Defaults to RN Light (light OS) and RN (dark OS). */
  systemThemes?: SystemThemes
  /** Disable system selection for backends that accept named themes only. */
  allowSystem?: boolean
  /** Optional named default for missing/invalid values. Also replaces system when allowSystem is false (default light). */
  fallbackTheme?: ThemeKey
  /** Omit for an app without a profile backend. */
  profile?: ThemeProfileAdapter
  /** Defaults to `session-is-initiator`. */
  impersonation?: ImpersonationThemeSource
  /** Token for the acting identity. A failed save only rolls back while the token is unchanged. */
  identityToken?: () => unknown
  saveErrorMessage?: string
  onSaveError?: (event: ThemeSaveErrorEvent) => void
}

export interface ThemeState {
  /** What the user chose: a theme key or `system`. */
  readonly preference: ThemePreference
  /** What is on screen. */
  readonly theme: ThemeKey
  readonly followsSystem: boolean
  /** A save is in flight or queued. */
  readonly saving: boolean
  readonly saveError: string
  /** A profile has been applied, so selections are saved. */
  readonly profileActive: boolean
  readonly impersonating: boolean
}

export type SelectResult =
  /** Applied and cached; nothing to save (no profile, logged out, or impersonating locally). */
  | 'applied-locally'
  /** The backend confirmed this preference. */
  | 'saved'
  /** The save failed and the last confirmed preference was restored. */
  | 'rolled-back'
  /** A newer selection, or a profile or identity change, replaced this one before it settled. */
  | 'superseded'

export interface ThemeController {
  getState(): ThemeState
  subscribe(listener: (state: ThemeState) => void): () => void
  /** Initial render: read the cache, resolve, apply to the document and rewrite the cache. */
  init(): ThemeKey
  /** The cached preference before a profile overwrites it, or null when nothing is cached. */
  readCachedPreference(): ThemePreference | null
  /** Apply and cache now; save when a profile is active. Resolves with the final outcome. */
  select(preference: ThemePreference): Promise<SelectResult>
  /** On: follow the OS. Off: keep the theme that is on screen as an explicit choice. */
  setFollowSystem(on: boolean): Promise<SelectResult>
  /** Apply the profile's preference (the source of truth) and enable saving. */
  applyProfile(value: string | null | undefined, context?: { impersonating?: boolean }): ThemeKey
  /** Logout or loss of identity: stop saving and drop pending work. The theme stays on screen. */
  clearProfile(): void
  /** Stop following OS changes and drop subscribers. */
  dispose(): void
}

export const defaultSaveErrorMessage = 'Unable to save your theme. Please select it again to retry.'

interface QueuedSelection {
  readonly preference: ThemePreference
  readonly settle: (result: SelectResult) => void
}

function browserStorage(): ThemeStorage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage
  } catch {
    return null
  }
}

function defaultRoot(): HTMLElement | null {
  return typeof document === 'undefined' ? null : document.documentElement
}

export function createThemeController(options: ThemeControllerOptions): ThemeController {
  const storage = options.storage === undefined ? browserStorage() : options.storage
  const getRoot = options.root ?? defaultRoot
  const matchMedia = options.matchMedia ?? defaultMatchMedia()
  const systemThemes = options.systemThemes ?? defaultSystemThemes
  const impersonationMode = options.impersonation ?? 'session-is-initiator'
  const saveErrorMessage = options.saveErrorMessage ?? defaultSaveErrorMessage

  const normalize = (value: string | null | undefined): ThemePreference => {
    const preference = resolvePreference(value)
    return preference === systemPreference && (options.allowSystem === false || (value !== systemPreference && options.fallbackTheme !== undefined)) ? (options.fallbackTheme ?? 'light') : preference
  }

  const listeners = new Set<(state: ThemeState) => void>()
  // Bumped by applyProfile and clearProfile; results from an older revision are ignored.
  let revision = 0
  let inFlight = false
  let queued: QueuedSelection | null = null
  let media: MediaQueryList | null = null

  function readCache(): string | null {
    try {
      return storage?.getItem(options.storageKey) ?? null
    } catch {
      return null
    }
  }

  function writeCache(preference: ThemePreference): void {
    try {
      storage?.setItem(options.storageKey, preference)
    } catch {
      // Private mode or disabled storage: the theme still applies for this page.
    }
  }

  function prefersDark(): boolean {
    try {
      return matchMedia?.(prefersDarkQuery).matches === true
    } catch {
      return false
    }
  }

  function resolve(preference: ThemePreference): ThemeKey {
    return preference === systemPreference ? resolveSystemTheme(prefersDark(), systemThemes) : preference
  }

  const initialPreference = normalize(readCache())
  let state: ThemeState = {
    preference: initialPreference,
    theme: resolve(initialPreference),
    followsSystem: initialPreference === systemPreference,
    saving: false,
    saveError: '',
    profileActive: false,
    impersonating: false,
  }
  // The last preference the backend confirmed (or the profile reported).
  let confirmed: ThemePreference = initialPreference

  function setState(patch: Partial<ThemeState>): void {
    const next = { ...state, ...patch }
    if ((Object.keys(next) as (keyof ThemeState)[]).every((key) => next[key] === state[key])) return
    state = next
    for (const listener of [...listeners]) listener(state)
  }

  function onSystemChange(): void {
    if (state.preference !== systemPreference) return
    const theme = resolve(systemPreference)
    applyThemeToDocument(theme, getRoot())
    setState({ theme })
  }

  function syncSystemListener(): void {
    if (state.followsSystem && !media && matchMedia) {
      try {
        media = matchMedia(prefersDarkQuery)
        if (typeof media.addEventListener === 'function') media.addEventListener('change', onSystemChange)
        else media.addListener(onSystemChange)
      } catch {
        media = null
      }
    } else if (!state.followsSystem && media) {
      detachSystemListener()
    }
  }

  function detachSystemListener(): void {
    if (!media) return
    if (typeof media.removeEventListener === 'function') media.removeEventListener('change', onSystemChange)
    else media.removeListener(onSystemChange)
    media = null
  }

  /** Shows a preference: resolve, apply to the document, cache, publish. */
  function show(preference: ThemePreference, patch: Partial<ThemeState> = {}): void {
    const theme = resolve(preference)
    applyThemeToDocument(theme, getRoot())
    writeCache(preference)
    setState({ ...patch, preference, theme, followsSystem: preference === systemPreference })
    syncSystemListener()
  }

  function canSave(): boolean {
    if (!options.profile || !state.profileActive) return false
    return !(state.impersonating && impersonationMode === 'keep-initiator-locally')
  }

  function dropQueued(): void {
    const pending = queued
    queued = null
    pending?.settle('superseded')
  }

  /** Saves one preference, then the newest queued selection, if any. */
  async function send(preference: ThemePreference): Promise<SelectResult> {
    const requestRevision = revision
    const token = options.identityToken?.()
    inFlight = true
    setState({ saving: true })
    let failed = false
    let failure: unknown
    try {
      await options.profile!.save(preference)
    } catch (error) {
      failed = true
      failure = error
    }
    // A profile or identity change already reset the queue and saving state.
    if (requestRevision !== revision) return 'superseded'
    inFlight = false
    if (failed && options.identityToken && token !== options.identityToken()) {
      dropQueued()
      setState({ saving: false })
      return 'superseded'
    }
    if (!failed) confirmed = preference
    // Latest wins: only the newest queued selection is sent, and only if the server needs it.
    const next = queued
    queued = null
    if (next) {
      if (next.preference === confirmed) {
        setState({ saving: false })
        next.settle('saved')
      } else {
        void send(next.preference).then(next.settle)
      }
      return 'superseded'
    }
    if (failed) {
      show(confirmed, { saving: false, saveError: saveErrorMessage })
      options.onSaveError?.({ error: failure, attempted: preference, restored: confirmed })
      return 'rolled-back'
    }
    setState({ saving: false })
    return 'saved'
  }

  async function select(preference: ThemePreference): Promise<SelectResult> {
    if (!isThemePreference(preference)) throw new TypeError(`Unknown theme preference: ${String(preference)}`)
    if (options.allowSystem === false && preference === systemPreference) throw new TypeError('System theme is disabled')
    show(preference, { saveError: '' })
    if (!canSave()) return 'applied-locally'
    if (inFlight) {
      dropQueued()
      return new Promise<SelectResult>((settle) => {
        queued = { preference, settle }
        setState({ saving: true })
      })
    }
    return send(preference)
  }

  function invalidate(): void {
    revision += 1
    inFlight = false
    dropQueued()
  }

  return {
    getState: () => state,

    subscribe(listener) {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },

    init() {
      const preference = normalize(readCache())
      confirmed = state.profileActive ? confirmed : preference
      show(preference)
      return state.theme
    },

    readCachedPreference() {
      const raw = readCache()
      return raw ? normalize(raw) : null
    },

    select,

    setFollowSystem(on) {
      return select(on ? systemPreference : state.theme)
    },

    applyProfile(value, context = {}) {
      invalidate()
      const impersonating = context.impersonating === true
      if (impersonating && impersonationMode === 'keep-initiator-locally') {
        // Keep the initiator's own theme; never show or overwrite the impersonated user's.
        setState({ profileActive: true, impersonating: true, saving: false, saveError: '' })
        return state.theme
      }
      const preference = normalize(value)
      confirmed = preference
      show(preference, { profileActive: true, impersonating, saving: false, saveError: '' })
      return state.theme
    },

    clearProfile() {
      invalidate()
      setState({ profileActive: false, impersonating: false, saving: false, saveError: '' })
    },

    dispose() {
      detachSystemListener()
      listeners.clear()
    },
  }
}
